// Created by Priyadarshini R for IVR 3D

package com.util;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


@SuppressWarnings("unchecked")
public class Parser extends DefaultHandler {

	private HashMap<String,String> mapParseResult = new HashMap<String,String>();
	private String strTmp;
	private String tagName =""; 
	List lstStart = new ArrayList();
	List lstEnd = new ArrayList();


	public HashMap parseXml(String strXml) 
	{
		SAXParserFactory spf = SAXParserFactory.newInstance();
		try 
		{
			InputSource source = new InputSource(new StringReader(strXml));
			SAXParser sp = spf.newSAXParser();
			sp.parse(source,this);
		}
		catch(Exception e) 
		{
			return null;
		}

		return mapParseResult;
	}

	/**
	 *	Overrids DefaultHandler class method
	 *	Receive notification of character data inside an element
	 */
	public void characters(char[] ch, int start, int length) throws SAXException {

		if ("specialCharacter".equalsIgnoreCase(tagName)) {
			strTmp += new String(ch, start, length);
		} else {
			strTmp = new String(ch, start, length);
		}
	}

	/**
	 *	Overrids DefaultHandler class method
	 *	Receive notification of the start of an element
	 */
	public void startElement(String namespaceURI, String localName,String qName, Attributes atts) {

		strTmp = ""; 
		if ("Message".equalsIgnoreCase(qName)) {
			mapParseResult.put(PaymentConstants.pymnt_3d_id, atts.getValue("id"));
		}
		if ("id".equalsIgnoreCase(qName) || "password".equalsIgnoreCase(qName)){
			tagName = "specialCharacter";
		}
		else{
			tagName="";
		}
	}

	/**
	 * Overrids DefaultHandler class method Receive notification of the end of
	 * an element
	 */
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		
		if("Error".equalsIgnoreCase(qName)){
			if ("version".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_version, strTmp);
			}
			if ("errorCode".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_errorCode, strTmp);
			}
			if ("errorMessage".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_errorMessage, strTmp);
			}
			if ("errorDetail".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_errorDetail, strTmp);
			}
			if ("vendorCode".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_vendorCode, strTmp);
			}
		}
		else{
			
			if ("version".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_version, strTmp);
			}
			if ("pan".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_pan, strTmp);
			}
			if ("acqBIN".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_acqBIN, strTmp);
			}
			if ("merID".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_merID, strTmp);
			}
			if ("name".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_merName, strTmp);
			}
			if ("country".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_country, strTmp);
			}
			if ("url".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_url, strTmp);
			}
			
			if ("xid".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_xid, strTmp);
			}
			if ("date".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_date, strTmp);
			}
			if ("amount".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_amt, strTmp);
			}
			if ("purchAmount".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_purchAmount, strTmp);
			}
			if ("currency".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_currency, strTmp);
			}
			if ("exponent".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_exponent, strTmp);
			}
			if ("acctID".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_acctID, strTmp);
			}
			if ("expiry".equalsIgnoreCase(qName)) {
				mapParseResult.put(PaymentConstants.pymnt_3d_expiry, strTmp);
			}
			
		}
	}
	
	
}
