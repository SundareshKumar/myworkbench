package com.util;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("unchecked")
public class ConcurrentHashMapUtil {
	
	static ConcurrentHashMap hashmap=new ConcurrentHashMap(32,0.9f,32);
	
	
	public static void put(String orgTranID,String tranID)
	{
		hashmap.put(orgTranID, tranID);
	}
	
	public static void putAll(HashMap HashMap)
	{
		hashmap.putAll(HashMap);
	}
	
	public static void remove(String orgTranID)
	{
		if(hashmap!=null)
		{
			hashmap.remove(orgTranID);
		}
	}
	
	public static String get(String orgTranID)
	{
		return (String) hashmap.get(orgTranID);
	}
	
}
