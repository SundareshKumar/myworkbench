package com.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;


public class TextFormat {

	private static HashMap<String, SimpleDateFormat> dateFrmtMap = new HashMap<String, SimpleDateFormat>();

	public static String simpleDateFormat(long l, String s) {
		Date date = new Date(l);
		return simpleDateFormat(date, s);
	}

	public static String simpleDateFormat(Date date, String s) {
		SimpleDateFormat simpledateformat = (SimpleDateFormat) dateFrmtMap
				.get(s);
		if (simpledateformat == null) {
			simpledateformat = new SimpleDateFormat(s);
			dateFrmtMap.put(s, simpledateformat);
		}
		FieldPosition fieldposition = new FieldPosition(0);
		StringBuffer stringbuffer = new StringBuffer(s.length());
		simpledateformat.format(date, stringbuffer, fieldposition);
		return stringbuffer.toString();
	}

	public static byte[] deflate(byte[] abyte0) throws IOException {
		if (abyte0 == null) {
			return new byte[0];
		} else {
			ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(
					(int) ((long) abyte0.length * 4L) / 5);
			DeflaterOutputStream deflateroutputstream = new DeflaterOutputStream(
					bytearrayoutputstream, new Deflater());
			deflateroutputstream.write(abyte0, 0, abyte0.length);
			deflateroutputstream.close();
			return bytearrayoutputstream.toByteArray();
		}
	}

	public static byte[] inflate(byte[] abyte0) throws IOException {
		if (abyte0 == null)
			return new byte[0];;
		ByteArrayInputStream bytearrayinputstream = new ByteArrayInputStream(
				abyte0);
		InflaterInputStream inflaterinputstream = new InflaterInputStream(
				bytearrayinputstream);
		ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(
				(int) ((long) abyte0.length * 5L) / 4);
		do {
			byte[] abyte1 = new byte[2048];
			int i = inflaterinputstream.read(abyte1);
			if (i != -1)
				bytearrayoutputstream.write(abyte1, 0, i);
			else
				return bytearrayoutputstream.toByteArray();
		} while (true);
	}

	public static final byte[] base64Encode(byte[] abyte0) {
		if (abyte0 == null)
			return new byte[0];
		byte[] abyte1 = new byte[abyte0.length + 2];
		System.arraycopy(abyte0, 0, abyte1, 0, abyte0.length);
		byte[] abyte2 = new byte[(abyte1.length / 3) * 4];
		int k = 0;
		for (int l = 0; k < abyte0.length; l += 4) {
			abyte2[l] = (byte) (abyte1[k] >>> 2 & 0x3f);
			abyte2[l + 1] = (byte) (abyte1[k + 1] >>> 4 & 0xf | abyte1[k] << 4 & 0x3f);
			abyte2[l + 2] = (byte) (abyte1[k + 2] >>> 6 & 3 | abyte1[k + 1] << 2 & 0x3f);
			abyte2[l + 3] = (byte) (abyte1[k + 2] & 0x3f);
			k += 3;
		}

		for (int i = 0; i < abyte2.length; i++)
			if (abyte2[i] < 26)
				abyte2[i] = (byte) (abyte2[i] + 65);
			else if (abyte2[i] < 52)
				abyte2[i] = (byte) ((abyte2[i] + 97) - 26);
			else if (abyte2[i] < 62)
				abyte2[i] = (byte) ((abyte2[i] + 48) - 52);
			else if (abyte2[i] < 63)
				abyte2[i] = 43;
			else
				abyte2[i] = 47;

		for (int j = abyte2.length - 1; j > (abyte0.length * 4) / 3; j--)
			abyte2[j] = 61;

		return abyte2;
	}

	public static final byte[] base64Decode(byte[] abyte0)
			throws DecoderException {
		Base64 base64 = new Base64();
		return base64.decode(abyte0);
	}

	public static String charEncodeString(byte[] abyte0) {
		
		String s = null;
		try {
			s = new String(abyte0, "US-ASCII");
		} catch (Exception exception) {
			
		}

		return s;
	}

	public static final byte[] charEncodeByteArray(String s) {
		
		byte abyte0[] = null;
		try {
			abyte0 = s.getBytes("US-ASCII");
		} catch (Exception exception) {
			
		}

		return abyte0;

	}

	public static String hexString(byte[] abyte0) {
		StringBuffer stringbuffer = new StringBuffer(abyte0.length * 2);
		for (int i = 0; i < abyte0.length; i++) {
			char c = Character.forDigit(abyte0[i] >>> 4 & 0xf, 16);
			char c1 = Character.forDigit(abyte0[i] & 0xf, 16);
			stringbuffer.append(Character.toUpperCase(c));
			stringbuffer.append(Character.toUpperCase(c1));
		}

		return stringbuffer.toString();
	}

	public static String zeroFill(String s, int i) {
		StringBuffer stringbuffer = new StringBuffer(i);
		int j = i - s.length();
		for (int k = 0; k < j; k++)
			stringbuffer.append("0");

		stringbuffer.append(s);
		return stringbuffer.toString();
	}

	public static String removeNonNumeric(String s) {
		int i = s.length();
		StringBuffer stringbuffer = new StringBuffer(i);
		for (int j = 0; j < i; j++) {
			char c = s.charAt(j);
			if (Character.isDigit(c))
				stringbuffer.append(c);
		}

		return stringbuffer.toString();
	}

	public static String simpleDecimalFormat(String s, String s1)
			throws NumberFormatException {
		double d = Double.valueOf(s).doubleValue();
		return simpleDecimalFormat(d, s1);
	}

	public static String simpleDecimalFormat(double d, String s)
			throws NumberFormatException {
		NumberFormat numberformat = NumberFormat.getInstance();
		if (numberformat instanceof DecimalFormat) {
			DecimalFormat decimalformat = (DecimalFormat) numberformat;
			decimalformat.applyLocalizedPattern(s);
			return decimalformat.format(d);
		} else {
			throw new NumberFormatException("form," + numberformat
					+ " is not an instance of " + "Decimal Format");
		}
	}

	public static String removeNewLineChars(String s) {

		char ac[] = s.toCharArray();
		int i = 0;
		int j = s.length();
		StringBuffer stringbuffer = new StringBuffer(j);
		for (int k = 0; k < j; k++)
			if (ac[k] == '\r' || ac[k] == '\n') {
				int l = k - i;
				if (l != 0)
					stringbuffer.append(ac, i, l);
				i = k + 1;
			}

		stringbuffer.append(ac, i, j - i);
		return stringbuffer.toString();
	}

	public static byte[] toByteArray(String string) {
		byte[] bytes = new byte[string.length()];
		char[] chars = string.toCharArray();

		for (int i = 0; i != chars.length; i++) {
			bytes[i] = (byte) chars[i];
		}

		return bytes;
	}

	

	public static String filterSpecialChars(String in) {
		if (in == null)
			return null;

		StringBuffer sb = new StringBuffer();
		char[] chars = in.toCharArray();

		for (int i = 0; i < chars.length; i++) {

			switch (chars[i]) {
			case '<':
				sb.append("&lt;");
				break;

			case '>':
				sb.append("&gt;");
				break;

			case '&':
				sb.append("&amp;");
				break;

			default:
				sb.append(chars[i]);
			}
		}

		return sb.toString();
	}

	public static String padRight(String s, int i) {
		if (s.length() >= i)
			return s;
		StringBuffer stringbuffer;
		for (stringbuffer = new StringBuffer(s); stringbuffer.length() < i; stringbuffer
				.append(' '))
			;
		return stringbuffer.toString();
	}

	public static String formatCurrency(double d, int i, String s) {

		NumberFormat numberformat = NumberFormat.getInstance();
		numberformat.setMaximumFractionDigits(i);
		numberformat.setMinimumFractionDigits(i);
		return s + numberformat.format(d);
	}
	
	 
	 public static String removeCharacter(String s, char c)
	    {
	        int i = s.length();
	        StringBuffer stringbuffer = new StringBuffer(i);
	        for(int j = 0; j < i; j++)
	        {
	            char c1 = s.charAt(j);
	            if(c1 != c)
	                stringbuffer.append(c1);
	        }

	        return stringbuffer.toString();
	    }

	 /*code added for redirect - starts*/
		public static byte[] hexString2Byte(String s)
		{
		    int i = s.length() / 2;
		    byte abyte0[] = new byte[i];
		    int j = 0;
		    for(int k = 0; k < s.length(); k += 2)
		    {
		        byte byte0 = (byte)Integer.parseInt(s.substring(k, k + 2), 16);
		        abyte0[j] = byte0;
		        j++;
		    }

		    return abyte0;
		}
		/*code added for redirect - ends*/
		
}
