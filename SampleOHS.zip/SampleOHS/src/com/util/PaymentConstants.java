/*************************************************************************************************************
 * Project id				:	FSS-PG-V1.0
 * Author					:	D Jagadesan 
 * Date of Creation			:	3rd Feb 2009
 * Date modified			:	
 * Class					:	PaymentConstants
 * Purpose					:	Constants for PaymentPage related operations
 * *
 ************************************************************************************************************/

package com.util; 

import java.io.File;
import java.util.HashMap;

public class PaymentConstants
{
	// config properties file location


	public static final String payzappServiceImplPort_address = "http://10.44.71.174:8085/RupayService/Payzappservice";

	//public static final String config_properties_file = "D:\\iPay\\Config\\config.properties";
	public static String config_properties_file;

//public static final String config_properties_file = "D:\\iPay\\Config\\config.properties";



//public static final String config_properties_file = "//home//qctap102//FSSIPAY//Config//iPay//Config//config.properties";


//public static final String config_properties_file = "//home//demo//ipay//Config//iPay//Config//config.properties";


    public static final String resource_file = "resource.properties";
	
	public static final String keystore_filepath = File.separator + "cgn" + File.separator + "keystore.bin";
	public static final String keystore_filename = "keystore.bin";
	public static final String resource_filepath = File.separator + "cgn" + File.separator + "resource.cgn";
	public static final String resource_filename = "resource.cgn";
	
	public static final String branding_location = "BRANDING_LOCATION";
	public static final String branding_inst = "INSTITUTION";
	public static final String branding_mrch = "MERCHANT";
	
	public static final String term_url = "TERMURL";
	
	public static final String avs_url = "AVS_URL";
	
	public static final String default_style_css = "STYLE_CSS";
	public static final String default_label_file = "LABEL_FILE";//Changes done by kavitha S for label propertie file on 5 Sep 2012	
	public static final String default_header_file = "HEADER_FILE";
	public static final String default_merchant_header_file = "MERCHANT_HEADER_FILE";//Added By Vinodhini T - For Separate merchant logo
	public static final String default_footer_file = "FOOTER_FILE";
	public static final String default_logo_file = "LOGO_FILE";
	public static final String default_js_file = "JS_FILE";
	
/**Direct Debit Start here **/
	
	//Added by Punitha - Table Rename
	public static final String tranlog_table="TRANLOG";
	public static final String tranlog_oldTranLog_table="OLD_TRANLOG";
	public static final String tranlog_tempTranlog_table="TEMP_TRANLOG";
	
	//KEK
	public static final String kek_alias_name = "KEK_ALIASNAME";
	
	//CARD NUMBER ENC
	public static final String iPay_key_store_location = "IPAY_KEY_STORE_LOCATION";
	public static final String iPay_key_store_pwd = "IPAY_KEY_STORE_PWD";
	public static final String iPay_alias_name = "IPAY_ALIASNAME";
	public static final String iPay_key_pwd = "IPAY_KEY_PASSWORD";
	public static final String iPay_pin_alias_name = "IPAY_PIN_ALIASNAME";
	public static final String iPay_keystore_type = "IPAY_KEY_STORE_TYPE";
	
	public static final String iPay_kek_keystore_file_name = "IPAY_KEK_KEY_STORE_FILE_NAME";
	public static final String iPay_dek_keystore_file_name = "IPAY_DEK_KEY_STORE_FILE_NAME";
	
	public static final String mail_smtp_host = "MAIL_SMTP_HOST";
	
	public static final String iPay_aggr_key_store_location = "IPAY_AGGR_KEY_STORE_LOCATION";
	public static final String iPay_aggr_key_store_pwd = "IPAY_AGGR_KEY_STORE_PASSWORD";
	
	public static final String iPay_inst_logo_temp_path = "IPAY_INSTLOGO_TEMP_PATH";
	public static final String iPay_inst_logo_width = "IPAY_INST_LOGO_WIDTH";
	public static final String iPay_inst_logo_height = "IPAY_INST_LOGO_HEIGHT";
	
	//Payment instrument constants
	public static final int pymntinstrmnt_active=1;
	public static final int pymntinstrmnt_inactive=0;
	/*public static final String pymntinstrmnt_credit="C";
	public static final String pymntinstrmnt_debit="D";
	public static final String pymntinstrmnt_storedvalue="S";
	public static final String pymntinstrmnt_3dsecure="V";*/
	
	public static final String payment_form_post="POST";
	public static final String payment_form_get="GET";
	public static final String payment_form_contenttype="application/x-www-form-urlencoded";
	public static final String payment_mrchresponse="REDIRECT=";
	
	public static final String payment_status_initialized="INITIALIZED";
	public static final String payment_status_presented="PRESENTED";
	public static final String payment_status_autherror="AUTH ERROR";
	public static final String payment_status_processed="PROCESSED";
	public static final String payment_status_canceled="CANCELED";
	public static final String payment_status_declined="DECLINED";
	
	//Added by Punitha A - Rupay 
	public static final String payment_status_not_processed="NOT PROCESSED";
	//End
	
	//Added for - Merchant Saved Card 
		public static final String pymnt_merchant_saved_card="Merchant_Saved_Card";
		public static final String pymnt_mrch_saved_card="Mrch_Saved_Card";
		public static final String pymnt_term_saved_card="Term_Saved_Card";
	//End
	public static final String payment_default_locale="en_US";
	
	public static final int payment_pin_atm=0;
	public static final int payment_pin_ecom=1;
	public static final int payment_pin_both=2;
	
	public static final int payment_yearstart=2000;
	public static final int payment_yearend=2049;
	
	public static final int pymnt_card_no_bin_length=10;
	
	public static final long payment_hashmap_period=1000000;// time in milli seconds
	public static final long payment_counter=100; // limit to clear the hash map
	
	public static final String pymnt_ntfy_yes="Y";
	public static final String pymnt_ntfy_no="N";
	
	public static final String pymnt_instrmnt_credit="C";
	public static final String pymnt_instrmnt_other_credit="OC";
	public static final String pymnt_instrmnt_other_debit="OD";
	public static final String rupay_brand_type = "RDC";
	//Prepaid
	public static final String pymnt_instrmnt_prepaid="P";
	//End
	/**Added by Karthikeyan S for Amex integration*/
	public static final String pymnt_instrmnt_amex="A"; 
	public static final String pymnt_instrmnt_debit="D";
	//Rupay
	public static final String pymnt_instrmnt_rupaydebit="RDC";
	//End
	
	public static final String pymnt_instrmnt_storedvalue="S";
	public static final String pymnt_instrmnt_vpas="V";
	public static final String pymnt_instrmnt_orgcont_vpas="VPAS";
	public static final String pymnt_instrmnt_ucaf="UCAF";
	public static final String pymnt_instrmnt_pindbt="PINDBT";
	public static final String pymnt_instrmnt_atmpay="ATMPAY";
	public static final String pymnt_instrmnt_directdebit="DD";
	
	public static final String pymnt_instrmnt_imps="IMPS";
	public static final int IMPS_MOBILE_NO_LENGTH=10;
	public static final int IMPS_MMID_LENGTH=7;
	public static final int IMPS_OTP_LENGTH=6;
	
	
	public static final int pymnt_tran_action_impspurchase = 17;
	
	/***/
	public static final String pymnt_card_no="CARDNUMBER"; // card no
	public static final String pymnt_card_bin="CARDBIN";
	public static final String pymnt_pin_no="PIN";						// card pin
	public static final String pymnt_cvv_no="CVV";						// cvv no
	public static final String pymnt_exp_str="EXPIRY_STR"; // card expiry month
	public static final String pymnt_exp_day="EXPIRY_DAY"; // card expiry month
	public static final String pymnt_exp_mnth="EXPIRY_MONTH"; // card expiry month
	public static final String pymnt_exp_yr="EXPIRY_YEAR"; // card expiry year
	/*Added By Vinodhini T - For SI Process	*/
	public static final String pymnt_cust_id="CUSTOMER_ID";
	public static final String card_encr_no="CARD_ENCR_NO";
	public static final String si_action="SI_ACTION";
	public static final String exp_date="EXP_DATE_HASHED";
	public static final String inst_si_flag="INST_SI_FLAG";
	public static final String term_si_flag="TERM_SI_FLAG";
	public static final String si_flg="SI_FLAG";
	public static final String si="SI";
	public static final String fail="fail";
	public static final String pass="pass";
	public static final String already_reg="ALREADY REGISTERED";
	public static final String not_reg="NOT REGISTERED";
	public static final String card_exist="CARDNUMBER ALREADY EXIST";
	public static final String term_miss_match="TERMINAL ID MISS MATCH";
	public static final String custid_miss_match="CUSTOMER ID DOES NOT EXIST";
	public static final String si_batch ="SIBATCH";
	/*Ends*/
	
	
	//Added By Pandiselvi A for Faster Checkout 
	public static final String fc_cust_id="CUSTOMER_ID";
	//End
	public static final String pymnt_pin_type="PIN_TYPE"; // if debit card, then pin type will show whether ATM PIN/ECOM PIN 
	public static final int pymnt_card_no_minlen=13; // card no min length
	public static final int pymnt_card_no_maxlen=19; // card no max length
	
	public static final String pymnt_exp_date="EXPIRY DATE";
	
	public static final String pymnt_imps_ben_mobile_no="BEN_MOB_NO"; 
	public static final String pymnt_imps_ben_mmid="BEN_MMID";				
	
	
	public static final String pymnt_imps_mobile_no="MOBILENUMBER"; // IMPS Mobile Number
	public static final String pymnt_imps_mmid="MMID";				// IMPS MMID
	public static final String pymnt_imps_otp="OTP";				// IMPS OTP
	
	public static final String pymnt_error_txn = "TRAN_ERROR_TXN";
		
	/***/
	
	/* Added by Priyadarshini R for IVR 3D*/
	public static final String pymnt_ivrFlag="IVR_3DFLAG";
	public static final String pymnt_ivr="IVR";
	public static final String pymnt_availauthchannal="AVAILABLE_AUTH_CHANNEL";
	public static final String pymnt_phoneid="PHONE_ID";
	public static final String pymnt_phoneidformat="PHONE_ID_FORMAT";
	public static final String pymnt_itpcredential="ITP_CREDENTIAL";
	public static final String pymnt_pareqchannel="PAREQ_CHANNEL";
	public static final String pymnt_shopChannel="SHOP_CHANNEL";
	public static final String pymnt_pareq="PAREQ";
	public static final String pymnt_paymentid="PAYMENT_ID";
	public static final String pymnt_acsurl="ACS_URL";
	public static final String pymnt_ivrPwdSts="IVR_PASSWORD_STATUS";
	public static final String pymnt_ivrPwd="IVR_PASSWORD";
	public static final String pymnt_itpauthTran="ITP_AUTHTRAN";
	public static final String pymnt_itpauthiden="ITP_AUTHIDENTIFIER";
	public static final String pymnt_stsYes="1";
	public static final String pymnt_reqType="POST";
	public static final String pymnt_contentType="application/x-www-form-urlencoded";
	public static final String pymnt_ivrProcess="PROCESS";
	public static final String pymnt_ivrhttp="HTTP";
	
	
	
	public static final String pymnt_purchaseamnt="PURCHASE_AMOUNT";
	public static final String pymnt_purchasecrrny="PURCHASE_CURRENCY";
	public static final String pymnt_purchaseexpo="PURCHASE_EXPONENT";
	public static final String pymnt_purchasedesc="PURCHASE_DESC";
	public static final String pymnt_merchantname="MERCHANT_NAME";	
	public static final String pymnt_pareqwaittime="PAREQ_WAITTIME";	
	
	
	public static final String BATCH_2FA_VERES_STATUS ="VERES - ENROLLMENT SUCCESSFUL";
	public static final String BATCH_2FA_VERES_IDENTIFIER ="VERES";
    public static final String BATCH_2FA_VERES_AUTH_STATUS ="VERES - NOT ENROLLED";
    public static final String BATCH_2FA_VERES_NOT_AUTH_STATUS ="VERES - AUTHENTICATION UN AVAILABLE";
    public static final String BATCH_2FA_PARES_NOT_AUTH_STATUS ="PARES - NOT AUTHENTICATED";
    public static final String BATCH_2FA_PARES_UNABLE_AUTH_STATUS ="PARES - UNABLE TO AUTHETICATE";
    public static final String BATCH_2FA_PARES_ATTEMPT_AUTH_STATUS ="PARES - AUTHENTICATION ATTEMPTED";
    public static final String BATCH_2FA_PAREQ_ACS_TIMEOUT ="PAREQ - ACS TIMEOUT";
    public static final String BATCH_2FA_HOST_SUCCESS_STATUS ="CAPTURED";
    public static final String BATCH_2FA_HOST_FAILURE_STATUS ="NOT CAPTURED";
    public static final int BATCH_2FA_OUTPUT_LENGTH = 150;
	
	
    public static final String loopback = "LOOPBACK";
	
	public static final String pymnt_tranportalId = "TRANPORTAL_ID";
	public static final String pymnt_recur_frequency = "PYMNT_RECUR_FREQUENCY";
	public static final String pymnt_recur_expiry = "PYMNT_RECUR_EXPIRY";
	public static final String pymnt_installments = "PYMNT_INSTALLMENTS";
	
	public static final String pymnt_crncy_cd="CRNCY_CODE";
	public static final String pymnt_default_crncy_cd="DEFAULT_CRNCY_CODE";
	public static final String pymnt_trnsc_actn="TRNSC_ACTION";
	public static final String pymnt_ecom_actn="ECOM_ACTION";
	public static final String pymnt_trnsc_amnt="TRNSC_AMOUNT";
	public static final String pymnt_usr_def_fld1 = "USR_DEF_FLD1";
	public static final String pymnt_usr_def_fld2 = "USR_DEF_FLD2";
	public static final String pymnt_usr_def_fld3 = "USR_DEF_FLD3";
	public static final String pymnt_usr_def_fld4 = "USR_DEF_FLD4";
	public static final String pymnt_usr_def_fld5 = "USR_DEF_FLD5";
	public static final String pymnt_lang_id = "LANG_ID";
	public static final String pymnt_payment_id_str = "PaymentID";
	public static final String pymnt_seqnum_id_str = "SeqNum";
	public static final String pymnt_track_id_str = "TrackID";
	public static final String pymnt_orig_trnscid = "ORIGINAL_TRANSACTION_ID";
	public static final String pymnt_maestro_orig_trnscid = "MAESTRO_ORIGINAL_TRAN_ID";
	//public static final String pymnt_orig_trnsc_amnt = "ORIGINAL_TRANSACTION_AMOUNT";
	public static final String pymnt_ref_trnscid = "REF_TRANSACTION_ID";
	public static final String pymnt_inst_id = "INSTID";
	public static final String pymnt_KeyStore_Pwd = "KEYSTOREPWD";
	public static final String pymnt_mrch_id = "MRCHID";
	public static final String pymnt_term_id = "TERMID";
	public static final String pymnt_mrchtrck_id = "MRCHTRACKID";
	public static final String pymnt_tran_id = "TRANID";
	public static final String pymnt_brnd_id = "BRNDID";
	public static final String pymnt_brnd_type = "BRAND_TYPE";
	public static final String pymnt_brnd_auth_type = "BRAND_AUTH_TYPE";
	public static final String pymnt_brnd_tran_type = "TRANSACTION_TYPE";
	public static final String pymnt_tran_ref = "TRAN_REF";
	public static final int pymnt_tran_action_purchase= 1;
	public static final int pymnt_tran_action_auth = 4;
	public static final int pymnt_tran_action_inquiry = 8;
	public static final int pymnt_tran_action_blnc_inquiry = 10;
	public static final int pymnt_tran_action_replenishment = 11;
	public static final int pymnt_tran_action_voidreplenishment = 12;
	public static final int pymnt_tran_action_credit = 2;
	public static final int pymnt_tran_action_voidpurchase = 3;
	public static final int pymnt_tran_action_capture = 5;
	public static final int pymnt_tran_action_voidcredit = 6;
	public static final int pymnt_tran_action_voidcapture = 7;
	public static final int pymnt_tran_action_voidauth = 9;	
	
	//Added By Kaliappan.J for OTP : Starts
	public static final int pymnt_tran_action_profile = 15;
	//Added By Kaliappan.J for OTP : Ends
	public static final String pymnt_id = "Payment_Id";
	public static final String pymnt_crncy_minor_digits = "CRNCY_MINOR_DIGITS";
	public static final String pymnt_crncy_symbol = "CRNCY_SYMBOL";
	public static final String pymnt_card_postal_code = "CARD_POSTAL_CODE";
	public static final String pymnt_card_address = "CARD_ADDRESS";
	public static final String pymnt_card_name = "CARD_NAME";
	
	public static final String pymnt_card_state = "CARD_STATE";
	public static final String pymnt_card_city = "CARD_CITY";
	public static final String pymnt_terminal_card_info_flg = "CARD_INFO_FLAG";
	public static final String pymnt_terminal_instrmnt_list = "TERMINAL_INSTRUMENT_LIST";
	public static final String pymnt_terminal_instrmnt_form = "TERMINAL_INSTRUMENT_FORM";
	public static final String pymnt_terminal_brand_list = "TERMINAL_BRAND_LIST";
	public static final String pymnt_terminal_action_list = "TERMINAL_ACTION_LIST";
	public static final String pymnt_terminal_crncy_list = "TERMINAL_CRNCY_LIST";
	public static final String pymnt_terminal_options_list = "TERMINAL_OPTIONS_LIST";
	public static final String pymnt_terminal_avs_list = "TERMINAL_AVS_LIST";
	public static final String pymnt_terminal_status = "TERMINAL_STATUS";
	public static final String pymnt_terminal_risk_flg = "TERMINAL_RISK_FLAG";
	public static final String pymnt_terminal_risk_check = "TERMINAL_RISK_CHECK";
	public static final String pymnt_terminal_risk_error = "TERMINAL_RISK_ERROR";
	public static final String pymnt_terminal_risk_profile_id = "TERMINAL_RISK_PROFILE_ID";
	public static final String pymnt_terminal_settlement_hr = "TERMINAL_SETTLEMENT_HR";
	public static final String pymnt_terminal_settlement_mn = "TERMINAL_SETTLEMENT_MN";
	public static final String pymnt_terminal_extrconnid = "EXTERNAL_CONNECTION_ID";
	public static final String pymnt_terminal_feeid = "FEE_ID";
	public static final String pymnt_terminal_merchant_acquirer = "MERCHANT_ACQUIRER";
	public static final String pymnt_terminal_merchant_acceptor_term = "MERCHANT_ACCEPTOR_TERM";
	public static final String pymnt_terminal_merchant_acceptor = "MERCHANT_ACCEPTOR";
	public static final String pymnt_terminal_merchant_b24_term_data = "MERCHANT_B24_TERM_DATA";
	public static final String pymnt_terminal_merchant_category_code = "MERCHANT_CATEGORY_CODE";
	public static final String pymnt_terminal_merchant_b24_id = "MERCHANT_B24_ID";
	public static final String pymnt_terminal_merchant_b24_group = "MERCHANT_B24_GROUP";
	public static final String pymnt_terminal_merchant_b24_region = "MERCHANT_B24_REGION";
	/** Setting  Time Out for Vreq & merchant notification in Terminal  : Sunil  06/03/2012*/
	public static final String pymnt_terminal_vPasTimeOutFlag="VPAS_TIMEOUT_FLAG";
    public static final String pymnt_terminal_merchTimeOutFlag="MERCH_TIMEOUT_FLAG";
    public static final String pymnt_terminal_vPasConnTimeOut="VPAS_CONN_TIMEOUT";
    public static final String pymnt_terminal_vPasReadTimeOut="VPAS_READ_TIMEOUT"; 
    public static final String pymnt_terminal_merchConnTimeOut="MERCH_CONN_TIMEOUT";
    public static final String pymnt_terminal_merchReadTimeOut="MERCH_READ_TIMEOUT";
    public static final String pymnt_terminal_merchnotificationflag="MERCH_NOTIFICATION_FLAG";
    
    /*Added for PreAuthenticated Transaction by Pandiselvi A*/
    public static final String pymnt_terminal_preauthflag="TERM_PREAUTH_FLAG";
    public static final String pymnt_inst_preauthflag="INST_PREAUTH_FLAG";
    /*End*/
    
    /*Added for PreAuthenticated Transaction by Pandiselvi A*/
    public static final String pymnt_terminal_fc_flg="TERM_FC_FLAG";
    public static final String pymnt_inst_fc_flg="INST_FC_FLAG";
    /*End*/

    public static final String pymnt_terminal_key = "TERMINAL_RESOURCE_KEY";
    public static final String pymnt_terminal_iv = "TERMINAL_RESOURCE_IV";
    public static final String pymnt_trandat_enc = "TRANDATA_ENC";
    public static final String pymnt_terminal_invalid_tran_login_attempt = "INVALID_TRANPORTAL_LOGIN_ATTEMPT";
    public static final String pymnt_terminal_tran_pswd_last_changed = "TRANPORTAL_PASSWORD_LAST_CHANGED";
    public static final String pymnt_terminal_tran_pswd_hash = "TRANPORTAL_PASSWORD_HASHED";
    public static final String pymnt_terminal_tran_pswd = "TRANPORTAL_PASSWORD";
    public static final String pymnt_terminal_lockout_date = "LOCKOUT_DATE";
    public static final String pymnt_terminal_ivr_flag = "TERMINAL_IVR_FLAG";
    public static final String pymnt_terminal_inquiry_flag= "TERMINAL_INQUIRY_FLAG";
     
    public static final String pymnt_inst_hashing_flag = "INST_HASHING_FLAG";
    public static final String pymnt_inst_ivr_flag = "INST_IVR_FLAG";
    public static final String pymnt_inst_ip_block_flag = "IP_BLOCK_FLAG";
    public static final String pymnt_inst_portal_domain = "PORTAL_DOMAIN";
       
    public static final String pymnt_mrch_hashing_flag = "MERCHAT_HASHING_FLAG";
     
    public static final String pymnt_terminal_impsFlag="IMPS_FLAG";
    
	public static final String pymnt_common_instrmnt_list = "COMMON_INSTRUMENT_LIST";
	public static final String pymnt_user_instrmnt = "USER_INSTRUMENT";
	public static final String pymnt_pymnt_instrmnt = "PAYMENT_INSTRUMENT";
	public static final String pymnt_instrmnt_list = "INTRUMENT_LIST";
	public static final String pymnt_reqr_cvd2_flg = "REQUIRE_CVD2_FLAG";
	public static final String pymnt_cvd2_flg_instbased = "INST_CVD2_FLAG";
	public static final String pymnt_response_code = "RESPONSE_CODE";
	public static final String pymnt_result_code = "RESULT_CODE";
	public static final String pymnt_tran_description = "TRAN_DESC";
	public static final String pymnt_tran_description_IVR = "TRAN_DESC_IVR";
	public static final String pymnt_result_code_captured = "CAPTURED";
	public static final String pymnt_result_code_approved = "APPROVED";
	public static final String pymnt_result_code_processed = "PROCESSED";
	public static final String pymnt_result_code_voided = "VOIDED";
	public static final String pymnt_result_code_notcaptured = "NOT CAPTURED";
	public static final String pymnt_result_code_notapproved = "NOT APPROVED";
	public static final String pymnt_result_code_notprocessed = "NOT PROCESSED";
	public static final String pymnt_result_code_notvoided = "NOT VOIDED";
	public static final String pymnt_result_code_failedavs = "FAILED AVS";
	public static final String pymnt_result_code_denied_by_risk = "DENIED BY RISK";
	public static final String pymnt_default_inst_conf = "DEFAULT_INST_CONF";
	public static final String pymnt_settlement_batch_date = "SETTLEMENT_BATCH _DATE";
	public static final String pymnt_inst_servicecharge_flg = "SERVICE_CHARGE_FLAG";
	public static final String pymnt_inst_fixedcharge = "FIXED_CHARGE";
	public static final String pymnt_inst_variablecharge = "VARIABLE_CHARGE";
	public static final String redirect = "redirect:http://localhost/";
	public static final String pymnt_b24_pos_entry_mode = "B24_POS_ENTRY_MODE";
	public static final String pymnt_b24_batch_data = "B24_BATCH_DATA";
	public static final String pymnt_b24_settlement_data = "B24_SETTLEMENT_DATA";
	public static final String pymnt_b24_preauth_data = "B24_PREAUTH_DATA";
	public static final String pymnt_b24_receiving_institution = "B24_RECEIVING_INSTITUTION";
	public static final String pymnt_auth_stan_id = "AUTH_STAN_ID";
	public static final String pymnt_mrch_name = "MERCHANT_NAME";
	public static final String pymnt_mrch_city = "MERCHANT_CITY";
	public static final String pymnt_mrch_state = "MERCHANT_STATE";
	public static final String pymnt_mrch_country = "MERCHANT_COUNTRY";
	public static final String pymnt_mrch_iso_country = "MERCHANT_ISO_COUNTRY";
	public static final String pymnt_mrch_web_address = "MERCHANT_WEB_ADDRESS";
	public static final String pymnt_mrch_phonNo = "MERCHANT_PHONE_NO";
	public static final String pymnt_mrch_zipCode = "MERCHANT_ZIP_CODE";
	public static final String pymnt_mrch_accept_category = "ACCEPT_MERCHANT_CATG";
	
	public static final String pymnt_tranPwd ="PASSWORD";
	public static final String pymnt_card_zip= "ZIP";
	//public static final String tran_xid="XID";
	public static final String ext_req_byte="EXTERNAL_REQUEST_BYTE";
	public static final String source_ip_str="SOURCE_IP";
	public static final String pymnt_auth_code = "AUTH_CODE";
	public static final String card_balance_str = "CARD_BALANCE";
	public static final String address_verification_code = "ADDRESS_VERFICATION_CODE";
	public static final String post_date = "POST_DATE";
	public static final String host_tranid = "HOST_TRANID";
	
	
	public static final int pymnt_cvd_yes = 1;
	public static final int pymnt_cvd_no = 0;
	
	public static final String pymnt_chargeback_flg = "CHARGEBACK_FLAG";
	public static final int pymnt_chargeback_yes = 1;
	public static final int pymnt_chargeback_no = 0;
	public static final String pymnt_mrch_error_page = "MERCHANT_ERROR_PAGE";
	
	public static final String pymnt_brndrules_d_checkdigit_flg = "D_CHECK_DIGIT_FLAG";
	public static final String pymnt_brndrules_d_exprvrfy_flg = "D_EXPIRY_VERIFY_FLAG";
	public static final String pymnt_brndrules_d_adrsvrfy_flg = "D_ADDRESS_VERIFY_FLAG";
	public static final String pymnt_brndrules_d_cardvrfy_flg = "D_CARD_VERIFY_FLAG";
	public static final String pymnt_brndrules_d_pindebit_flg = "D_PIN_DEBIT_FLAG";
	
	//Rupay Debit Card Brand Rules - Added by Punitha A
	public static final String pymnt_brndrules_rdc_checkdigit_flg = "RDC_CHECK_DIGIT_FLAG";
	public static final String pymnt_brndrules_rdc_exprvrfy_flg = "RDC_EXPIRY_VERIFY_FLAG";
	public static final String pymnt_brndrules_rdc_adrsvrfy_flg = "RDC_ADDRESS_VERIFY_FLAG";
	public static final String pymnt_brndrules_rdc_cardvrfy_flg = "RDC_CARD_VERIFY_FLAG";
	public static final String pymnt_brndrules_rdc_pindebit_flg = "RDC_PIN_DEBIT_FLAG";
	//End
	
	public static final String pymnt_brndrules_c_checkdigit_flg = "C_CHECK_DIGIT_FLAG";
	public static final String pymnt_brndrules_c_exprvrfy_flg = "C_EXPIRY_VERIFY_FLAG";
	public static final String pymnt_brndrules_c_adrsvrfy_flg = "C_ADDRESS_VERIFY_FLAG";
	public static final String pymnt_brndrules_c_cardvrfy_flg = "C_CARD_VERIFY_FLAG";
	public static final String pymnt_brndrules_c_pindebit_flg = "C_PIN_DEBIT_FLAG";
	
	public static final String pymnt_brndrules_v_checkdigit_flg = "V_CHECK_DIGIT_FLAG";
	public static final String pymnt_brndrules_v_exprvrfy_flg = "V_EXPIRY_VERIFY_FLAG";
	public static final String pymnt_brndrules_v_adrsvrfy_flg = "V_ADDRESS_VERIFY_FLAG";
	public static final String pymnt_brndrules_v_cardvrfy_flg = "V_CARD_VERIFY_FLAG";
	public static final String pymnt_brndrules_v_pindebit_flg = "V_PIN_DEBIT_FLAG";
	public static final String pymnt_card_participation_cache = "CARD_PARTICIPATION_CACHE";
	public static final String pymnt_brndrules_data = "BRAND_RULES_DATA";
	
	public static final String pymnt_host_token = "HOST_TOKEN";
	//Added By Pandiselvi A
	public static final String pymnt_host_pur_ref_id = "HOST_PUR_REF_ID";
	//End
	//public static final String pymnt_authentication_token_response = "AUTH_TOKEN_RESPONSE";
	public static final String pymnt_authentication_token = "AUTH_TOKEN";
	//public static final String pymnt_xid = "XID";
	public static final String pymnt_ucaf_auth_data = "UCAF_AUTH_DATA";
	public static final String pymnt_auth_token_enc_data = "AUTH_TOKEN_ENC";
	public static final String pymnt_id_expired = "PAYMENT_ID_EXPIRED";
	
	public static final int pymnt_brandrules_flg_yes = 1;
	public static final int pymnt_brandrules_flg_no = 0;
	
	public static final String pymnt_brndtype_visa = "V";
	public static final String pymnt_brndtype_mastercard = "M";
	public static final String pymnt_brndtype_dinersclub = "D";	// Brand Type Symbol as D for Diners Club Card
	
	public static final String pymnt_result_code_hosttimeout = "HOST TIMEOUT";
	public static final String pymnt_remote_ip_address = "REMOTE_IP_ADDRESS";
	public static final String pymnt_request_sent_time = "REQUEST_SENT_TIME";
	public static final String pymnt_request_rcvd_time = "REQUEST_RCVD_TIME";
	public static final String pymnt_response_rcvd_time = "RESPONSE_RCVD_TIME";
	public static final String pymnt_response_sent_time = "RESPONSE_SENT_TIME";
	public static final String pymnt_host_tranid = "HOST_TRAN_ID";
	
	public static final String pymnt_init_time = "PYMT_INIT_TIME";
	
	/**
	 * Added by Vijayarumugam for Tran_set_id logging in Tranlog
	 */
	public static final String pymnt_tran_set_id = "TRAN_SET_ID";
	
	public static final String pymnt_batch_id = "BATCH_ID";
	public static final String pymnt_batch_filepostion = "filePosition";
	public static final String pymnt_post_date = "POST_DATE";
	
	
	public static final String pymnt_auth_token_response = "AUTH_TOKEN_RESPONSE";
	public static final String pymnt_data_encrypt_key_name = "DATA_ENCRYPT_KEY_NAME";
	public static final String pymnt_data_encrypt_enc_name = "DATA_ENCRYPT_ENC_NAME";
	public static final String pymnt_xid_encyrpt_code = "XID_ENC_CODE";
	public static final String pymnt_card_vrfy_rsp_cd = "CARD_VERIFY_RESP_CODE";
	public static final String pymnt_risk_rsp_actn_cd = "RISK_RESP_ACTN_CODE";
	public static final int pymnt_risk_rsp_actn_cd_1 = 1;
	public static final int pymnt_risk_rsp_actn_cd_2 = 2;
	
	public static final String pymnt_inst_direct_debit_flg = "DIRECT_DEBIT_FLAG";
	public static final String pymnt_inst_ecom_flg = "INST_ECOM_FLAG";
	
	public static final String pymnt_inst_dd_conn_timeout = "DD_CONN_TIMEOUT";
	public static final String pymnt_inst_dd_read_timeout = "DD_READ_TIMEOUT";
	
	public static final String pymnt_mrch_view_hldr_flg = "VIEW_HOLDER_FLAG";
	
	public static final int pymnt_negative_card_status_active=1;
	public static final int pymnt_declined_card_status_active=1;
	public static final String pymnt_inst_direct_debit_url = "DIRECT_DEBIT_URL";
	public static final String pymnt_inst_direct_debit_inquiry_url = "DIRECT_DEBIT_INQUIRY_URL";
	public static final String pymnt_inst_direct_debit_prefix = "DIRECT_DEBIT_PREFIX";
	public static final String pymnt_inst_data_enc_key = "DATA_ENCRYPTION_KEY";
	public static final String pymnt_action_inquiry = "inqy";
	
	/**
	 * Added for PRM
	 */
	public static final String pymnt_inst_prm = "PRM_FLAG";
	public static final int pymnt_inst_prmflg_active = 1;
	public static final int pymnt_inst_prmflg_inactive = 0;

	public static final String pymnt_inst_impsflag = "INST_IMPS_FLAG";
	
	public static final String maestro_brand_type = "MA";
	public static final String maestro_brand_presented = "YES";
	public static final String maestro_brand_not_presented = "NO";
	public static final String maestro_brand_invalid = "INVALID BRAND";
	public static final String maestro_brand_decline = "DECLINE";
			
	public static final String pymnt_mrch_errorstr = "null&ErrorText=";
	
	
	public static final String  pymnt_orig_AuthCode = "ORIGINAL_AUTH_CODE";
	public static final String  pymnt_orig_RespCode = "ORIGINAL_RESPONSE_CODE";

	
	public static final String pymnt_orig_tran_data = "ORIGINAL_TRANSACTION_DATA";
	
	public static final String pymnt_processingoption_actioncode="PRCS_OPTN_ACTN_CD";
	public static final String pymnt_processingoption_actioncode_list="PRCS_OPTN_ACTN_CD_LIST";
	
	public static final String pymnt_unique_message_id="UNIQUE_MESSAGE_ID";
	
	public static final String pymnt_result_code_noresult = "NO RESULT";
	//Added by Suguna
	
	public static String atm_notPaid = "001";
	public static String atm_confirm_sts = "Y";

	public static String masterSchemaPropLocation = "SCHEMA_PROPERTIES_LOCATION";
	
	
	//3D Secure constants
	public static final String pymnt_3d_map = "map";
	public static final String pymnt_pares_details = "PaymentPAResDetails";
	public static final String pymnt_3d_pareq = "PAReq";
	public static final String pymnt_3d_flag = "3DFLAG";
	public static final String pymnt_3d_enrolled_yes = "Y";
	public static final String pymnt_3d_enrolled_no = "N";
	public static final String pymnt_3d_eci = "eci";
	public static final String pymnt_3d_ucaf = "UCAF";
	public static final String pymnt_3dsecure_authentication = "SECURE_AUTHENTICATION";
	
	//VPAS VEReq
	public static final String  webserver_tranportal_tcpip = "WEBSERVER_TRANPORTAL_TCPIP";
	public static final String  webserver_tranportal_http = "WEBSERVER_TRANPORTAL_HTTP";
	public static final String  webserver_hosted_http = "WEBSERVER_HOSTED_HTTP";
	public static final String  pymnt_selected_instrument = "SELECTED_PYMNT_INSTRUMENT";
	public static final String  pymnt_3d_vereq_data = "VEREQXML";
	public static final String  pymnt_3d_vereq_message_id = "VEREQ_MESSAGE_ID";
	public static final String  pymnt_3d_veres_data = "VERESXML";
	public static final String  pymnt_3d_directory_url = "directoryURL";
	public static final String  pymnt_3d_payment_id = "paymentId";
	public static final String  pymnt_3d_veres_detail = "VEResDetails";
	
	public static final String  pymnt_merchant_notify_object = "merchantNotifyObject";
	public static final String  pymnt_response_data = "responseData";
	public static final String  pymnt_merchant_response_url = "merchantResponseURL";
	public static final String  pymnt_merchant_error_url = "merchantErrorURL";
	public static final String  pymnt_merchant_notify_flag = "notifyFlag";
	public static final String  pymnt_merchant_notify_url = "notifyResponseURL";
	public static final String  pymnt_merchant_paymentid = "paymentId";
	public static final String  pymnt_3d_encoded_payment_data = "encodedPaymentData";
	public static final String  pymnt_3d_encoded_vereq_data = "encodedVEREQData";
	public static final String  pymnt_3d_webserver_hosted_url = "webserverHosted3DURL";
	public static final String  pymnt_3d_webserver_notify_url = "webserverNotifyURL";
	public static final String  pymnt_3d_payment_response_url = "paymentResponseURL";
	public static final String  pymnt_3d_payment_brand_type = "brandType";
	public static final String  pymnt_3d_payment_txn_type = "txnType";
	
	public static final String  pymnt_3d_id = "id";
	public static final String  pymnt_3d_vereq_id = "vereq_id";
	public static final String  pymnt_3d_version = "version";
	public static final String  pymnt_3d_iReqCode = "iReqCode";
	public static final String  pymnt_3d_iReqDetail = "iReqDetail";
	public static final String  pymnt_3d_Extension = "Extension";
	public static final String  pymnt_3d_protocol = "protocol";
	public static final String  pymnt_3d_url = "url";
	public static final String  pymnt_3d_acctID = "acctID";
	public static final String  pymnt_3d_enrolled = "enrolled";
	public static final String  pymnt_3d_vereq_senttime = "vereq_sent_time";
	
	// Added by Priyadarshini R for IVR 3D
	public static final String  pymnt_3d_npc356authdata = "npc356authdata";
	public static final String  pymnt_3d_npc356authdataencrypt_mandatory  = "mandatory";
	public static final String  pymnt_3d_npc356authdataencrypttype  = "npc356authdataencrypttype";
	public static final String  pymnt_3d_npc356authdataencryptkeyvalue  = "npc356authdataencryptkeyvalue";
	public static final String  pymnt_3d_name  = "name";
	public static final String  pymnt_3d_length  = "length";
	public static final String  pymnt_3d_type  = "type";
	public static final String  pymnt_3d_label  = "label";
	public static final String  pymnt_3d_prompt  = "prompt";
	public static final String  pymnt_3d_npc356authstatusmessage  = "npc356authstatusmessage";
	public static final String  pymnt_3d_npc356itpstatus  = "npc356itpstatus";
	public static final String pymnt_3d_enc_ivr_pwd_str = "EncrytedIVRPassword";
	public static final String  pymnt_3d_merName= "merName";
	public static final String  pymnt_3d_country= "country";
	public static final String  pymnt_3d_amt= "Amount";
	public static final String  pymnt_3d_expiry = "expiry";
	public static final String  pymnt_3d_exid = "extensionid";
	public static final String  pymnt_3d_pares_exid = "pares_extensionid";
	public static final String  pymnt_3d_excritical = "critical";
	public static final String  pymnt_3d_pares_excritical = "pares_critical";
	
		
	
	//VPAS PARes
	public static final String pymnt_3d_paresid = "pares_id";
	public static final String pymnt_3d_paresmap = "PAResmap";
	public static final String pymnt_3d_pares = "PaRes";
	public static final String  pymnt_3d_md= "MD";
	public static final String  pymnt_3d_acqBIN= "acqBIN";
	public static final String  pymnt_3d_merID= "merID";
	public static final String  pymnt_3d_xid= "xid";
	public static final String  pymnt_3d_date= "date";
	public static final String  pymnt_3d_purchAmount= "purchAmount";
	public static final String  pymnt_3d_currency= "currency";
	public static final String  pymnt_3d_exponent= "exponent";
	public static final String  pymnt_3d_pan= "pan";
	public static final String  pymnt_3d_time= "time";
	public static final String  pymnt_3d_status= "status";
	public static final String  pymnt_3d_cavv= "cavv";
	public static final String  pymnt_3d_cavvAlgorithm= "cavvAlgorithm";
	public static final String  pymnt_3d_DigestValue= "DigestValue";
	public static final String  pymnt_3d_SignatureValue= "SignatureValue";
	public static final String  pymnt_3d_X509Certificate= "X509Certificate";
	public static final String  pymnt_3d_Reference= "Reference";
	public static final String  pymnt_3d_Signature= "Signature";
	public static final String  pymnt_3d_SignedInfo= "SignedInfo";
	public static final String  pymnt_3d_CanonicalizationMethod= "CanonicalizationMethod";
	public static final String  pymnt_3d_SignatureMethod= "SignatureMethod";
	public static final String  pymnt_3d_DigestMethod= "DigestMethod";
	public static final String  pymnt_3d_PARes_Failed= "Failed";
	
	
	//VPAS Error
	public static final String pymnt_3d_errorCode = "errorCode";
	public static final String pymnt_3d_errorMessage = "errorMessage";
	public static final String pymnt_3d_errorDetail = "errorDetail";
	public static final String pymnt_3d_vendorCode = "vendorCode";
	public static final String pymnt_3d_err_code = "error";
	
	//AVS
	public static final String avs_result_o = "O";
	public static final String avs_result_a = "A";
	public static final String avs_result_e = "E";
	public static final String avs_result_n = "N";
	public static final String avs_result_r = "R";
	public static final String avs_result_s = "S";
	public static final String avs_result_u = "U";
	public static final String avs_result_w = "W";
	public static final String avs_result_x = "X";
	public static final String avs_result_y = "Y";
	public static final String avs_result_z = "Z";
	
	public static final String pymnt_fee_type_fixed = "F";
	public static final String pymnt_fee_type_variable = "V";
	
	public static final int pymnt_fee_criteria_1 = 1; // Yearly
	public static final int pymnt_fee_criteria_2 = 2; //Monthly
	public static final int pymnt_fee_criteria_3 = 3; // Quarterly
	public static final int pymnt_fee_criteria_4 = 4; // One time
	public static final int pymnt_fee_criteria_5 = 5; // Per transaction
	public static final int pymnt_fee_criteria_6 = 6; // Percentage
	public static final int pymnt_fee_criteria_7 = 7; // Transaction count
	public static final int pymnt_fee_criteria_8 = 8; // Action code
	
	
	public static final String new_pin = "NEW_ECOM_PIN";
	public static final String old_pin = "OLD_ECOM_PIN";
	public static final String confirm_pin = "CONFIRM_PIN";
	public static final String ecom_tran1 = "R";
	public static final String ecom_tran2= "DR";
	public static final String ecom_tran3= "FP";
	public static final String ecom_tran4= "CP";
	public static final String ecom_action = "ECOM_ACTION";
	public static final String ecom_register = "13";
	public static final String ecom_pin_change = "14";
	public static final String ecom_forgot_pin = "15";
	public static final String ecom_deregister = "16";
	public static final String ecom_element_RD = "E10000";
	public static final String ecom_element_FC = "E40000";
	public static final String ecom_s123_register = "FSSPGWRE";
	public static final String ecom_s123_dregister = "FSSPGWDR";
	public static final String ecom_s123_pinchange = "FSSPGWPC";
	public static final String ecom_s123_fpin = "FSSPGWFP";
	public static final int ecom_pin_length =30;
	public static final int ecom_old_pinlength=28;
	public static final String ecom_flag_yes ="Y";
	public static final String ecom_flag_no ="N";
	public static final String ecom_msg = "ECOM_RESPONSE";
	
	public static final String pymnt_m24_station_primary = "PRIMARY_M24_STATION";
	public static final String pymnt_m24_station_alternate = "ALTERNATE_M24_STATION";
	
	public static final String pymnt_pin_type_atm = "A";
	public static final String pymnt_pin_type_ecom = "E";
	
	public static final String pymnt_tranDateTime = "tranDateTime";
	
	public static final String pymnt_is_ecom_trxn = "IS_ECOM_TRNXN";
	public static final String pymnt_is_ecom_trxn_yes = "YES";
	public static final String pymnt_is_ecom_trxn_no = "NO";
	
	public static final String pymnt_extr_conn_tran_type = "EXTR_CONN_TRAN_TYPE";
	/*
	 * Added By Vinodhini.T - For Visa,Master Config
	 */
	public static final String pymnt_extr_conn_auth_entity="AUTH_ENTITY";
	public static final String pymnt_extr_conn_auth_type="AUTH_TYPE";
	/*Ends*/
		
	public static final String pymnt_b24_extr_conn_prm = "B24_EXTR_CONN_PRIMARY";
	public static final String pymnt_b24_extr_conn_alt = "B24_EXTR_CONN_ALTERNATE";
	
	public static final String trxn_unique_id = "TRXN_UNIQUE_ID";
	
	
	public static final String action_code_purchase = "Purchase";
	public static final String action_code_credit = "Credit";
	public static final String action_code_void_purchase = "Void Purchase";
	public static final String action_code_auth = "Auth";
	public static final String action_code_capture = "Capture";
	public static final String action_code_void_credit = "Void Credit";
	public static final String action_code_void_capture = "Void Capture";
	public static final String action_code_inquiry = "Inquiry";
	public static final String action_code_void_auth = "Void Auth";
	public static final String action_code_ecom_change_pwd = "Ecom change password";
	public static final String action_code_ecom_de_registration = "Ecom De Registration";
	public static final String action_code_ecom_registration = "Ecom Registrations";
	public static final String action_code_ecom_reg = "Ecom reg";
	public static final String action_code_ecom_forget_pwd = "Ecom Forget Password";
	public static final String action_code_imps = "IMPS";
	

	/** Card, Terminal & Risk Setting */	
	public static final String risk_profile_cardtrxndrtn="CARD_TRXN_DRTN";
	public static final String risk_profile_termtrxndrtn="TERM_TRXN_DRTN";
	public static final String risk_profile_iptrxndrtn="IP_TRXN_DRTN";
	public static final String risk_profile_iptrxncnt="IP_TRXN_CNT";
	public static final String risk_profile_ipaddress="REMOTE_ADDRESS";
	
	public static final String rspcode_05="Do not approve";
	public static final String rspcode_41="Lost or stolen card (cap)";
	public static final String rspcode_59="Suspect fraud";
	public static final String rspcode_62="Restricted card";
	public static final String rspcode_65="Exceeds withdrawal uses";
	
	/** Card, Terminal & Risk Setting */
	
	/** Direct Debit Prefix Starts **/
	//Added By Kaliappan.J for NetBanking : Starts
	public static final String dd_prefix_abk="IBAB";
	public static final String dd_prefix_ibk="IBIB";
	public static final String dd_prefix_iob="IBIO";
	public static final String dd_prefix_ubi="IBUB";
	//Added By Kaliappan.J for NetBanking : Ends
	
	/*public static final String dd_prefix_abk="DDABK";
	public static final String dd_prefix_ibk="DDIBK";
	public static final String dd_prefix_iob="DDIOB";
	public static final String dd_prefix_ubi="DDUBI";*/
	/** Direct Debit Prefix Ends **/
	
	/**Pagination Information Starts**/
	public static final String ItemsPerPage = "ITEMSPERPAGE";
	public static final String pagesPerSet = "PAGESPERSET";
	/** Pagination Information Ends **/
	
	/** Maestro batch Type start **/
	public static final String maestro_batch= "MAESTROBATCH";
	public static final String maestro_batch_value= "Y";
	public static final String pymnt_temp_orig_trnscid = "TEMP_ORIGINAL_TRANSACTION_ID";
	public static final String maestro_refund_mrch_catgyCode = "MAESTROREFUNDMRCHCODE";
	public static final String maestro_pymnt_mrch_name ="MAESTRO_MERCHANT_NAME";
	public static final String maestro_pymnt_mrch_city ="MAESTRO_MERCHANT_CITY";
	public static final String maestro_pymnt_mrch_state ="MAESTRO_MERCHANT_STATE";
	public static final String maestro_pymnt_mrch_country ="MAESTRO_MERCHANT_COUNTRY";
	
	/** Maestro batch Type end **/
	
	/** Reports */
	public static String email_from_address = "REPORT_EMAIL_FROM_ADDRESS";
	public static String report_temp_location = "REPORT_TEMP_FOLDER_PATH";
	public static String rupay_report_download_location = "RUPAY_REPORT_DOWNLOAD_FOLDER_PATH";
	public static String max_no_of_recs = "DYNA_REP_MAX_REC_COUNT";
	
		
	/**Direct Debit Start here **/
	
	
	public static String directDebit_RU = "/directdebit.htm?actionparam=bankResponse&";
	
	//	Added for IPAYV3 Issues
	public static Boolean eventLog_trace_flag_enabled;
	public static Boolean eventLog_transaction_flag_enabled;
	public static Boolean trace_managerlog_flag_enabled;
	public static final int event_manager_log_priority = 1;
	//	Added for IPAYV3 Issues
	
	public static Boolean log_trace_flag_enabled;
	public static Boolean log_transaction_flag_enabled;
	public static int log_nothing = 0;
	public static int log_transaction_info = 1;
	
	public static Boolean agg_log_trace_flag_enabled;
	public static Boolean agg_log_transaction_flag_enabled;
	public static int agg_log_nothing = 0;
	public static int agg_log_transaction_info = 1;

	
	/** For Amex Integration starts here*/
	
	public static final String amex_payment_status_Authenticated="AUTHENTICATED";
	public static final String amex_payment_status_Authenticated_error="AUTHENTICATION ERROR";
	public static final String amex_payment_status_Authenticated_not_available="AUTHENTICATION NOT AVAILABLE";
	public static final String amex_payment_status_Authorized="AUTHORIZD";
	public static final String amex_payment_status_Captured="CAPTURED";
	public static final String payment_status_capterror="CAPTURE ERROR";
	public static final String amex_payment_status_auth_error="AUTH ERROR";
	public static final String amex_payment_status_refund="REFUNDED";
	public static final String payment_status_refund_error="REFUND ERROR";
	public static final String pymnt_customer_firstname = "CUSTOMER_FIRST_NAME";
	public static final String pymnt_customer_lastname = "CUSTOMER_LAST_NAME";
	public static final String pymnt_customer_mobilenum = "CUSTOMER_MOBILE_NUM";
	public static final String pymnt_customer_zipcode= "CUSTOMER_ZIP_CODE";
	public static final String pymnt_customer_addr= "CUSTOMER_ADDRESS";
	public static final String pymnt_customer_email = "CUSTOMER_EMAIL";
	public static final String amex_vpc_Version = "vpc_Version";
	public static final String amex_vpc_Command = "vpc_Command";
	public static final String amex_vpc_Merchant = "vpc_Merchant";
	public static final String amex_vpc_AccessCode = "vpc_AccessCode";
	public static final String amex_vpc_MerchTxnRef = "vpc_MerchTxnRef";
	public static final String amex_vpc_OrderInfo = "vpc_OrderInfo";
	public static final String amex_vpc_Amount = "vpc_Amount";
	public static final String amex_vpc_Currency = "vpc_Currency";
	public static final String amex_vpc_Gateway = "vpc_Gateway";
	public static final String amex_vpc_Card = "vpc_Card";
	public static final String amex_vpc_CardNum = "vpc_CardNum";
	public static final String amex_vpc_CardExp = "vpc_CardExp";
	public static final String amex_vpc_CardSecurityCode = "vpc_CardSecurityCode";
	public static final String amex_vpc_SecureHash = "vpc_SecureHash";
	public static final String amex_vpc_SecureHashType = "vpc_SecureHashType";
	public static final String amex_secret_code = "amex_secret_code";
	public static final String amex_vpc_TransNo = "vpc_TransNo";
	public static final String amex_vpc_User = "vpc_User";
	public static final String amex_vpc_Pwd = "vpc_Password";
	public static final String amex_vpc_ver_amt ="vpc_ver_amt";
	public static final String amex_vpc_CardMonth = "vpc_CardMon";
	public static final String amex_vpc_CardYear = "vpc_CardYear";
	public static final String amex_hash_status = "hash_status";
	public static final String amex_hash_value = "CORRECT";
	public static final String EMAIL_PATTERN = 
		"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" 
		+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	
	public static final String amex_vpc_3DSECI = "vpc_3DSECI";
	public static final String amex_vpc_3DSXID = "vpc_3DSXID";
	public static final String amex_vpc_3DSenrolled = "vpc_3DSenrolled";
	public static final String amex_vpc_3DSstatus = "vpc_3DSstatus";
	public static final String amex_vpc_BatchNo = "vpc_BatchNo";
	public static final String amex_vpc_Locale = "vpc_Locale";
	public static final String amex_vpc_ver_Message = "vpc_ver_Message";
	public static final String amex_vpc_ver_TransactionNo = "vpc_ver_TransactionNo";
	public static final String amex_vpc_ver_TxnResponseCode = "vpc_ver_TxnResponseCode";
	
	public static final String amex_vpc_auth_Message = "vpc_auth_Message";
	public static final String amex_vpc_auth_TransactionNo = "vpc_auth_TransactionNo";
	public static final String amex_vpc_auth_TxnResponseCode = "vpc_auth_TxnResponseCode";
	
	public static final String amex_vpc_auth_ReceiptNo = "vpc_auth_ReceiptNo";
	public static final String amex_vpc_capt_ReceiptNo = "vpc_capt_ReceiptNo";
	public static final String amex_vpc_auth_amt = "vpc_auth_amt";
	public static final String amex_vpc_capt_amt = "vpc_capt_amt";
	
	public static final String amex_vpc_capt_Message = "vpc_capt_Message";
	public static final String amex_vpc_capt_TransactionNo = "vpc_capt_TransactionNo";
	public static final String amex_vpc_capt_TxnResponseCode = "vpc_capt_TxnResponseCode";
	public static final String amex_vpc_VerSecurityLevel = "vpc_VerSecurityLevel";
	public static final String amex_vpc_VerStatus = "vpc_VerStatus";
	public static final String amex_vpc_VerToken = "vpc_VerToken";
	public static final String amex_vpc_VerType = "vpc_VerType";
	public static final String amex_vpc_TxSource="vpc_TxSource";
	public static final String amex_vpc_TxSource_value="INTERNET";
	public static final String amex_vpc_charset="_charset_";
	public static final String amex_vpc_charset_value="UTF-8";
	public static final String amex_vpc_refund_amt = "vpc_refund_amt";
	
	public static final String amex_vpc_refund_Message = "vpc_refund_Message";
	public static final String amex_vpc_refund_TransactionNo = "vpc_refund_TransactionNo";
	public static final String amex_vpc_refund_TxnResponseCode = "vpc_refund_TxnResponseCode";
	public static final String amex_vpc_refund_ReceiptNo = "vpc_refund_ReceiptNo";
	public static final String amex_pymt_status = "PAYMENT_STATUS";
	public static final String amex_pymt_ver_time = "PYMT_VER_TIME";
	public static final String amex_pymt_auth_time = "PYMT_AUTH_TIME";
	public static final String amex_pymt_capture_time = "PYMT_CAPT_TIME";
	public static final String pymnt_source_ip="SOURCE_IP";
	public static final String amex_vpc_Version_value = "1";
	public static final String amex_vpc_Command_value = "pay";
	public static final String amex_vpc_Merchant_value = "TEST9820356491";
	public static final String amex_vpc_AccessCode_value = "CDB1A599";
	public static final String amex_vpc_Gateway_value = "threeDSecure";
	public static final String amex_vpc_Card_value = "Amex";
	public static final String amex_vpc_refund_Command_value = "refund";
	public static final String amex_vpc_capture_Command_value = "capture";
	public static final String amex_vpc_SecureHashType_value = "SHA256";
	public static final String amex_secret_code_value= "7E6116FA3299FF09553F086DD3D6805F";
	public static final String amex_vpc_User_value= "testfssama";
	public static final String amex_vpc_Pwd_value = "password0";
	public static final String amex_flag= "amex_flag";
	public static final String amex_status_yes= "Y";
	public static final String amex_status_no= "N";
	public static final String amex_mode3A_url= "amex_mode3A_url";
	public static final String amex_vpc_ReturnURL= "vpc_ReturnURL";
	public static final String  pymnt_amex_webserver_notify_url = "webserverNotifyURL";
	public static final String amex_psp_code = "FS";
	public static final String amex_merchant_code = "12345";
	public static final String amex_merchant_name = "FINANCIALSOFT";
	public static final String amex_mode_3b = "Mode 3B";
	public static final String amex_mode_capture = "Mode Capture";
	public static final String amex_mode_refund = "Mode Refund";
	public static final String amex_action= "amex_action";
	public static final String amex_MessageTypeIdentifier= "1100";
	public static final String amex_MessageReasonCode= "1900";
	public static final String amex_CardAcceptorBusinessCode= "5399";
	public static final String amex_CardAcceptorIdCode= "3342517539";
	public static final String amex_CardAcceptorNameLocation= "DG EA API VERS=2.0.0, DF62=Y\\\\\\\\\\\\";
	public static final String amex_SecondaryId= "ITD";
	public static final String amex_ServiceIdentifier="AX";
	public static final String amex_RequestTypeIdentifier="AE";
	public static final String amex_EAResponse="Acknowledgement";
	public static final String amex_ProcessingCode="174800";
	/** For Amex Integration ends here*/
	/**Added By Monisha - For Setting unique Response Code for all Risk Conditions - Starts**/
	/*public static final String responseCode_declinedCard="i1";
	public static final String responseCode_negativeBin="i2";
	public static final String responseCode_negativeCard="i3";
	public static final String responseCode_ipBlock="i4";
	public static final String responseCode_riskNotFound="i5";
	public static final String responseCode_term_MaxFloorLimitAmt="i6";
	public static final String responseCode_term_MaxFloorLimitTxnCount="i7";
	public static final String responseCode_term_MaxProcessAmt="i8";
	public static final String responseCode_term_MaxCreditProcessAmt="i9";
	public static final String responseCode_card_MaxDebitAmt="i10";
	public static final String responseCode_card_MaxCreditAmt="i11";
	public static final String responseCode_card_MinTxnAmt="i12";
	public static final String responseCode_card_MaxTxnCount="i13";
	public static final String responseCode_IP_MaxTxncount="i14";
	public static final String responseCode_error_or_exceptions="i15";*/
	
	public static final String responseCode_declinedCard="Z";
	public static final String responseCode_negativeBin="X";
	public static final String responseCode_negativeCard="Y";
	public static final String responseCode_ipBlock="B";
	public static final String responseCode_riskNotFound="R";
	public static final String responseCode_term_MaxFloorLimitAmt="D";
	public static final String responseCode_term_MaxFloorLimitTxnCount="E";
	public static final String responseCode_term_MaxProcessAmt="F";
	public static final String responseCode_term_MaxCreditProcessAmt="G";
	public static final String responseCode_card_MaxDebitAmt="H";
	public static final String responseCode_card_MaxCreditAmt="I";
	public static final String responseCode_card_MinTxnAmt="K";
	public static final String responseCode_card_MaxTxnCount="J";
	public static final String responseCode_IP_MaxTxncount="T";
	public static final String responseCode_error_or_exceptions="P";
	/**Added By Monisha - For Setting unique Response Code for all Risk Conditions - Ends**/
	
	/**Added By Aneesa for Risk Codes Chart in dashboard **/
	public static final String rspcode_i1 ="Declined Card";
	public static final String rspcode_i2 ="Negative BIN";
	public static final String rspcode_i3 ="Negative Card";
	public static final String rspcode_i4 ="IP Block";
	public static final String rspcode_i5 ="Risk Not Found";
	public static final String rspcode_i6 ="Maximum Floor Limit Amount";
	public static final String rspcode_i7 ="Maximum Floor Limit Count";
	public static final String rspcode_i8 ="Maximum Process Amount";
	public static final String rspcode_i9 ="Maximum Credit Process Amount";
	public static final String rspcode_i10 ="Maximum Debit Amount";
	public static final String rspcode_i11 ="Maximum Credit Amount";
	public static final String rspcode_i12 ="Minimum Transaction Amount";
	public static final String rspcode_i13 ="Maximum Transaction Count";
	public static final String rspcode_i14 ="IP Maximum Transaction Count";
	public static final String rspcode_i15 ="Exception";
	/**End of addition By Aneesa for Risk Codes Chart in dashboard **/
	
	/** Added by Punitha A for Rupay Process - Start **/
	
	public static final String pymnt_rupay_const_flag = "rupayconst_flag";
  	public static final String pymnt_rupay_callerid = "rupayconst_callerid";
    public static final String pymnt_rupay_token = "rupayconst_token";
    public static final String pymnt_rupay_userid = "rupayconst_userid";
    public static final String pymnt_rupay_pwd = "rupayconst_password";
    
    public static final String pymnt_rupay_const_yes = "Y";
    public static final String pymnt_rupay_const_no = "N";
    
    public static final String pymnt_rupay_debitFlag="rupay_rupaydebitflag";
    public static final String pymnt_rupay_merchantID = "rupay_merchatnid";
    public static final String pymnt_rupay_terminal = "rupay_terminalid";
    public static final String pymnt_rupay_sub_action="rupay_sub_action";
    public static final String pymnt_rupay_version = "1.0.0.0";
    public static final String pymnt_rupay_partnerid = "rupay_partnerid";
    public static final String pymnt_rupay_merchpwd = "rupayc_merchpassword";
    public static final String pymnt_rupay_tid = "rupay_tid";
    public static final String pymnt_rupay_mcc = "rupay_mcc";
    public static final String pymnt_rupay_cardacceptorid = "rupay_cardacceptorid";
    public static final String pymnt_rupay_townername = "rupay_townername";
    public static final String pymnt_rupay_tcityname = "rupay_tcityname";
    public static final String pymnt_rupay_tstatename = "rupay_tstatename";
    public static final String pymnt_rupay_tcountryname = "rupay_tcountryname";
    public static final String pymnt_rupay_postname = "rupayt_postname";
    public static final String pymnt_rupay_mtelephone = "rupay_mtelephone";
    public static final String pymnt_rupay_tranid = "rupay_tran_id";
    public static final String BANKPASS_ACCEPTED_BRANDS_STR = "bankpass_accepted_brands_str";
    
    public static final String pymnt_rupay_rqststatus = "rupay_rqststatus";
    public static final String pymnt_rupay_init_resp = "Rupay_Init_Response";
    public static final String pymnt_rupay_init_resp_status = "Rupay_Init_Response_Status";
    public static final String pymnt_rupay_rrn = "retrieval_ref_number";
    public static final String pymnt_rupay_guid="rupay_guid";
    public static final String pymnt_rupay_modulus="rupay_modulus";
    public static final String pymnt_rupay_exponent="rupay_exponent";
    public static final String pymnt_rupay_status="rupay_status";
    public static final String pymnt_rupay_errorcode="rupay_errorcode";
    public static final String pymnt_rupay_errormsg="rupay_errormsg";
    
    public static final String pymnt_rupay_error_txn="rupay_error_txn";
    public static final String pymnt_rupay_appr_code="rupay_appr_code";
    
    public static final String pymnt_rupay_auth_resp_status = "Rupay_Auth_Response_Status";
    public static final String pymnt_rupay_auth_resp = "Rupay_Auth_Response";
    
    public static final String pymnt_rupay_inquiry_resp_status = "Rupay_Inquiry_Response_Status";
    public static final String pymnt_rupay_inquiry_resp = "Rupay_Inquiry_Response";
    
    public static final String pymnt_rupay_checkbin_resp_status = "Rupay_Checkbin_Response_Status";
    public static final String pymnt_rupay_checkbin_resp = "Rupay_Checkbin_Response";
    public static final String pymnt_rupay_frame_url = "rupayFrameUrl";
    
    //Authorize Configuration
    public static final String pymnt_rupay_auth_errorTxn = "failure";
    public static final String pymnt_rupay_auth_invalid_errMsg = "INVALID AUTHORIZE LEG";
    public static final String pymnt_rupay_auth_host_out_errMsg = "AUTHORIZE HOST OUT ERROR";
    public static final String pymnt_rupay_auth_parse_errMsg = "AUTHORIZE PARSE ERROR";
    
    /** Added by Punitha A for Rupay Process - End **/
    
  //Added by Viswajith S for OTP starts
    public static final String ext_generation_url="EXT_GENERATION_URL";
    public static final String ext_validation_url="EXT_VALIDATION_URL";
    //Ends
    
    //Added by Viswajith S for Currency Conversion starts
    public static final String pymnt_convrt_crncy_cd="CONVRT_CRNCY_CODE";
    public static final String pymnt_convrt_trnsc_amnt="CONVRT_TRNSC_AMOUNT";
    public static final String pymnt_crncy_type="CURRENCY_TYPE";
    public static final String pymnt_cc_flg="CCFLG";
    public static final String pymnt_cc_flg_mc="MC";
    public static final String pymnt_cc_flg_cc="CC";
    public static final String pymnt_cc_flg_oc="OC";
    public static final String pymnt_cc_refundbatch_type="CC_REFUND_BATCH_TYPE";
    public static final String pymnt_cc_refundbatch_flg_txn="TXN_DATE_RATE";
    public static final String pymnt_cc_refundbatch_flg_ason="ASON_DATE_RATE";
    public static final String pymnt_cc_tran_id="CC_TRANID";
    public static final String cc_user_id="CC_USER_ID";
    public static final String cc_pasword="CC_PWD";
    public static final String cc_url="CC_URL";
    //Ends
    
    /** Added by Punitha A for Visa / Master Process - Start **/
    
    public static final String pymnt_terminal_auth_mode="AUTH_MODE";
    
    public static final String echo_thread_Time="1000";
    
    public static final String iPay_visa_zmk_pin_alias_name = "IPAY_VISA_ZMK_PIN_ALIASNAME";
    public static final String iPay_visa_zpk_pin_alias_name = "IPAY_VISA_ZPK_PIN_ALIASNAME";
    public static final String iPay_visa_pin_alias_name = "IPAY_VISA_PIN_ALIASNAME";
    public static final String iPay_master_zmk_pin_alias_name = "IPAY_MASTER_ZMK_PIN_ALIASNAME";
    public static final String iPay_master_zpk_pin_alias_name = "IPAY_MASTER_ZPK_PIN_ALIASNAME";
    public static final String iPay_master_pin_alias_name = "IPAY_MASTER_PIN_ALIASNAME";
    
    /** Added by Punitha A for Visa / Master Process - End **/
    
    /** Added by Vinodhini T -  for Visa / Master Process - Start **/
    public static final String pymnt_terminal_visa_extrconnid="VISA_EXTERNAL_CONNECTION_ID";
    public static final String pymnt_terminal_visa_merchant_acceptor="VISA_MERCHANT_ACCEPTOR";
    public static final String pymnt_terminal_visa_merchant_acceptor_term="VISA_MERCHANT_ACCEPTOR_TERM";
    public static final String pymnt_terminal_visa_merchant_acquirer="VISA_MERCHANT_ACQUIRER";
    public static final String pymnt_terminal_visa_merchant_b24_group="VISA_MERCHANT_B24_GROUP";
    public static final String pymnt_terminal_visa_merchant_b24_id="VISA_MERCHANT_B24_ID";
    public static final String pymnt_terminal_visa_merchant_b24_region="VISA_MERCHANT_B24_REGION";
    public static final String pymnt_terminal_visa_merchant_b24_term_data="VISA_MERCHANT_B24_TERM_DATA";
    public static final String pymnt_terminal_visa_auth_type="VISA_AUTH_TYPE";
    
    public static final String pymnt_terminal_master_extrconnid="MASTER_EXTERNAL_CONNECTION_ID";
    public static final String pymnt_terminal_master_merchant_acceptor="MASTER_MERCHANT_ACCEPTOR";
    public static final String pymnt_terminal_master_merchant_acceptor_term="MASTER_MERCHANT_ACCEPTOR_TERM";
    public static final String pymnt_terminal_master_merchant_acquirer="MASTER_MERCHANT_ACQUIRER";
    public static final String pymnt_terminal_master_merchant_b24_group="MASTER_MERCHANT_B24_GROUP";
    public static final String pymnt_terminal_master_merchant_b24_id="MASTER_MERCHANT_B24_ID";
    public static final String pymnt_terminal_master_merchant_b24_region="MASTER_MERCHANT_B24_REGION";
    public static final String pymnt_terminal_master_merchant_b24_term_data="MASTER_MERCHANT_B24_TERM_DATA";
    public static final String pymnt_terminal_master_auth_type="MASTER_AUTH_TYPE";
    
    public static final int pymnt_extr_entity_interchange=1;
    public static final int pymnt_extr_entity_switch=0;
    
    
    /** Added by Vinodhini T -  for Visa / Master Process - End **/
    
  //Added by Shereen.N for transaction amount validation
	public static final int invalid_txnamount =  0;
	//Ends
	
	//Added by Viswajith S
	public static final String pymnt_crncy_symbol_usd ="USD";
	//Ends
	
	
	//Prepaid
	public static final String pymnt_brndrules_p_checkdigit_flg = "P_CHECK_DIGIT_FLAG";
	public static final String pymnt_brndrules_p_exprvrfy_flg = "P_EXPIRY_VERIFY_FLAG";
	public static final String pymnt_brndrules_p_adrsvrfy_flg = "P_ADDRESS_VERIFY_FLAG";
	public static final String pymnt_brndrules_p_cardvrfy_flg = "P_CARD_VERIFY_FLAG";
	public static final String pymnt_brndrules_p_pindebit_flg = "P_PIN_DEBIT_FLAG";
	//Ends

	
	//For iRemit
    public static final int activation_status = 1;

	
	/**
	 * IRemiter table columns in map
	 */
	
	public static final String iremit_tran_id = "TRAN_ID";
	public static final String iremit_name = "Name";
	public static final String iremit_card_holder = "Card Holder Name";
	public static final String iremit_card_number = "Card Number";
	public static final String iremit_amount = "Amount";
	public static final String iremit_tran_date = "Transaction Date";
	public static final String iremit_tran_time = "Transaction Time";
	
	 /**  For OCT Request frame **/     
    public static final int pymnt_oct_action_code=11;
    public static final String pymnt_instrmnt_oct_value="C";
    /**End**/
    
    public static final String pymnt_errordesc = "ERROR_DESC";
    
  //Added by Subraamni V for Report JNDI
    public static final String REPORT_JNDI = "1";
    public static final String REPORT_NO_JNDI = "0";
  //Added by Subraamni V for Report JNDI
    //Added by Subraamni V Host Server detials
    public static final String manage_server_details = "MANAGE_SERVER";
    public static final String server_name = "SERVER_NAME";
    //End
    
    //Added by Viswajith S for message24
    
    public static final String extrconn_aggregator_flag="EXTRCONN_AGGR_FLG";
    public static final String ipay_echo="IPAY_ECHO";
    public static final String m24_sh_path="M24_SH_PATH";
    
    public static final String visa_m24_sh_path="VISA_M24_SH_PATH";
    public static final String master_m24_sh_path="MASTER_M24_SH_PATH";
    
    //End
    //added by Prasanna Vengataramana G for station name
    public static final String ipaybase24="IPAYBASE24";
    public static final String ipayhost="IPAYHOST";
    public static final String ipayhostecho="IPAYHOSTECHO";

    //Added by Punitha For Visa / Master
    public static final String ipay_server_visa="VISA";
    public static final String ipay_server_master="MASTER";
    
    
    public static final int visatrantype = 9;
    public static final int mastertrantype = 10;
    public static final int ipayechoremoteport =50;
    public static final int base24trantype =7;
    public static final int hosttrantype = 4;
    public static final int hostechotrantype = 8;
    public static final int visabase24trantype =9;
    public static final int visahosttrantype = 9;
    public static final int visahostechotrantype = 9;
    public static final int masterbase24trantype =10;
    public static final int masterhosttrantype = 10;
    public static final int masterhostechotrantype = 10;
    public static final int impstrantype = 6;
    
    public static final String local_host="LOCAL_HOST";
    
    public static final String base24apiconntypenm ="7";
    public static final String hostapiconntypenm = "2";
    public static final String hostechoapiconntypenm = "2a";
    public static final String impsapiconntypenm = "17";
    public static final String sms_alert_logon = "CON^`!XML^`!ICICIBANK#END#";
    public static final String sms_alert_logoff = "EXT^`!CLOSE the Message#END#";
    public static final String sms_alert_logonsuccess = "CON!0^`!";
    public static final String sms_alert_logon_ack =  "ACK!MSGSTATUS=TRUE;FATAL=FALSE;DEPT=MBG;APPID=3DSFRG;DEPTMSGID=1;INFO1=;INFO2=;INFO3=;INFO4=JAVA;TRN_GENERATE_TIMESTAMP=2015-07-17 17:56:58;MOBILE=918055938818;ISGMSGID=97707;ERROR=^`!";
    
    public static final String aggregator_flag_yes = "Y";
    public static final int base24 = 0;
	public static final String pymnt_prefix_id = "PYMNT_PREFIX_ID";
    
    //Added for card holder name
    public static final String pymnt_card_hldr_name_flg = "CARD_HLDR_NAME_FLG";
    //End
    
    public static final String STATUS_TIME_OUT = "TIME_OUT";
    public static final String STATUS_LATE_RESPONSE = "LATE_RESPONSE";
	
    public static final String process_option="PROCESSING_OPTION";
    public static final String Merchant_HUB_Flag_Yes="Y";
    public static final String Merchant_HUB_Flag_No="N";
    
    public static final String Selected_Authtype="selectedAuthType";
    
    public static final int min_merchant_acceptor_term = 8;
    public static final int min_merchant_acceptor = 15;
    public static final int min_acceptor_institution = 4;
    /***Added  on 12-09-16 for Bit 43 Merchant Location: Starts***/
	public static final String pymnt_Inst_merch_location_flag = "INST_MERCH_LOC_FLAG";
	/****Added for Bit 43 Merchant Location : Ends *****/
	
	/***Added  on 16-09-16 for Static reports: Starts***/
	public static String staticReportPropLocation = "REPORT_PROPERTIES_LOCATION";
	
   /**Added by Anusha R on 21/09/16 for ECI Configuration : Starts**/
	public static final String pymnt_Inst_eci_flag = "INST_ECI_FLAG";	
	public static final String eci_flag_yes ="1";
	public static final String eci_flag_no ="0";
	/**Added by Anusha R on 21/09/16 for ECI Configuration : Ends**/
    //BOMH changes - starts
    public static final String cust_account_no="CUST_ACCOUNT_NO";
    public static final String cust_journal_no="CUST_JOURNAL_NO";
    public static final int log_journ_acc_yes=1;
    public static final int log_journ_acc_no=0;
    //BOMH changes - ends
    //SBI online refund - starts
    public static final String original_service_online_refund="ORIGINAL_SERVICE_AMNT";
	public static final String pymnt_Inst_online_refund_flag="INST_ONLINE_RFND_FLAG";
	public static final String online_refund_flag= "1";
	public static final String pymnt_inst_servicecharge_amount = "SERVICE_CHARGE_AMNT";
    //SBI online refund - ends 
	//Added by Anusha R on 30/09/16 for Maestro Refund Batch Process
	public static final String responseCode ="00";
	public static final String masteroRefundBatchG ="G";
	//End
 // added by SUBRAMANI V for grips  - starts
 	public static final String grips_merchant_code="GRIPS_MERCHANT_CODE";
 	public static final String grips_mode="GRIPS_MODE";
 	public static final String grips_noofchallan="GRIPS_NO_CHALLAN";
 	public static final String grips_challanrefiddate="GRIPS_CHALLAN_REF_ID_DATE";
 	public static final String grips_head_account="GRIPS_HEAD_ACCOUNT";
 	public static final String grips_amount="GRIPS_AMOUNT";
 	public static final String grips_deposited_by="GRIPS_DEPOSITER_NAME";
 	public static final String grips_language_id="GRIPS_LANGUAGE_ID";
 	public static final String grips_challan_ref_id="GRIPS_CHALLAN_REF_ID";
 	public static final String grips_depositor_id="GRIPS_DEPOSITOR_ID";
 	public static final String grips_validate_flag="VR";
 	public static final String grips_pass_url="1";
 	public static final String grips_proceed_trrn="PT";
 	public static final String grips_flag_inst="GRIPS_FLAG_INST";
 	public static final String grips_flag_term="GRIPS_FLAG_TERM";
 	public static final String grips_report_download_location="GRIPS_REPORT_DOWNLOAD_PATH";
 	// added by SUBRAMANI V for grips  - ends
 	public static final String Accout_Number="sAccount_Number";
 	
 	public static final String  pymnt_3d_payment_brand_certname = "certname";
	//Added for IPAYV2 - 3D Secure issue ----Starts
	public static final String  pymnt_3d_payment_brand_onofftype = "onofftype";
	public static final String pymnt_onOff_type = "onOffType";
	public static final int pymnt_onus_flag = 1;
	public static final int pymnt_offus_flag = 0;
    //Added By Kaliappan.J for OTP : Starts
    public static final String json_msgbdy_alerttype="SMS";
	public static final String json_msgbdy_msghash="?";
	public static final String json_msgbdy_authenticationsallowed="1";
	public static final String json_msgbdy_pwdcategory="OTP";
	public static final String json_msgbdy_pwdmask="N";
	public static final String json_msgbdy_otprefdata="YES";
	
	public static final String OTP_STATUS_SUCCESS = "0";
	public static final String OTP_STATUS_MESSAGE = "Status";
	
	public static final String  otp_model_upload = "U";
	public static final String  otp_model_host = "H";
	public static final String  otp_model_json = "J";
	
	public static final String  otp_status_sent = "SENT";
	public static final String  otp_status_success = "SUCCESS";
	public static final String  otp_status_retry_fail = "OTP ATTEMPTS EXCEED";
	public static final String  otp_status_resend_fail = "OTP RESEND ATTEMPTS EXCEED";
	public static final String  otp_status_expired = "OTP EXPIRED";
	public static final String otp_status_fail = "FAIL";
	
	public static final String  inst_logo = "INST_LOGO";
	public static final String  mrch_logo = "MERCH_LOGO";
	public static final String  mrch_name = "MERCHANT_NAME";
	public static final String  inst_name = "INSTNAME";
	public static final String  otp_req = "OTP_REQUEST";
	public static final String  otp_req_yes = "YES";
	public static final String  otp_resend = "RESEND";
	public static final String  otp_email = "OTP_EMAIL";
	public static final String  otp_mobileno = "OTP_MOBILE_NO";
	public static final String  otp_countrycode = "OTP_COUNTRY_CODE";
	public static final String  otp_allowed_international = "I";
	public static final String  otp_allowed_domestic = "D";
	public static final String  otp_country_code = "91";
	public static final String  otp_country_code_text = "in";
	public static final String  otp_webserver_url="WEBSERVER_OTP_URL";
	public static final String  otp_userid="OTP_USER_ID";
	public static final String  otp_pwd="OTP_USER_PWD";
	public static final String  otp_email_from_addr="ipay@fss.co.in";
	public static final String  otp_email_regards="Admin";
	public static final String  otp_idfc_webserver_url="IDFC_OTP_WEBSERVICE_URL";
	public static final String  otp_hosted_txn="HT";
	public static final String  otp_tranportal_txn="TT";
	public static final String  otp_validate="VALIDATE";
	
	public static final String  formatter_type="FORMATTER_TYPE";
	public static final String  formatter_name="FORMATTER_NAME";
	public static final String  formatter_type_default="D";
	public static final String  formatter_type_bank="B";
	
	//Added By Kaliappan.J for OTP : Ends
    
	//Added By Kaliappan.J for SBI CBDT Merchant : Starts
	public static final String NA="NA";
	//Added By Kaliappan.J for SBI CBDT Merchant : Ends
	//Added By Anusha R on 17/10/16 for Security Issue while sending response and error url in Request during transaction-Starts
	public static final String merch_http_res_url="Response_URL";
	public static final String merch_http_error_url="Error_URL";
	//Added By Anusha R on 17/10/16 for Security Issue while sending response and error url in Request during transaction-Ends
	//Added by Anusha R for EMI Flag
	public static final int paymentInstrumentCount=1;
	//End
    public static final String extrconn_nodejs_flag="EXTRCONN_NODEJS_FLG";
    public static final String extrconn_nodejs_source="NODEJS_SOURCE";
    public static final String extrconn_nodejs_destination="NODEJS_DESTINATION";
    public static final String extrconn_nodejs_url="NODEJS_URL";
    public static final String extrconn_nodejs_methodtype="NODEJS_METHOD_TYPE";
    public static final String extrconn_nodejs_contenttype="NODEJS_CONTENT_TYPE";
    public static final String extrconn_nodejs_timeout="NODEJS_TIMEOUT";
    public static final String extrconn_nodejs_retryattmpts="NODEJS_RETRY_ATTMPTS";
    public static final String alternate_src="NODEJS_ALTERNATE_SOURCE";
    public static final String alternate_destn="NODEJS_ALTERNATE_DESTN";
    public static final String pymnt_Inst_SingleTid_flag = "INST_SINGLETID_FLAG";
	public static final String pymnt_Term_SingleTid_flag = "TERM_SINGLETID_FLAG";
	public static final int pymnt_SingleTid_active = 1;
	public static final int pymnt_SingleTid_Inactive = 1;
	
	/** Added By Kaliappan.J for Radio Button Flag : Starts **/
	public static final String radioFlag="RADIO_FLAG";
	/** Added By Kaliappan.J for Radio Button Flag : Ends **/
	//Added by Anusha R on 03/11/16 for Maestro Batch Refund
	public static final String pymnt_Retailer_Id = "RETAILER_ID";
	/**Added for Master Card Mandate***/
	public static final String pymnt_mrch_facilitator_flag = "FACILITATOR_FLAG";
	public static final String pymnt_mrch_facilitator_id = "FACILITATOR_ID";
	public static final String pymnt_mrch_facilitator_name = "FACILITATOR_NAME";
	public static final String pymnt_mrch_sales_org_id = "SALES_ORG_ID";
	//public static final String pymnt_mrch_sub_mrch_id = "SUB_MRCH_ID"; -- to be removed
	public static final String pymnt_mrch_user_field = "USER_FIELD";
	public static final int common_one=1;
	/**Added for Master Card Mandate***/
	
	//Added for success rate : Jothieshwar  Starts
    public static final String pymnt_merchant_type_hosted = "HOSTED";
    public static final String pymnt_merchant_type_tranportal = "TRANPORTAL";
    public static final String pymnt_merchant_type_tranportalvbv = "TRANPORTALVBV";
    public static final String pymnt_merchant_type_tranportalvbvivr = "IVR";
    
    public static final String pymnt_merchant_type_batch = "BATCH";
    public static final String pymnt_merchant_type_entertran = "ENTER TRAN";
    public static final String pymnt_merchant_type_aggregator = "AGGREGATOR";
    
    public static final String pymnt_merchant_type = "MRCHTYPE";
    public static final String pymnt_status_0 = "Total processed transactions by PG";
    public static final String pymnt_status_1 = "Total failed transactions at PG";
    public static final String pymnt_status_3 = "Cancelled by Customer";
    public static final String pymnt_status_4 = "Auth Error Cases";
    public static final String pymnt_status_5 = "Unable to Verify (Not able to connect with interchanges during VEREQ leg)";
    public static final String pymnt_status_6 = "3DS Card Enrolled (Enrolled txns)";
    public static final String pymnt_status_7 = "3DS Card not Enrolled (Not Enrolled txns)";
    public static final String pymnt_status_9 = "3DS Successful PARES";
    public static final String pymnt_status_8 = "3DS Failed PARES";
    public static final String pymnt_status_10 = "Unable to Authorize (Denied By RISK / Host Time Out / PARES Not Successful)";
    public static final String pymnt_status_12 = "Unable to Authenticate";
	//Added for success rate : Jothieshwar  Ends
  //Added for rupay bin upload : starts
    public static final String rupaybin_upload_path = "uploadRupayBinPath";
    public static final String rupaybin_upload_error_path = "uploadRupayBinPath";
    public static final String rupaybin_message_type="BIN_MESSAGE_TYPE";
    public static final String rupaybin_message_type_sms="SMS";
    public static final String rupaybin_message_type_dms="DMS";
    //Added for rupay bin upload : ends
	
	/** Added By Kaliappan.J for PreAuth Transaction : Starts **/
	public static final String pymnt_Enrolled_Status = "ENROLLED_STATUS";
	public static final String pymnt_Auth_Status = "AUTH_STATUS";
	public static final String pymnt_Pre_Auth_Transaction = "PREAUTH_TRANSACTION";
	public static final String pymnt_result_code_success = "SUCCESS";
	/** Added By Kaliappan.J for PreAuth Transaction : Ends **/
	
	/** Added By Kaliappan.J for Aggregator : Starts **/
	public static final String aggr_mapping_logo_location = "AGGR_MAPPING_LOGO_LOCATION";
	
	public static final int pymnt_active = 1;
	public static final int pymnt_Inactive = 0;
	
	public static final String pymnt_trans_id_str = "transid";
	public static final String pymnt_terminal_tranportalPwd= "TERM_TRANPORTAL_PASS";
	public static final String pymnt_Batch_Type = "BATCH_TRANSACTION";
	
	public static final String pymnt_rupay_tran_id = "RUPAY_TRAN_ID";
	
	public static final String rupay_flag= "rupay_flag";
	public static final String rupay_action= "rupay_action";
	public static final String rupay_refund_Command_value = "refund";
	
	public static final String pymnt_aggr_name="AGGR_NAME";
	public static final String pymnt_inst_name="INST_NAME";
	
	public static final String pymnt_aggr_paymentid="AGGR_PAYMENT_ID";
	public static final String aggr_flag="AGGR_FLAG";
	
	public static final String pymnt_aggr_id="AGGR_ID";
	public static final String pymnt_aggr_pwd="AGGR_PASSWORD";
	
	public static final String pymnt_terminal_risk_error_code = "TERMINAL_RISK_ERROR_CODE";
	/** Added By Kaliappan.J for Aggregator : Ends **/
	//Added by subramaniv for risk and interchange alert
		public static final String pymnt_inst_config_interchangealert_flg = "INSTCONFIG_INTERCHANGEALERT_FLAG";
		public static final String pymnt_interchange_conn_failure_errorcode = "ErrorCode:01";
		public static final String pymnt_interchange_conn_failure = "Connection Failur";
		public static final String pymnt_interchange_conn_refused = "Connection Refused";
		public static final String pymnt_interchange_conn_closed_errorcode = "ErrorCode:02";
		  public static final String pymnt_interchange_conn_timeout_errorcode = "ErrorCode:03";
		    public static final String pymnt_interchange_securechannel_failure_errorcode = "ErrorCode:04";
		    public static final String pymnt_interchange_other_errors = "ErrorCode:05";
		    public static final String pymnt_interchange_read_timeout = "ErrorCode:06";
		    public static final String pymnt_interchange_protocol_error_code = "ErrorCode:07";
		    public static final String pymnt_interchange_conn_closed = "Connection Closed";
		    public static final String pymnt_interchange_conn_timeout = "Connection Timeout";
		    public static final String pymnt_interchange_securechannel_failure = "Secure Channel Failure";
		    public static final String pymnt_interchange_conn_readtimeout = "Connection Read Timeout";
		    public static final String pymnt_interchange_protocol_error = "Protocol Error";
		    public static final String pymnt_interchange_type_rupay = "NPCI";
		    public static final String pymnt_interchange_type_offus_visa = "OFFUS_VISA";
		    public static final String pymnt_interchange_type_onus_visa = "ONUS_VISA";
		    public static final String pymnt_interchange_type_offus_master = "OFFUS_MASTER";
		    public static final String pymnt_interchange_type_onus_master = "ONUS_MASTER";
		    public static final String pymnt_interchange_type_offus_diners = "OFFUS_DINERS";
		    public static final String pymnt_interchange_type_onus_diners = "ONUS_DINERS";
		    public static final String pymnt_interchange_type = "INTERCHANGE_TYPE";
		    public static final String pymnt_brndtype_V = "VISA";
		    public static final String pymnt_brndtype_M = "MASTER";
		    public static final String pymnt_brndtype_D = "DINERS";
		    public static final String rAlertInterchange = "Interchange";
		    public static final String pymnt_interchange_status_down = "N"; 
		    public static final String pymnt_interchange_status_active = "Y"; 
		    public static final int alertChoice_mail = 1;
		    public static final String rAlertRisk = "Risk";
		    public static final String RALert_Config_List = "RALERT_CONFIG_LIST";
		    public static final String pymnt_terminal_risk_alert_flg = "TERMINAL_RISK_ALERT_FLAG";
			public static final String pymnt_inst_risk_alert_flg = "INST_RISK_ALERT_FLAG";
			public static final Integer pymnt_terminal_risk_level_one = 1;
			public static final Integer pymnt_terminal_risk_level_two = 2;
			public static final Integer pymnt_terminal_risk_level_three = 3;
			public static final String risk_alert_choice = "RISK_ALERT_CHOICE";
			public static final String risk_alert_mobile = "RISK_ALERT_MOBILE";
			public static final String risk_alert_email = "RISK_ALERT_EMAIL";
			public static final String risk_profile_details = "RISK_PROFILE_DETAILS";
			public static final String pymnt_risk_check_cal = "RISK_CHECK_CAL";
			public static final String tran_alert_interchange = "TRAN_INTERCHANGE";
			public static final String tran_alert_risk = "TRAN_RISK";
			public static final String tran_alert_type = "TRAN_ALERT_TYPE";
			public static final String PG = "PG";
			public static final String responseCode_card_successcount="L";
			
			//Added for testpath external connection - starts
			public static final String connectivityFlag="CONNECTIVITY_FLG";
			//Added for testpath external connection - ends
			
			public static final String supported_pymnt_id = "Supported_Payment_Id";
			
			//Added for PayZapp - Starts
			public static final String payzappCardMasked="payzappCardMasked";
			public static final String payzappCardHash="payzappCardHash";
			public static final String payzappPgTxnId="payzappPgTxnId";
			public static final String payzappWibmoTxnId="payzappWibmoTxnId";
			public static final String payzappMerId="payzappMerId";
			public static final String payzappPgStatusCode="payzappPgStatusCode";
			public static final String payzappCardClassificationType="payzappCardClassificationType";
			public static final String payzappCardType="payzappCardType";
			public static final String payzappResCode="payzappResCode";
			public static final String payzappResDesc="payzappResDesc";
			public static final String payzappErrorCode="payzappErrorCode";
			public static final String payzappErrorDetail="payzappErrorDetail";
			public static final String payzappRRN="payzappRRN";	
			public static final String payzappUsername="admin";	
			public static final String pymnt_mrch_payzapp_flag = "PAYZAPP_FLAG";
			public static final String pymnt_instrmnt_payzapp="PZ";
			//Added for PayZapp - Ends
			
			//public static final String batch_type = "BATCH_TYPE";
			//public static final String batch_preauth_flag = "BATCH_PREAUTH_FLAG";
			public static final String paresRcvdTime="paresrectime";
			
			//Added for Merchant Aggregattor Transaction- Starts
			//public static final String pymnt_aggr_id = "AGGRID";
			public static final String pymnt_aggr_mrch_id = "AGGR_MRCHID";
			public static final String pymnt_aggr_portal_domain ="AGGR_PORTAL_DOMAIN";
			public static final String pymnt_aggr_instrmntCredit ="Credit_Card_CVV";
			public static final String pymnt_aggr_instrmntCredit_Pin ="Credit_Card_PIN";
			public static final String pymnt_aggr_instrmntDebit ="Debit_Card_CVV";
			public static final String pymnt_aggr_instrmntDebit_Pin ="Debit_Card_PIN";
			public static final String pymnt_aggr_instrmntPrepaid ="Prepaid_Card_CVV";
			public static final String pymnt_aggr_instrmntPrepaid_Pin ="Prepaid_Card_PIN";
			public static final String pymnt_aggr_instrmntDD ="Direct_debit";
			public static final String pymnt_aggr_instrmntimps ="IMPS";
			public static final String pymnt_aggr_instrmntwallet ="WALLET";
			public static final String pymnt_aggr_instrmntEMI ="EMI";
			public static final String pymnt_aggr_instrmntUPI ="UPI";
			public static final String pymnt_aggr_routingCredit ="ROuting_Credit_CVV";
			public static final String pymnt_aggr_routingDebit ="ROuting_Debit_CVV";
			public static final String pymnt_aggr_routingPrepaid ="Routing_Prepaid_CVV";
			public static final String pymnt_aggr_routingCredit_Pin ="Routing_Credit_Pin";
			public static final String pymnt_aggr_routingDebit_Pin ="Routing_Debit_Pin";
			public static final String pymnt_aggr_routingPrepaid_Pin ="Routing_Prepaid_Pin";
			public static final String pymnt_aggr_routingDD ="Routing_Direct_Debit";
			public static final String pymnt_aggr_routingimps ="Routing_IMPS";
			public static final String pymnt_aggr_routingwallet ="Routing_Wallet";
			public static final String pymnt_aggr_routingEMI ="Routing_EMI";
			public static final String pymnt_aggr_routingUPI ="Routing_UPI";
			public static final String aggr_dflt_PG_flag ="Default_PG_Flag";
			public static final String aggr_default_PG ="1";
			public static final String aggr_list_PG ="2";
			public static final String aggr_binbased_routing="3";
			public static final String aggr_routing_list="2";
			public static final String aggr_tranid ="TRANID";
			public static final String aggr_pymnt_instrmnt ="AGGR_PYMNT_INSTRMNT";
			public static final String batch_type = "BATCH_TYPE";
			public static final String batch_preauth_flag = "BATCH_PREAUTH_FLAG";
			public static final String aggr_pymnt_rsltcode = "PYMNT_RSLT_CODE";
			public static final String aggr_pymnt_rspnsecode = "PYMNT_RESPONSE_CODE";
			public static final String aggr_txn_rfrncenum = "TRAN_REF_NUM";
			public static final String aggr_pymnt_tranid = "PYMNT_TRAN_ID";
			public static final String aggr_pymnt_status = "PYMNT_STATUS";
			public static final String aggr_extrconnID = "EXTRCONN_ID";
			public static final String aggr_pymnt_chnl_code = "PYMNT_CHNL_CODE";
			 public static final String aggr_pymnt_routed_bank = "PYMNT_ROUTED_BANK";
			public static final String aggr_partner_bankID = "PARTNET_BANK_ID";
			public static final String aggr_partner_merchID = "PARTNET_MERCH_ID";
			public static final String aggr_partner_termID = "PARTNET_TERMINAL_ID";
			public static final String aggr_pymnt_contvty_type = "CONNECTIVITY_TYPE";
			public static final String aggr_pymnt_encr_card = "ENCRYPTED_CARD_NUM";
			public static final String aggr_pymnt_pg_pymntID = "PG_PAYMENT_ID";
			public static final String aggr_txn_IP = "TRAN_IP";
			public static final String aggr_txn_type = "TRAN_TYPE";
			public static final String aggr_multi_schema ="AGGR_MULTI_SCHEMA";
			public static final String aggr_intr_sleep ="AGGR_INTR_SLEEP";
			public static final String pymnt_usr_def_fld6 = "USR_DEF_FLD6";
			public static final String pymnt_usr_def_fld7 = "USR_DEF_FLD7";
			public static final String pymnt_usr_def_fld8 = "USR_DEF_FLD8";
			public static final String pymnt_usr_def_fld9 = "USR_DEF_FLD9";
			public static final String pymnt_usr_def_fld10 = "USR_DEF_FLD10";
			public static final String pymnt_usr_def_fld11 = "USR_DEF_FLD11";
			public static final String pymnt_usr_def_fld12 = "USR_DEF_FLD12";
			public static final String pymnt_usr_def_fld13 = "USR_DEF_FLD13";
			public static final String pymnt_usr_def_fld14 = "USR_DEF_FLD14";
			public static final String pymnt_usr_def_fld15 = "USR_DEF_FLD15";
			public static final String pymnt_aggr_billpayflg ="BILLPAY_FLAG";
			public static final String pymnt_aggr_billpaydata ="BILLPAY_DATA";
			public static final String pymnt_aggr_billpay_refnum ="BILLPAY_REFNUM";
			public static final String pymnt_aggr_org_pg_tranid ="ORIG_PYMNT_TRAN_ID";
			public static final String aggr_active="1";
			public static final String aggr_inactive ="0";
			public static final String aggr_txn_type_hosted="HOSTED";
			public static final String aggr_txn_type_tranortal="TRANPORTAL";
			public static final String aggr_txn_type_batch="Batch";
			public static final String pymnt_instrmnt_credit_pin="CP";
			public static final String pymnt_instrmnt_debit_pin="DP";
			public static final String aggr_extr_conn_type ="AGGR_EXTR_CONN_TYPE";
			public static final String aggr_routing_type = "ROUTING_TYPE";
			public static final String aggr_cntvty_type_pg ="1";
			public static final String aggr_cntvty_type_aggr ="4";
			
			public static final String aggr_txn_type_trnprtl_TCP="TRANPORTAL";
			
				

			//public static final String pg_aggr_tran_invalid_aggrExtrconn ="INVALID Aggregator External Connection";
			
			//public static final String pymnt_aggr_portal_domain = "PORTAL_DOMAIN";
			
			//Added for Merchant Aggregattor Transaction- Ends
			
			
			//Added payment Id value as -1 when it is null for Tranportal Transaction
			public static final String payment_id_minus_one="-1";

			public static final String pymnt_extrconn_authtype_others = "O";
			public static final String pymnt_formatted_eci_value = "FORMATTED_ECI_VALUE";
			
			public static final String pymnt_retailer_phone_no = "RETAILER_PHONE_NUMBER";
			public static final String inst_saved_card = "INST SAVEDCARD";
			
			
			
			//Added for PINKEY
			 public static final String pin_algorithm = "ALGORITHM";
			 public static final String pin_encryption_mode = "ENCRYPT_MODE";
			 public static final String pin_padding_Type = "PADDING_TYPE";
			 public static final String pin_keyType = "KEY_TYPE";
			 public static final String pin_pinblck_format = "PINBLOCK_FORMAT";
			 public static final String pin_keyvalue = "KEY_VALUE";
			 public static final String pin_auth_type="AUTH_TYPE";
			 public static final String pin_blck_format_pinpad="PINPAD";
			 public static final String pin_paddingType_nopad = "NoPadding";
			 public static final String pin_paddingType_pkcs7 = "PKCS7Padding";
			 
			 
			 public static final String pymnt_extr_conn_bici_flag = "EXTR_BICI_FLAG";
				
			 public static final String VPAS_PAREQ_MSG="PAREQ_MSG";
			 
			//NSDL Implementation Changes : Jothieshwar Starts
			public static final String termNsdlFlag="TERM_NSDL_FLAG";
			public static final String instNsdlFlag="INST_NSDL_FLAG";
			//NSDL Implementation Changes : Jothieshwar Ends
				
			public static final String nodejs_ms_based_flg  = "NODEJS_MANAGE_SERVER_BASED_FLAG";
			public static final String brand_extr_conn_id = "BRAND_EXTR_CONN_ID";
			
			//Added for One Click Checkout
			public static final String pymnt_oneclk_chk_cust_mob_num="ONE_CLK_CUST_MOB";
			public static final String pymnt_oneclk_chk_cust_email_id="ONE_CLK_CUST_EMAIL";
			public static final String pymnt_oneclk_chk_flag = "ONE_CLK_CHK_FLG";
			public static final String pymnt_oneclk_chk_agree_flag = "ONE_CLK_CHK_AGREE_FLG";
			public static final String riskAlertOneClickCheckout = "OneClickCheckout";
			public static final String pymnt_oneclk_chk_agree_flag_cancel = "ONE_CLK_CHK_AGREE_FLG_CANCEL";
			public static final String pymnt_other_debit_flag = "ONE_CLK_OTHER_DEB_FLG";
			//Added for One Click Checkout	
			
			
			public static final String aggr_netbanking_janata_bankid = "JSB";
			public static final String aggr_netbanking_mrchcode = "PID";
			public static final String aggr_netbanking_sbi_mrchcode = "merchant_code";
			public static final String aggr_netbanking_sbi_encdata = "encdata";
			public static final String aggr_netbanking_sbi_bkrefno = "BankRefNo";
			public static final String aggr_netbanking_sbi_mkrefno="MerchantRefNo";
			public static final String aggr_netbanking_united_bank_paid = "PAID";
			public static final String aggr_netbanking_united_bank_bid = "BID";
			public static final String aggr_netbanking_united_bank_statflg="STATFLG";
			public static final String aggr_netbanking_united_bank_action = "Action.ShoppingMall.Login.Init";
			public static final String aggr_netbanking_united_bank_id = "BankId";
			public static final String aggr_netbanking_united_bank_cg = "CG";
			public static final String aggr_netbanking_united_bank_user_type = "UserType";
			public static final String aggr_netbanking_united_bank_app_type = "AppType";
			public static final String aggr_netbanking_united_bank_user_lang_id = "USER_LANG_ID";
			public static final String aggr_netbanking_bank_id = "BANK_ID";
			public static final String aggr_netbanking_cub_mrchcode = "merchantcode";
			public static final String aggr_netbanking_cub_tid = "TID";
			public static final String aggr_netbanking_cub_status = "STATUS";
			public static final String aggr_netbanking_mrchrefno = "PRN";
			public static final String aggr_netbanking_sbi_mrchrefno = "MerchantRefNo";
			public static final String aggr_netbanking_cub_mrchrefno = "BRN";
			public static final String aggr_netbanking_amt = "AMT";
			public static final String aggr_netbanking_sbi_amt = "TxnAmount";
			public static final String aggr_netbanking_modeofoperation = "MD";
			public static final String aggr_netbanking_cub_modeofoperation = "trantype";
			public static final String aggr_netbanking_cub_acc = "ACCNO";
			public static final String aggr_netbanking_cub_nar = "NAR";
			public static final String aggr_netbanking_cub_checksum ="CHECKSUM";
			public static final String aggr_netbanking_currncy = "CRN";
			public static final String aggr_netbanking_return_url = "RU";
			public static final String aggr_netbanking_sbi_return_url = "returnurl";
			public static final String aggr_netbanking_item_code = "ITC";
			public static final String aggr_netbanking_cg = "CG";
			public static final String aggr_netbanking_resp_type = "RESPONSE";
			public static String fssaggrnetbanking_RU = "/fssaggrnetbankingRes.htm";
			public static final String aggr_netbanking_url = "BANKURL";
			public static final String aggr_netbanking_bankid = "BANKID";
			public static final String aggr_netbanking_prefix = "PREFIX";
			public static final String aggr_netbanking_date = "AGGR_NETBANKING_DATE";
			public static final String aggr_netbanking_inquiry_url = "INQUIRY_URL";
			public static final String aggr_netbanking_inquiry_status_success = "S";
			public static final String aggr_netbanking_inquiry_status_fail = "F";
			public static final String pymnt_term_aggr_fc_flag="AGGRFCFLAG";
			
			public static final String aggr_inquiry_status = "INQUIRY_STATUS";
			public static final String aggr_inquiry_success = "SUCCESS";
			public static final String aggr_inquiry_failure = "FAILURE";
			public static final String aggr_netbanking_key = "AGGR_NETBANKING_KEY";
			
			public static final String aggr_pymnt_contvty_type_pg = "1";
			public static final String aggr_pymnt_contvty_type_netbanking = "2";
			
			public static final String aggr_pymnt_instrmnt_brandtype ="AGGR_BRAND_TYPE";
			//Fss Aggregator-Starts
			public static final String aggr_key_store_location = "AGGREGATOR_KEY_STORE_LOCATION";
			//Fss Aggregator-Ends
			
			public static final String aggr_extrConn_aliasName ="AGGR_PG_Terminal_Alias_Name";
			public static final String aggr_extrConn_resrcPath ="AGGR_PG_Terminal_Resource_Path";
			public static final String aggr_extrConn_tranportalId ="AGGR_PG_TranportalId";
			public static final String aggr_extrConn_tranportalPwd ="AGGR_PG_TranportalPwd";
			public static final String aggr_extrConn_URL ="AGGR_EXTRCONN_URL";
			public static final String aggr_extrConn_termKey ="AGGR_EXTRCONN_TERMKEY";
			
			/*Code Added for GSTN starts*/
			public static final String gstn_key_path = "GSTN_KEY_PATH";
			public static final String gstn_flag = "GSTN_FLAG";
			public static final String gstn_txn_id = "GSTN_TXN_ID";
			
			public static final String gstn_tran_log = "GSTN_TRAN_LOG";
			public static final String gstn_payment_id = "GSTN_PAYMENT_ID";
			public static final String gstn_gstin = "GSTN_GSTIN";
			public static final String gstn_cpin = "GSTN_CPIN";
			public static final String gstn_cgstamt = "GSTN_CGSTAMT";
			public static final String gstn_igstamt= "GSTN_IGSTAMT";
			public static final String gstn_track_id = "GSTN_TRACK_ID";
			public static final String gstn_sgstamt = "GSTN_SGSTAMT";
			public static final String gstn_total_amt = "GSTN_TOTAL_AMT";
			public static final String gstn_merchant = "GSTN_MERCHANT";
			public static final String gstn_payment_init_time = "GSTN_PAYMENT_INIT_TIME";
			public static final String gstn_terminal_id = "GSTN_TERMINAL_ID";
			public static final String gstn_return_url = "GSTN_RETURN_URL";
			public static final String gstn_request_date_time= "GSTN_REQUEST_DATE_TIME";
			public static final String gstn_beneficiary_state_code = "GSTN_BENEFICIARY_STATE_CODE";
			public static final String gstn_bankcode = "GSTN_BANK_CODE";
			public static final String gstn_hmac = "GSTN_HMAC";
			
			public static final String gstn_status_failure = "0";
			public static final String gstn_status_success = "1";
			
			public static final String gstn_success = "SUCCESS";
			public static final String gstn_failed = "FAILED";
			public static final String gstn_pending = "PENDING";
			public static final String gstn_invalid = "INVALID";
			
			public static final String PMT9000 = "PMT9000";
			public static final String PMT9000_message = "Payment Transaction failed";
			public static final String PMT9001 = "PMT9001";
			public static final String  PMT9001_message = "Malformed Request";
			public static final String  PMT9002 = "PMT9002";
			public static final String  PMT9002_message = "Invalid CPIN";
			public static final String  PMT9008 = "PMT9008";
			public static final String PMT9008_message =  "Invalid Merchant ID";
			public static final String  PMT9007 = "PMT9007";
			public static final String  PMT9007_message = "Message Tampered";
			
			public static final String  PMT9004="PMT9004";
			public static final String  PMT9004_message = "Challan already paid";
			public static final String  PMT9010 = "PMT9010";
			public static final String  PMT9010_message = "Request is Stale";
			/*code added for GSTN fix -starts*/
			/*Code Added for GSTN Remmitance starts*/
			public static final String  PMT9013 = "PMT9013";
			public static final String  PMT9013_message = "Invalid Transaction";
			//Code Added for GSTN Implementation : Jothieshwar plugin Fix Starts
			public static final String  PMT9019 = "PMT9019";
			//Code Added for GSTN Implementation : Jothieshwar plugin Fix Ends
			public static final String  PMT9019_message = "S2S timeout";
			public static final String PMT9015 = "PMT9015";
			public static final String PMT9015_message = "Browser Refresh";
			public static final String PMT9014 = "PMT9014";
			public static final String PMT9014_message = "User pressed back button";
			public static final String PMT9017 = "PMT9017";
			public static final String PMT9017_message ="Session expiry/timeout";
			public static final String PMT9016 = "PMT9016";
			public static final String PMT9016_message ="Aborted the transaction";
			public static final String cess_amt="GSTN_CESSAMT";
			/*Code Added for GSTN Remmitance ends*/
			/*code added for GSTN fix -Ends*/
			public static final String gstn_action_ONLPMT = "ONLPMT";
			public static final String gstn_action_ODVPMT = "ODVPMT";	
			public static final String gstn_merchant_id = "GSTN";
			public static final String B24_SWITCH_CONNECTIVITY_FLAG = "B24_SWITCH_CONNECTIVITY";
			public static final String DIRECT_B24_SWITCH_FLAG = "D";
			public static final String FSSNET_B24_SWITCH_FLAG = "F";
			/*Code Added for GSTN ends*/
			
			//Code Added for GSTN Implementation : Jothieshwar Starts
			public static final String gstn_merchant_id_int = "999999998";
			//Code Added for GSTN Implementation : Jothieshwar Ends
			/*Code Added for GSTN fix - Starts*/
			public static final String checkCredit="C";
			public static final String checkCreditDebit="checkCreditDebit";
			public static final String cardNumber="cardNumber";
			/*Code Added for GSTN fix - Ends*/
			//*Code Added for GSTN Remmitance starts*/
			public static final String gstn_cpin_validation_path="GSTN_CPIN_VALIDATION_PATH";
			public static final String gstn_remittance_path="WEBSERVER_URL_FOR_GSTN_REMITTANCE_URL";
			public static final String gstn_cpin_status="VCIPN";
			public static final String gstn_remittance_action = "CCDCRMT";
			public static final String  PMT9012 = "PMT9012";
			public static final String  PMT9012_message = "Invalid CIN";
			/*Code Added for GSTN Remmitance ends*/
			//Code Added for GSTN Remittance Upload : Malathi Starts
		    public static final String gstnRemittance_upload_error_file = "GSTNRemittanceErrorData.txt";
		    public static final String gstnRemittance_upload_process_error_file = "GSTNRemittanceProcessErrorData.txt";
		    public static final String gstnRemittance_realisation_datefmt = "dd/MM/yyyy";
    //GSTN Remittance Upload Fix : Malathi Starts
		    //public static final String gstnRemittance_realisation_timefmt = "HH:mm:ss";
		    
		    public static final String gstnRemittance_gstn_txn_id = "GSTN TXN ID";
		    public static final String gstnRemittance_bank_ref_num = "Bank Reference Number";
		    public static final String gstnRemittance_realisation_date = "Realisation Date";
		    public static final String gstnRemittance_realisation_time = "Realisation Time";
		    
		    //Code Added for GSTN Remittance Upload : Malathi Ends
			public static final String gstnRemittance_upload_amt = "Amount";     
    		public static final String gstnRemittance_realisation_timestampfmt = "dd/MM/yyyy HH:mm:ss";
    		public static final String gstnRemittance_realisation_timefmt = "dd/MM/yyyy HH:mm:ss or dd/MM/yyyy";
			//Code Added for GSTN - Response Changes - Starts
		    public static final String Creditcard="CC";
		    public static final String DirectDebit="DD";
		    public static final String Debitcard="DC";
		    public static final String gstn_check_instrument="C";
		    public static final String gstn_credit_instrument="CC";
		    public static final String gstn_debit_instrument="DC";
		    /**Added for Rupay**/
			public static final String pymnt_instrmnt_rupay="RDC";
			/**Added for Rupay**/
		    //Code Added for GSTN - Response Changes - Ends
		    //Added for Cardbin in final response -starts
			public static final String card_bin_txn="CARD_BIN";
			//Added for Cardbin in final response -ends
			
			public static final String IPAY_FSS_AGGR_LOGO_TEMP_PATH = "IPAY_FSS_AGGR_LOGO_TEMP_PATH";
			public static final String IPAY_FSS_AGGR_LOGO_WIDTH = "IPAY_FSS_AGGR_LOGO_WIDTH";
			public static final String IPAY_FSS_AGGR_LOGO_HEIGHT = "IPAY_FSS_AGGR_LOGO_HEIGHT";
			
		
			//Added for Merchant saved card
			public static final String MERCHANT_SAVEDCARD_FLAG_ENABLED="Y";
			//Ends
			
			/*Code Added for changing the Brand ID to Brand name for HDFC starts*/
			public static final String pymnt_brnd_name = "BRAND_NAME";
			/*Code Added for changing the Brand ID to Brand name for HDFC Ends*/
			public static final String aggr_amex_mode="AGGR_AMEX_MODE";
			public static final int aggr_amex_mode_1=1;
			public static final int aggr_amex_mode_2=2;
			public static final int aggr_connectivity_type_pg=1;
			public static final int aggr_connectivity_type_interchange=3;
			public static final String aggr_interchange_type_amex="A";
			public static String fssaggramex_RU = "/fssAggrAmexRes.htm";
			public static final String pymnt_result_code_amex_capture = "RESULT_CODE_AMEX_CAPTURE";
			public static final String pymnt_response_code_amex_capture = "RESPONSE_CODE_AMEX_CAPTURE";
			public static final String pymnt_amex_capture_bank_auth_id = "AMEX_CAPTURE_BANK_AUTH_ID";
			public static final String pymnt_amex_capture_pymnt_tran_id = "AMEX_CAPTURE_PYMNT_TRAN_ID";
			public static final String pymnt_amex_capture_receipt_no = "AMEX_CAPTURE_RECEIPT_NO";
			public static final String pymnt_amex_vpc_accesscode = "AMEX_VPC_ACCESS_CODE";
			public static final String pymnt_amex_vpc_merchantcode = "AMEX_VPC_MERCHANT_CODE";
			public static final String pymnt_amex_vpc_username = "AMEX_VPC_USERNAME";
			public static final String pymnt_amex_vpc_pwd = "AMEX_VPC_PWD";
			public static final String pymnt_amex_vpc_domain = "AMEX_VPC_DOMAIN";
			public static String fssaggramex_mode2_redirect = "/views/fssaggr/payment/AuthorizationForm.jsp?";
			
			/** Added By Kaliappan J for Preauth : Starts **/
			public static final String preauth_udf_1 = "PA";
			/** Added By Kaliappan J for Preauth : Ends **/
			
			public static final String institution_mca_flag = "MAKER_CHECKER_FLAG";
			public static final String PYMNT_TERMINAL_TXNRETRY_FLAG= "TERMINAL_TXN_RETRY_FLAG";
			//Added for FssAggr Aggregator Logo for Branding -Starts
			public static final String fss_aggr_branding_location = "FSS_AGGR_BRANDING_LOCATION";
			public static final String fss_aggr_logo_width = "FSS_AGGR_LOGO_WIDTH";
			public static final String fss_aggr_logo_height = "FSS_AGGR_LOGO_HEIGHT";
			public static final String branding_aggr = "AGGREGATOR";
			public static final String branding_aggr_header = "Header";
			
			//Added for FssAggr Aggregator Logo for Branding -Ends
			//Added for FssAggr Aggregator Merchant Branding-Starts
			public static final String fss_aggr_mrch_logo_width = "FSS_AGGR_MRCH_LOGO_WIDTH";
			public static final String fss_aggr_mrch_logo_height = "FSS_AGGR_MRCH_LOGO_HEIGHT";
			public static final String branding_aggr_mrch = "AGGREGATORMERCHANT";
			public static final String branding_aggr_css = "CSS";
			public static final String file_name_css="aggrpaypage-theme.css";
			//Added for FssAggr Aggregator Merchant Branding-Ends	
			//Added by Anusha R To Insert value in UDF1 for Pre Auth-starts
			public static final String pre_auth_udf1="PA";
			//Added by Anusha R To Insert value in UDF1 for Pre Auth-ends
			
			public static final String pymnt_mrch_errorstrs = "!ERROR!-";
			//Added for EBS Integration by Madhu Ram Kumar C.
			public static final String aggr_connectivity_type_PymtAggr="4";
			public static final String aggr_connectivity_type_IB="2";
			
			//PG types
			public static final int aggr_pg_type_ipay2_1=1;
			public static final int aggr_pg_type_ipay3_0=2;
			public static final int aggr_pg_type_ipay3_1=3;
			public static final int aggr_pg_type_acipg=4;
			public static final int aggr_pg_type_axispg=5;
			public static final String aggr_extrConn_pgType="FSS_AGGR_EXTR_CONN_PG_TYPE";
			public static final String aggr_extrConn_prtcl_tcpip="tcpip";
			public static final String aggr_Tran_retry_count="AGGR_TRAN_RETRY_COUNT";
			
			public static final String pymnt_axispg_vpc_domain = "AXISPG_VPC_DOMAIN";
			public static final String pymnt_axispg_vpc_accesscode = "AXISPG_VPC_ACCESS_CODE";
			public static final String pymnt_axispg_vpc_pwd = "AXISPG_VPC_PWD";
			public static final String pymnt_axispg_vpc_merchantcode = "AXISPG_VPC_MERCHANT_CODE";
			public static final String pymnt_axispg_vpc_username = "AXISPG_VPC_USERNAME";
			
			public static final String aggr_axispg_mode="AXISPG_AMEX_MODE";
			public static final int aggr_axispg_mode_1=1;
			public static final int aggr_axispg_mode_2=2;
			public static String fssaggraxispg_RU = "/fssAggrAxisPgRes.htm";
			
			
			
			//Added by Anusha R for FssAggr Branding in aggrPayment page-starts
			public static final String fss_aggr_default_style_css = "AGGR_STYLE_CSS";				
			public static final String fss_aggr_pymnt_aggr_logo = "AGGR_LOGO";
			//Added by Anusha R for FssAggr Branding in aggrPayment page-ends
			
			//Added by Jeeva D for Aggregator paymentpage cancel
			public static final String pymnt_status_cancelled="CANCELLED";
			
			public static String fssconnect_txn_success = "000";
			public static String fssconnect_msg_rejected_sm = "002";
			public static String fssconnect_unable_to_process_msg = "003";
			public static String fssconnect_destn_not_available = "004";
			public static String fssconnect_invalid_input = "005";
			public static String fssconnect_duplicate_msg = "006";
			public static String fssconnect_destn_not_logged_or_connction_closed = "007";
			public static String fssconnect_declined_requst_get_method = "008";
			public static String fssconnect_txn_initiated_with_invalid_src = "009";
			public static String fssconnect_invalid_unique_id = "010";
			public static String fssconnect_ip_blocked = "011";
			public static String fssconnect_ip_not_configured= "012";
			public static String fssconnect_remote_ip_not_configured= "013";
			public static String fssconnect_invalid_input_format= "014";
			
			public static String pymnt_report_status="REPORT_STATUS"; 
			public static final int VPAS_Successful_PARES = 9;
		    public static final int  VPAS_failed_PARES = 8;
		    public static final int VPAS_unable_authorize = 10;
		    
			public static final String aggr_contvty_through = "AGGR_CONNTVITY_THRO";
			public static final String aggr_contvty_through_merch = "M";
			public static final String aggr_contvty_through_aggr = "A";
			
			
			//Added for EBS Integration
			public static final String aggr_ebs_channel ="channel";
			public static final String aggr_ebs_stndrd_channel ="0";
			public static final String aggr_tran_conntvty_type ="CONNECTIVITY_TYPE";
			public static final String aggr_netbanking_id ="AGGRNETBANKING_ID";
			public static final String aggr_netbanking_name ="AGGRNETBANKING_NAME";
			public static final String aggr_netbanking_pymnt_optncd ="AGGRNETBANKING_OPTN_CODE";
			public static final String aggr_extr_conthrgh_merchant ="M";
			public static final String aggr_extr_conthrgh_aggregator ="A";
			public static final String aggr_extrConn_aggr_code ="PYMNT_AGGR_CODE";
			public static final String aggr_extrConn_aggr_name ="PYMNT_AGGR_NAME";
			public static final String aggr_extrConn_aggr_prefix ="PYMNT_AGGR_PREFIX";
			public static final String aggr_extrConn_aggr_url ="PYMNT_AGGR_URL";
			public static final String aggr_extrConn_aggr_inq_url ="PYMNT_AGGR_INQ_URL";
			public static final String aggr_extrConn_aggr_conthrgh ="CON_THROUGH";
			public static final String aggr_extrConn_aggr_mrchid="AGGR_EXTR_MRCH_ID";
			public static final int aggr_connectivity_type_internetbanking=2;
			public static final int aggr_connectivity_type_pymnt_aggr=4;
			public static String fssaggrebs_RU = "/fssaggrEbsRes.htm";
			public static final String aggr_extrConn_ebsacntId ="account_id";
			public static final String aggr_extrConn_ebsadrs ="address";
			public static final String aggr_extrConn_ebs_algrtm ="algo";
			public static final String aggr_extrConn_ebs_sha512 ="SHA512";
			public static final String aggr_extrConn_ebs_amount ="amount";
			public static final String aggr_extrConn_ebs_city ="city";
			public static final String aggr_extrConn_ebs_cntry ="country";
			public static final String aggr_ebs_cntry_ind ="IND";
			public static final String aggr_ebs_currency= "currency";
			public static final String aggr_ebs_currency_inr= "INR";
			public static final String aggr_ebs_descrptn= "description";
			public static final String aggr_ebs_email= "email";
			public static final String aggr_ebs_mode= "mode";
			public static final String aggr_ebs_mode_live= "LIVE";
			public static final String aggr_ebs_name= "name";
			public static final String aggr_ebs_pymnt_optn= "payment_option";
			public static final String aggr_ebs_phone= "phone";
			public static final String aggr_ebs_postal_code= "postal_code";
			public static final String aggr_ebs_return_url= "return_url";
			public static final String aggr_ebs_ref_num= "reference_no";
			public static final String aggr_ebs_secure_hash= "secure_hash";
			public static final String aggr_ebs_url= "EBSurl";
			public static final String aggr_ebs_refund_inq_url= "EBS_REFUND_INQ_URL";
			public static final String aggr_ebs_key= "EBS_HASH_KEY";
			
			public static final String pymnt_authentication_type = "AUTHENTICATION_TYPE";
			public static final String pymnt_cvv_pin = "VP";
			public static final String pymnt_cvv = "V";
			public static final String pymnt_pin = "P";
			public static final String card_already_registered = "CARD_ALREADY_REGISTERED";
			public static final String new_card_added = "NEW_CARD_ADDED";
			public static final String card_status_change = "CARD_STATUS_CHANGE";
			public static final String aggr_trnprtl_flg = "AGGR_TRANPORTAL_FLG";
			public static final String RISK_CHECK_PAYMENTID = "RISK_PAY_ID";
			public static final String RISK_CHECK_TRAN_ALERT_HISTRY_ID = "TRAN_ALERT_HISTRY_ID";
			
			
			public static final String aggr_pg_intgrtn_id = "PG_AGGR_INTGRTN_ID";
			public static final String aggr_pg_intgrtn_pwd = "PG_AGGR_INTGRTN_PWD";
			public static final String pymnt_trans_id = "TransID";
			public static final String aggr_pg_udf1 = "AGGR_PG_UDF1";
			public static final String aggr_pg_udf2 = "AGGR_PG_UDF2";
			public static final String aggr_pg_udf3 = "AGGR_PG_UDF3";
			public static final String aggr_pg_udf4 = "AGGR_PG_UDF4";
			public static final String aggr_pg_udf5 = "AGGR_PG_UDF5";
			public static final char aggr_card_mask	= '1';
			
			
			//Added by Pandiselvi A - Pin block using HSM
			public static final String RESULT_BOOLEAN="result";
			public static final String HSM_RESULT="HSM_RESULT";
			public static final String HSM_TYPE="HSM_TYPE";
			public static final String ALTER_EXTR_CONN_LIST="ALTER_EXTR_CONN_LIST";
			public static final String RESPONSE_CODE="resp_code";
			public static final String COMMON_NODE_JS_RESPONSE_CODE="respCode";
			public static final String COMMON_NODE_JS_RESPONSE_DESCRIPTION="respDescription";
			public static final String HSM_SAFENET_DECRYPT_COMMAND="EE0805";
			public static final String HSM_SAFENET_ENCRYPT_COMMAND="EE0804";
			public static final String HSM_SAFENET_CAVV_COMMAND="EE0802";
			public static final String HSM_SAFENET_SIGN_DATA_COMMAND="EE9005";
			public static final String HSM_SAFENET_PIN_DATA_COMMAND="EE0600";
			public static final String SUCCESS_RESPONSE="00";
			public static final String HSM_SAFENET_HEALTH_COMMAND="010000";
			
			public static final String SOFWARE_ENCRYPT_MODE="sofware";
			public static final String HARDWARE_ENCRYPT_MODE="hsm";
			public static final String HSM_SAFENET="SAFENET";
			public static final String HSM_RACAL="RACAL";
			public static final String HSM_DATA="HSM_DATA";
			public static final String HSM_PRIME_EXTR_CONN = "HSM_PRIME_EXTR_CONN";
			public static final String HSM_ALTER_EXTR_CONN = "HSM_ALTER_EXTR_CONN";
			public static final String HSM_SOURCE_KEY="HSM_SOURCE_KEY";
			public static final String HSM_HEADER="HEADER";
			public static final String HSM_ENCRYPT_MODE="HSM_ENCRYPT_MODE";
			public static final String HSM_KEY_SPEC="HSM_KEY_SPEC";
			public static final String HSM_INPUT_CHAIN_VALUE="HSM_INPUT_CHAIN_VALUE";
			public static final String HSM_ATN="HSM_ATN";
			public static final String HSM_SERVICE_CODE="HSM_SERVICE_CODE";
			public static final String HSM_CAVV_PADD="HSM_CAVV_PADD";
			public static final String HSM_STATIC="static";

			public static final String HSM_SIGN_HASH_FUNCTION="HSM_SIGN_HASH_FUNCTION";
			public static final String PIN_BLCK_MTD="PIN_BLCK_MTD";
			public static final String HSM_PIN_ANB="HSM_PIN_ANB";
			public static final String HSM_PIN_LENGTH="HSM_PIN_LENGTH";
			
			public static final String OTP_NODE_JS_SOURCE="source";
			public static final String OTP_NODE_JS_MSG="message";
			public static final String OTP_NODE_JS_DESTINATION="destination";
			public static final String OTP_NODE_JS_RRN="uniqueId";
			public static final String COMMON_NODE_JS_RESPONSE_REQUIRED="responseRequired";
			public static final String COMMON_NODE_JS_TIMESTAMP="timestamp";
			public static final String COMMON_NODE_JS_ALTR_SRC_ARRY="alternateSrcArray";
			public static final String COMMON_NODE_JS_ALTR_DES_ARRY="alternateDestArray";
			public static final String COMMON_NODE_JS_IIN="iin";
			public static final String COMMON_NODE_JS_RESPONSE_REQUIRED_VALUE="1";
			public static final String PIN_ENCR_MODE="PIN_ENCR_MODE";
			public static final String PIN_ENCR_ALG="PIN_ENCR_ALG";
			public static final String PIN_ENCR_PADDING_TYPE="PIN_ENCR_PADDING_TYPE";
			public static final String PIN_BLCK_FORMAT="PINBLOCK_FORMAT";
			public static final String PIN_KEY_PATH="PIN_KEY_PATH";
			public static final String PIN_KEY_ALISE_NAME="PIN_KEY_ALISE_NAME";
			public static final String PIN_BLOCK_FORMAT_ANSI="ANSI";
			public static final String CONNECT_VIA_NODEJS="0";
			public static final String PIN_ASYNC_RESULT="PIN_ASYNC_RESULT";
			public static final String PIN_SYNC_RESULT="PIN_SYNC_RESULT";
			
			public static final String LATE_GOOD_RESP="LATE_GOOD_RESP";
			public static final String SAF_HOST_TIMEOUT="H";
			public static final String SAF_LATE_GOOD="L";
			
			//End
			//ICICI PG-Aggregator Integration Changes-starts
			public static final String aggr_icici_extr_conn ="ICICI DEBIT PIN";
			public static final String aggr_icici_resp_URL ="ICICI_PG_Response_url";
			public static final String aggr_icici_tranid ="TRANID";	
			//ICICI PG-Aggregator Integration Changes-ends
			public static final String aggr_bank_code ="ISSUER_BANK_CODE";
					
			public static final String terminal_app_pwd = "TERMINAL_APP_PWD";
			public static final String terminal_app_type = "TERMINAL_APP_TYPE";
			
			//ICICI PG-Aggregator Tranportal Changes
			public static final String aggr_icici_tranresp_URL ="ICICI_PG_Tran_Resp_url";
			
			//SBI PG-Aggregator Changes
			public static final int aggr_pg_type_sbi=6;
			public static final String aggr_sbi_resp_URL ="SBI_Host_Responseurl";
			public static final String ipaddressString ="ipaddressString";
			
			// Bank list filtering based on Terminal by Madhu Ram Kumar C. -starts
			public static final String pymnt_term_aggr_acptBnkLst_DP ="ACCPT_BNK_LST_DP";
			public static final String pymnt_term_aggr_acptBnkLst_DD ="ACCPT_BNK_LST_DD";
			// Bank list filtering based on Terminal by Madhu Ram Kumar C. -ends
			public static final String aggr_intrptd_txn_ms ="AGGR_TXN_MS";
			public static final String old_keystore_path="OLD_KEYSTORE_PATH";
			public static final String old_keystore_pwd="OLD_KEYSTORE_PWD";
			public static final String old_keystore_alias="OLD_KEYSTORE_ALIAS";
			
			
			  public static final String alternate_destn_conn_status="NODEJS_ALTERNATE_DESTN_CONN_STAT";
			 
			public static final String DUMMY_CARD_NO="XXXXXXXXXXXXXXXX-XX-XXXX-XXX-XXX-XXX";
			
			//Ineterrupted txn handler - starts by Madhu Ram Kumar C.
			public static final String aggr_intrptd_txn_udf14 ="INTERRUPTED_TRANSACTION";
			public static final String aggr_intrptd_txn_refnd_flag ="INTRPTD_TXN_REFUND_FLAG";
			public static final String aggr_intrptd_txn_failed ="FAILURE";
			public static final String aggr_intrptd_txn_sucess ="CAPTURED";
			public static final String aggr_intrptd_txn ="INTERRUPTED_TRANSACTION";
			public static final String aggr_mer_inq_prsentd = "MRCHNT_INQ_PRESENTED";
			
			//Kotak
			//public static String aggr_netbanking_merchid_kotak="OSBSGTEST";
			public static String aggr_netbanking_seperator_kotak="|";
			public static String aggr_netbanking_purchase_kotak="0500";
			public static String aggr_netbanking_response_kotak="0502";
			public static String aggr_netbanking_bankrefno_kotak="BANK_REF_NUM";
			public static String aggr_netbanking_desc_kotak="DESC";
			public static String aggr_netbanking_status_kotak="STATUS";
			public static String aggr_netbanking_msg_kotak="msg";
			public static String aggr_netbanking_dateandtime_kotak="DATE";
			public static String aggr_netbanking_inquiry_kotak="0520";
			public static String aggr_netbanking_checksum_kotak="CHECKSUM";
			
			public static final int PYMNT_TRAN_STATUS_AUTHERROR = 4;
			/*code added for redirect-starts*/
			public static String browser_agent="User-Agent";
			public static String http_accept="accept";
			//public static final String ENABLE_RUPAY_REDIRECTION_BANK = "ENABLE_RUPAY_REDIRECTION_BANK";
			/*code added for redirect-ends*/
			
			//Code added for HDFC instId changes starts
			public static final String hdfc_new_paypage ="NEW_PAYPAGE_INSTITUTION";
			//Code added for HDFC instId changes ends
			
			/*** Added for UPI Integration : Starts ***/
		    public static final String UPI="%UPI%";
		    public static final String UPI_FLAG="1";
		    public static final String pymnt_instrmnt_upi="UPI";
		    public static final String  upi_webserver_url="UPI_WEBSERVICE_URL";
		    public static final String upiPgTxnId="upiPgTxnId";
		    public static final String upiCustRefNo="UPI_CUST_REF_NO";
		    public static final String upiRefNo="UPI_REF_ID";
		    public static final String upiaaprNo="UPI_APPR_NO"; 
		    public static final String upiTransId="UPI_TRANS_ID";
		    public static final String upiRetryCount="UPI_RETRY_COUNT";
		    public static final String upiReadTimeout="UPI_READ_TIMEOUT"; 
		    public static final String upiConnectionTimeout="UPI_CONNECTION_TIMEOUT";
		    public static final String upiIdleTime="UPI_IDLE_TIME";
		    public static final String mindgate="MindGate";
		    /***Added for UPI Integration : Ends***/
}

