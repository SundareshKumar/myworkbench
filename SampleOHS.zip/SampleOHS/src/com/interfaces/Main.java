package com.interfaces;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Main {

	public static void main(String[] args) {
		String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ThreeDSecure><Message id=\"VEREQ201801281246888\"><VEReq><version>1.0.2</version><pan>4012001037141112</pan><Merchant><acqBIN>567</acqBIN><merID>201</merID><password>ellappav</password></Merchant></VEReq></Message></ThreeDSecure>";
		msg = msg.substring(msg.indexOf("<Message id=\""),msg.indexOf("<VEReq>"));
		System.out.println(msg.split("\"")[1]);
	}

}
