package com.interfaces;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import com.fss.iso.Type1ISOMessage;

public class Server {
	
	static int k = 0;
	
	public static void main(String[] args) throws IOException {
		new Server(8090).start();
	}

	int port;
	
	private boolean welcomeRequired = false;
	
	private int welcomeTimePeriod = 30000;
		
	Server(int port){
		this.port = port;
	}

	List<Handler> handlers = new ArrayList<Handler>();
	
	public void start() throws IOException {
		ServerSocket ss = new ServerSocket(port);
		while(true){
			Socket socket = ss.accept();
			synchronized (this) {
				if(handlers.size() < 200) {
					System.out.println("Accepting New Connection from : " + socket.getRemoteSocketAddress());
					//handlers.add(new Handler(socket, handlers.size() + 1));
					new Handler(socket, handlers.size() + 1);
				} else {
					System.out.println("Cannot accept more than 20 connections.");
				}
			}
		}
	}
	
	void remove(Handler handler){
		handlers.remove(handler);
		System.out.println("Removing Handler.");
		System.out.println("Total handlers currently running : " + handlers.size());
	}
	
	class Handler extends Thread {
		
		int id = 0;

		private Socket sock = null;
		
		BufferedReader reader = null;

		BufferedWriter bw = null;

		Handler() {
		}

		Handler(Socket sock, int id) {
			this.sock = sock;
			this.id = id;
			setDaemon(true);
			start();
		}
		
		public void run() {
//				try {
//			Thread.sleep(20000000l);
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
			try {
				if(welcomeRequired) {
					sock.setSoTimeout(welcomeTimePeriod);
				}
				reader = new BufferedReader(new InputStreamReader(sock
						.getInputStream()));
				bw = new BufferedWriter(new OutputStreamWriter(sock
						.getOutputStream()));
			} catch (Exception e) {
				System.out.println("Error while getting Streams.");
				if (reader != null)
					close();
					remove(this);
				return;
			}
			
			int timeout = 30 * 1000;
			
			long lastProcessedTime = System.currentTimeMillis();

			while (true) {
				try {
					if(welcomeRequired) {
						if((lastProcessedTime + timeout) < System.currentTimeMillis()) {
							String _800 = "ISO0060000400800822000000000000004000000000000000828103256206933001";
							try {
								write(_800, 4, 2);
								lastProcessedTime = System.currentTimeMillis();
							} catch (IOException e) {
								System.out.println("Socket Down");
								close();
								remove(this);
								return;		
							}							
						}
					}					
	
					String request = read(4, 2);
					if (request == null) {
						System.out.println("Nothing is read");
						close();
						remove(this);
						return;						
					} else {
						lastProcessedTime = System.currentTimeMillis();
						System.out.println("Request From Client : "
								+ new String(request));
						if(k == 0) {
							//Thread.sleep(11000L);
						} 
						//Thread.sleep(60000);
						processRequest(request);
					}
				}  catch (SocketTimeoutException ste) {
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Error while read-write");
					close();
					remove(this);
					return;
				}
			}
		}
		
		private void processRequest(String request) throws IOException 
		{
			System.out.println("Inside ProcessReq in Server::");
			Type1ISOMessage type1ISOMessage = new Type1ISOMessage();
			type1ISOMessage.unpack(request.getBytes());
			if(!type1ISOMessage.getMsgType().equals("0810")) 
			{
				if(type1ISOMessage.getMsgType().equals("0200"))
				{
					System.out.println("Inside 200::");
					type1ISOMessage.setMsgType("0210");
				}
				else if(type1ISOMessage.getMsgType().equals("0420") || type1ISOMessage.getMsgType().equals("0421"))
				{
					type1ISOMessage.setMsgType("0430");
				}
				else if(type1ISOMessage.getMsgType().equals("0220"))
				{
					type1ISOMessage.setMsgType("0230");
				}
				String details = type1ISOMessage.getStringElement(3);
				System.out.println("Details::"+details);
				String cardNoArr[] = type1ISOMessage.getStringElement(35).split("=");
				type1ISOMessage.setElement(2, cardNoArr[0]);
				if(k == 0) 
				{
					type1ISOMessage.setElement(39, "00");
				}
				else 
				{
					type1ISOMessage.setElement(39, "01");
				}
				byte[] resIsoMsg = type1ISOMessage.pack();
				new String(resIsoMsg);
				try
				{
				//	Thread.sleep(20000);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				write(new String(type1ISOMessage.pack()), 4, 2);
			}
			else 
			{
				System.out.println("0810 Message is Received.");
			}
			
		}

		void close() {
			try {
				reader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			if (bw != null)
				try {
					bw.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			if (sock != null)
				try {
					sock.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
		
		protected void write(String str, int transferType, int length)
		throws IOException {
	/*BufferedWriter bufferedWriter = new BufferedWriter(
			new OutputStreamWriter(_sock.getOutputStream()));*/
//			try {
//				
//				Thread.sleep(60*60*1000);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
	if (1 == transferType) {
		str = pad(str, ' ', length, true);
		bw.write(str); // Fixed length
	} else if (2 == transferType) {
		bw.write(str); // Variable length ends with new line
		bw.newLine();
	} else if (3 == transferType) {
		bw.write(pad(String.valueOf(str.length()), ' ', length,
				true));
		bw.write(str); // Variable length starts with Decimal
		// length header
	} else if (4 == transferType) {
		System.out
				.println("======================================================================");
		System.out.println("Writing : " + str);
		System.out
				.println("======================================================================");
		bw.write(pad(String.valueOf(toGraphical(str.length(),
				length)), ' ', length, true));
		bw.write(str);
		bw.flush();
		// Variable length starts with Graphical
		// length header
	} else if (5 == transferType) {
		bw.write(str); // Variable length ends with new line
	}
	bw.flush();
}

protected String read(int transferType, int length) throws IOException {
	/*BufferedReader bufferedReader = new BufferedReader(
			new InputStreamReader(_sock.getInputStream()));*/
	int ret;
	char[] chrBuf;
	String strBuf = "";
	if (1 == transferType) {
		chrBuf = new char[length]; // Fixed length
		ret = reader.read(chrBuf, 0, chrBuf.length);
		if (-1 == ret) {
			System.out.println("Error while reading response - " + ret);
			strBuf = null;
		} else {
			strBuf = new String(chrBuf);
		}
	} else if (2 == transferType) {
		strBuf = reader.readLine(); // Variable length ends with new
		// line
	} else if (3 == transferType) {
		chrBuf = new char[length]; // Variable length starts with Decimal
		// length header
		ret = reader.read(chrBuf, 0, chrBuf.length);
		if (-1 == ret) {
			System.out.println("Error : while reading response - " + ret);
			strBuf = null;
		} else {
			strBuf = new String(chrBuf);
			try {
				int resLength = Integer.parseInt(strBuf);
				chrBuf = new char[resLength];
				reader.read(chrBuf, 0, chrBuf.length);
				strBuf = new String(chrBuf);
			} catch (Exception e) {
				System.out
						.println("Error : while converting first 2 bytes to Number.");
				strBuf = null;
			}
		}
	} else if (4 == transferType) {
		chrBuf = new char[length];
		ret = reader.read(chrBuf, 0, chrBuf.length);
		if (-1 == ret) {
			System.out.println("Error : while reading response - " + ret);
			strBuf = null;
		} else {
			try {
				int len = (int) toDecimal(chrBuf);
				chrBuf = new char[len];
				reader.read(chrBuf, 0, chrBuf.length);
				strBuf = new String(chrBuf);
			} catch (Exception e) {
				System.out
						.println("Error : while converting first 2 bytes to Number.");
				strBuf = null;
			}
		}

	} else if (5 == transferType) {

		byte ETX = 0x03;
		chrBuf = new char[1]; // Variable length starts with Graphical
		// length header
		while (true) {
			ret = reader.read(chrBuf, 0, 1);
			strBuf = strBuf + new String(chrBuf);
			if (chrBuf[0] == (char) ETX)
				break;
		}

		ret = reader.read(chrBuf, 0, 1);
		strBuf = strBuf + new String(chrBuf);
	}
	chrBuf = null;
	return strBuf;
}

private long toDecimal(char[] graphical) {
	int length = graphical.length;
	long decimal = 0;
	for (int i = 0; i < graphical.length; i++) {
		length--;
		decimal += graphical[i] * (long) Math.pow(16, 2 * length);
	}
	return decimal;
}

private char[] toGraphical(long decimal, int length) {
	char[] graphical = new char[length];
	for (int i = 0; i < graphical.length; i++) {
		length--;
		graphical[i] = (char) (decimal / Math.pow(16, 2 * length));
		decimal %= Math.pow(16, 2 * length);
	}
	return graphical;
}

private String pad(String str, char ch, int length, boolean append) {
	String padStr = new String(str);
	if (length < str.length()) {
		return str.substring(0, length);
	}
	for (int i = str.length(); i < length; i++) {
		if (append) {
			padStr = padStr + ch;
		} else {
			padStr = ch + padStr;
		}
	}
	return padStr;
	}			
	}
	
}
