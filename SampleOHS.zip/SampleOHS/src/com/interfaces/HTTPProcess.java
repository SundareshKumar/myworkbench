package com.interfaces;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;

import org.omg.CORBA.LocalObject;

public final class HTTPProcess
{
	    public static final String POST = "POST";
	    public static final String GET = "GET";
	    private URL url;
	    private HttpURLConnection sendURL;
	    private boolean ssl;
	    int attempts;
	
    public HTTPProcess(String hostURL, boolean ssl)
    {
        url = null;
        sendURL = null;
        this.ssl = false;
        try
        {
            url = new URL(hostURL.trim());
        }
        catch(MalformedURLException e)
        {
        }
        this.ssl = ssl;
    }

    public byte[] sendMessage(byte[] abyte0, String s)
    {
        return sendMessage(abyte0, s, null, false, null);
    }

    public byte[] sendMessage(byte[] abyte0, String s, String s1)
    {
        return sendMessage(abyte0, s, s1, false, null);
    }

    public byte[] sendMessage(byte[] abyte0, String s, boolean flag)
    {
        return sendMessage(abyte0, s, null, flag, null);
    }
    
    public byte[] sendMessage(byte[] msg, String requestMethod, String contentType, boolean noResponse, LocalObject tranObject)
    {
         BufferedOutputStream out = null;
         BufferedInputStream in = null;
         String vpastimeoutflag=null;
         
         try
         {
             if(url == null)
             {
                 return null;
             }
            
             sendURL = (HttpURLConnection)url.openConnection();
             requestMethod = requestMethod.toUpperCase();
             if(!"POST".equals(requestMethod) && !"GET".equals(requestMethod))
             {
                 return null;
             }
             sendURL.setRequestMethod(requestMethod);
             sendURL.setDoOutput(true);
             sendURL.setDoInput(true);
             sendURL.setAllowUserInteraction(false);
            
             if(contentType != null)
                 sendURL.setRequestProperty("Content-Type", contentType);
             if(msg != null && msg.length > 0)
             {
                 sendURL.setRequestProperty("Content-Length", String.valueOf(msg.length));
                 out = new BufferedOutputStream(sendURL.getOutputStream());
                 out.write(msg, 0, msg.length);
                 out.flush();
                 out.close();
             }
             if(noResponse)
                 return null;
             int length = sendURL.getContentLength();
             byte[] bytes;
             if(length < 0)
             {
                 ByteArrayOutputStream bout = new ByteArrayOutputStream(128);
                 in = new BufferedInputStream(sendURL.getInputStream());
                 do
                 {
                     int b = in.read();
                     if(b == -1)
                         break;
                     bout.write(b);
                 } while(true);
                 bytes = bout.toByteArray();
                 return bytes;
             }
             bytes = new byte[length];
             in = new BufferedInputStream(sendURL.getInputStream());
             int pos;
             int numBytesRead;
             for(pos = 0; pos < length; pos += numBytesRead)
             {
                 numBytesRead = in.read(bytes, pos, length - pos);
                 if(numBytesRead != -1)
                     continue;
                 break;
             }
             return bytes;
         }
             
         catch (ConnectException ce) {
         	ce.printStackTrace();
             return null;
 		}  catch (SocketTimeoutException ste) {
             return null;
 		} 
         catch(Exception e) {
         	e.printStackTrace();
            return null;
         }
         finally
         {
        	 try 
        	 {
        		 if(in!=null)
        		 {
        			 in.close();
        			 in=null;
        		 }
        		 if(out!=null)
        		 {
        			 out.close();
        			 out=null;
        		 }
        		 if(sendURL!=null)
        		 {
        			 sendURL.disconnect();
        			 sendURL=null;
        		 }
        	 }
        	 catch (Exception e) 
        	 {
        	 }
         }
       
    }
    
    
    public byte[] sendMessage(byte msg[], String requestMethod, String contentType, boolean noResponse,int timeOut,int retryAttempts) throws ConnectException
    {
    	 
         BufferedOutputStream out = null;
         BufferedInputStream in = null;
         try
         {
             if(url == null)
             {
            	 return null;
             }

             sendURL = (HttpURLConnection)url.openConnection();
             requestMethod = requestMethod.toUpperCase();
             if(!requestMethod.equals("POST") && !requestMethod.equals("GET"))
             {
            	 return null;
             }
             sendURL.setRequestMethod(requestMethod);
             sendURL.setDoOutput(true);
             sendURL.setDoInput(true);
             sendURL.setAllowUserInteraction(false);
             sendURL.setConnectTimeout(timeOut*1000);
             sendURL.setReadTimeout(timeOut*1000);
             if(contentType != null)
                 sendURL.setRequestProperty("Content-Type", contentType);
             if(msg != null && msg.length > 0)
             {
                 sendURL.setRequestProperty("Content-Length", String.valueOf(msg.length));
                 out = new BufferedOutputStream(sendURL.getOutputStream());
                 out.write(msg, 0, msg.length);
                 out.flush();
                 out.close();
             }
             if(noResponse)
                 return null;
             int length = sendURL.getContentLength();
             byte bytes[];
             if(length < 0)
             {
                 ByteArrayOutputStream bout = new ByteArrayOutputStream(128);
                 in = new BufferedInputStream(sendURL.getInputStream());
                 do
                 {
                     int b = in.read();
                     if(b == -1)
                         break;
                     bout.write(b);
                 } while(true);
                 bytes = bout.toByteArray();
                 return bytes;
             }
             bytes = new byte[length];
             in = new BufferedInputStream(sendURL.getInputStream());
             int pos;
             int numBytesRead;
             for(pos = 0; pos < length; pos += numBytesRead)
             {
                 numBytesRead = in.read(bytes, pos, length - pos);
                 if(numBytesRead != -1)
                     continue;
                 break;
             }
             return bytes;
         }
         	
         catch(ConnectException e)
         {
        	 

        	 if(attempts<retryAttempts)
        	 {
        		 attempts++;
        		 sendMessage(msg, requestMethod, contentType, noResponse, timeOut, retryAttempts);
        	 }
        	 else
        	 {
        	 //e.printStackTrace();
        	 throw new ConnectException();
        	 }
         
         }
         catch(SocketTimeoutException e)
         {
        	 throw new ConnectException();
        	 
         }
         catch(Exception e)
         {
        	 //e.printStackTrace();
         }
         
         return null;
       
    }

    static 
    {
    	/*ResourceBundle resourceBundle = ResourceBundleUtil.getBundle();
        String proHndlr = "com.sun.net.ssl.internal.www.protocol";
        String keyStore = resourceBundle.getString("Keystore");
        String keyStorePswd = resourceBundle.getString("keyStorePswd");
        String trustStore = resourceBundle.getString("trustStore");      
        String trustStorePswd = resourceBundle.getString("trustStorePswd");
        String debug = "all";
        if(proHndlr != null)
            System.setProperty("java.protocol.handler.pkgs", proHndlr);
        if(keyStore != null)
            System.setProperty("javax.net.ssl.keyStore", keyStore);
        if(keyStorePswd != null)
            System.setProperty("javax.net.ssl.keyStorePwd", keyStorePswd);
        if(trustStore != null)
            System.setProperty("javax.net.ssl.trustStore", trustStore);
        if(trustStorePswd != null)
            System.setProperty("javax.net.ssl.trustStorePwd", trustStorePswd);
        if(debug != null)
            System.setProperty("javax.net.debug", debug);*/
    }
}