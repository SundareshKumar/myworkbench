package com.interfaces;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.security.KeyStore;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

import org.omg.CORBA.LocalObject;


public final class HTTPSProcess
{
	
	static KeyManager[] km;
	static TrustManager[] tm;

	int attempts;
	
    public HTTPSProcess()
    {
    }

    /*static {
        //for localhost testing only
        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
        new javax.net.ssl.HostnameVerifier(){

                @Override
            public boolean verify(String hostname,
                    javax.net.ssl.SSLSession sslSession) {
                if (hostname.equals("your_domain")) {
                    return true;
                }
                return false;
            }
        });
    }*/
    public byte[] sendMessage(String hostURL, byte msg[], String requestMethod)
    {
        return sendMessage(hostURL, msg, requestMethod, null, false, null, null);
    }

    public byte[] sendMessage(String hostURL, byte msg[], String requestMethod, String contentType)
    {
        return sendMessage(hostURL, msg, requestMethod, contentType, false, null, null);
    }

    public byte[] sendMessage(String hostURL, byte msg[], String requestMethod, boolean noResponse)
    {
        return sendMessage(hostURL, msg, requestMethod, null, noResponse, null, null);
    }      

    public byte[] sendMessage(String hostURL, byte msg[], String requestMethod, String contentType, boolean noResponse)
    {
        return sendMessage(hostURL, msg, requestMethod, contentType, noResponse, null, null);
    }

    
    
    
    
    
    public byte[] sendMessage(String hostURL, byte msg[], String requestMethod, String contentType, boolean noResponse, String alias,LocalObject hashMap)
    {
        BufferedOutputStream out = null;
        BufferedInputStream in = null;
        String vpastimeoutflag = null;
        ByteArrayOutputStream bout = null;
        File file = null;
        try
        {
        	if(alias==null || "".equals(""))
        	{
        		alias="alias";
        	}
        	//System.out.print("java home: "+System.getProperty(""));
            try
            {
                //url = new URL(hostURL.trim());
            	
            	 url = new URL(null, hostURL.trim(), new sun.net.www.protocol.https.Handler());
                
               
            }
            catch(MalformedURLException e)
            {
            	return null;
            }
            
            if(url == null)
            {
                return null;
            }
            
            if(alias != null)
            {
                //Modified - SafeKey Implementation
            	SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
                //End
                // Added for connecting all brands (Diners Issue)
                /* keystore */ 
                if(km != null && km.length > 0)
                {
                	
	                FileInputStream keyStream = null;
	                KeyManagerFactory keyFactory = null;
	                char[] keyPassword = null;
	                KeyStore keyStore = null; 
	                try 
	                {
	                	file = new File("keystorefile location");
	                	keyStream = new FileInputStream(file);
	                	keyStore = KeyStore.getInstance(KeyStore.getDefaultType());    
	                    //keyPassword = ResourceBundleUtil.getString("keyStorePswd").trim().toCharArray();
	                    keyStore.load(keyStream, keyPassword);
	                    keyFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());   
	                    keyFactory.init(keyStore,keyPassword);  
	                    km = keyFactory.getKeyManagers();
					}
	                catch (Exception e) 
	                {
	                    return null;	
					}
	                finally
	                {
	                	if(keyStream!=null)
	                	{
	                		keyStream.close();
	                		keyStream=null;
	                	}
	                	file = null;
	                	keyFactory = null;
	                	keyPassword = null;
	                	keyStore = null;
	                }
                }
                
                /* truststore */ 
                if(tm!=null && tm.length>0)
                {
	                FileInputStream trustStream = null;
	                char[] trustPassword = null;
	                TrustManagerFactory trustFactory = null;
	                KeyStore trustStore = null; 
	                try 
	                {
	                	file = new File("trustStore location");
	                	trustStream = new FileInputStream(file);
	                    trustStore = KeyStore.getInstance(KeyStore.getDefaultType());    
	                    //trustPassword =  ResourceBundleUtil.getString("trustStorePswd").trim().toCharArray();
	                    trustStore.load(trustStream, trustPassword);
	                    trustFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());    
	                    trustFactory.init(trustStore);                       
	                    tm = trustFactory.getTrustManagers();
					}
	                catch (Exception e) 
	                {
	                    return null;
					}
	                finally
	                {
	                	if(trustStream!=null)
	                	{
	                		trustStream.close();
	                		trustStream=null;
	                	}
	                	file = null;
	                	trustFactory = null;
	                	trustPassword = null;
	                	trustStore = null;
	                }
                }
                // Ended for connecting all brands (Diners Issue)
                
                HostnameVerifier hv = new HostnameVerifier(){
    				public boolean verify(String arg0, SSLSession arg1) {
    					System.out.println("Warning: URL Host: " + arg0 + " vs. "
    							+ arg1.getPeerHost());
    					return true;
    				}

			};
                
                sslContext.init(km, tm, null);
                javax.net.ssl.SSLSocketFactory sslFactory = sslContext.getSocketFactory();
                HttpsURLConnection.setDefaultSSLSocketFactory(sslFactory);
                HttpsURLConnection.setDefaultHostnameVerifier((javax.net.ssl.HostnameVerifier)hv);
            } 
            
           /* HostnameVerifier hv = new HostnameVerifier()
            {
   				@Override
   				public boolean verify(String arg0, SSLSession arg1) {
   					System.out.println("Warning: URL Host: " + arg0 + " vs. "
                            + arg1.getPeerHost());
                    return true;
   				}
            };
            HttpsURLConnection.setDefaultHostnameVerifier(hv);*/
            
            sendURL = (HttpsURLConnection)url.openConnection();
            requestMethod = requestMethod.toUpperCase();
            if(!requestMethod.equals("POST") && !requestMethod.equals("GET"))
            {
        		return null;
            }
            
            sendURL.setRequestMethod(requestMethod);
            sendURL.setDoOutput(true);
            sendURL.setDoInput(true);
            sendURL.setAllowUserInteraction(false);

           if(contentType != null)
        	   sendURL.setRequestProperty("Content-Type", contentType);

            if(msg != null && msg.length > 0)
            {
                sendURL.setRequestProperty("Content-Length", String.valueOf(msg.length));
                out = new BufferedOutputStream(sendURL.getOutputStream());
                out.write(msg, 0, msg.length);
                out.flush();
                out.close();
            }
            
            if(noResponse)
                return null;
           
            int length = sendURL.getContentLength();
            byte bytes[];
            if(length < 0)
            {
                bout = new ByteArrayOutputStream(128);
                in = new BufferedInputStream(sendURL.getInputStream());
                do
                {
                    int b = in.read();
                    if(b == -1)
                        break;
                    bout.write(b);
                } while(true);
                bytes = bout.toByteArray();
               
                return bytes;
            }
           
            bytes = new byte[length];
            in = new BufferedInputStream(sendURL.getInputStream());
            int pos;
            int numBytesRead;
            for(pos = 0; pos < length; pos += numBytesRead)
            {
                numBytesRead = in.read(bytes, pos, length - pos);
                if(numBytesRead != -1)
                    continue;
                
                break;
            }

            return bytes;
        } 
        /** Timeout Configuration - Starts **/
        catch (ConnectException ce) {
        	ce.printStackTrace();
            return null;
		}  catch (SocketTimeoutException ste) {
            return null;
		} 
        /** Timeout Configuration - Ends **/
        catch(Exception e) {
        	e.printStackTrace();
            return null;
        }
        
        finally
        {
        	try 
        	{
        		if(in!=null)
        		{
        			in.close();
        			in=null;
        		}
        		if(out!=null)
        		{
        			out.close();
        			out=null;
        		}
        		if(sendURL!=null)
        		{
        			sendURL.disconnect();
        			sendURL=null;
        		}
        		bout = null;
        		vpastimeoutflag = null;
			}
        	catch (Exception e) 
        	{
				//PGLogger.logTrace("" + e.fillInStackTrace());
			}
        }
    }
    
    
    
    
    public byte[] sendMessage(String hostURL, byte msg[], String requestMethod, String contentType, boolean noResponse,int timeout,int retryAttempts) throws ConnectException
    {
        BufferedOutputStream out = null;
        BufferedInputStream in = null;
        ByteArrayOutputStream bout = null;
        try
        {
            //PGLogger.logTrace(" Connecting URL: "+hostURL);
            try
            {
                url = new URL(hostURL.trim());
            }
            catch(MalformedURLException e)
            {
            	//PGLogger.logTrace("MalformedURLException occured in HTTPS Process",e);
            	return null;
            }
            
            if(url == null)
            {
                return null;
            }
            
                //Modified -SafeKey Implementation
                SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
                //End
                
                /* keystore */ 
                if(km == null)
                {
	                FileInputStream keyStream = null;
	                KeyManagerFactory keyFactory = null;
	                char[] keyPassword = null;
	                KeyStore keyStore = null; 
	                File file = null;
	                try 
	                {
	                	
	                	file = new File("keyStoreFile location");
	                	keyStream = new FileInputStream(file);
	                	keyStore = KeyStore.getInstance(KeyStore.getDefaultType());    
	                    //keyPassword = ResourceBundleUtil.getString("keyStorePswd").trim().toCharArray();
	                    keyStore.load(keyStream, keyPassword);
	                    keyFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());   
	                    keyFactory.init(keyStore,keyPassword);  
	                    km = keyFactory.getKeyManagers();
					}
	                catch (Exception e) 
	                {
	                    return null;	
					}
	                finally
	                {
	                	if(keyStream!=null)
	                	{
	                		keyStream.close();
	                		keyStream=null;
	                	}
	                	file = null;
	                	keyFactory = null;
	                	keyPassword = null;
	                	keyStore = null;
	                }
                }
                
                /* truststore */ 
                if(tm==null)
                {
	                FileInputStream trustStream = null;
	                char[] trustPassword = null;
	                TrustManagerFactory trustFactory = null;
	                KeyStore trustStore = null; 
	                File file = null;
	                try 
	                {
	                  	file = new File("trustStore location");
	                	trustStream = new FileInputStream(file);
	                    trustStore = KeyStore.getInstance(KeyStore.getDefaultType());    
	                    //trustPassword =  ResourceBundleUtil.getString("trustStorePswd").trim().toCharArray();
	                    trustStore.load(trustStream, trustPassword);
	                    trustFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());    
	                    trustFactory.init(trustStore);                       
	                    tm = trustFactory.getTrustManagers();
					}
	                catch (Exception e) 
	                {
	                    return null;
					}
	                finally
	                {
	                	if(trustStream!=null)
	                	{
	                		trustStream.close();
	                		trustStream=null;
	                	}
	                	file = null;
	                	trustFactory = null;
	                	trustPassword = null;
	                	trustStore = null;
	                }
                }
                // Ended for connecting all brands (Diners Issue)
                sslContext.init(km, tm, null);
                javax.net.ssl.SSLSocketFactory sslFactory = sslContext.getSocketFactory();
                HttpsURLConnection.setDefaultSSLSocketFactory(sslFactory);
              
         // Create all-trusting host name verifier
    		HostnameVerifier allHostsValid = new HostnameVerifier() {
    			public boolean verify(String hostname, SSLSession session) {
    				return true;
    			}

				
    		};

    		// Install the all-trusting host verifier
    		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
            sendURL = (HttpsURLConnection)url.openConnection();
            requestMethod = requestMethod.toUpperCase();
            if(!requestMethod.equals("POST") && !requestMethod.equals("GET"))
            {
        		return null;
            }
            sendURL.setConnectTimeout(timeout);
            sendURL.setRequestMethod(requestMethod);
            sendURL.setDoOutput(true);
            sendURL.setDoInput(true);
            sendURL.setAllowUserInteraction(true);
          
            		
           if(contentType != null)
        	   sendURL.setRequestProperty("Content-Type", contentType);

            if(msg != null && msg.length > 0)
            {
                sendURL.setRequestProperty("Content-Length", String.valueOf(msg.length));
                out = new BufferedOutputStream(sendURL.getOutputStream());
                out.write(msg, 0, msg.length);
                out.flush();
                out.close();
            }
            
            if(noResponse)
                return null;
           
            int length = sendURL.getContentLength();
            byte bytes[];
            if(length < 0)
            {
                bout = new ByteArrayOutputStream(128);
                in = new BufferedInputStream(sendURL.getInputStream());
                do
                {
                    int b = in.read();
                    if(b == -1)
                        break;
                    bout.write(b);
                } while(true);
                bytes = bout.toByteArray();
               
                return bytes;
            }
           
            bytes = new byte[length];
            in = new BufferedInputStream(sendURL.getInputStream());
            int pos;
            int numBytesRead;
            for(pos = 0; pos < length; pos += numBytesRead)
            {
                numBytesRead = in.read(bytes, pos, length - pos);
                if(numBytesRead != -1)
                    continue;
                
                break;
            }

            return bytes;
        }
        catch(ConnectException e)
        {

        	//PGLogger.logTrace("SocketTimeoutException occured in HTTPS Process",e);
        	if(retryAttempts>attempts)
        	{
        		attempts++;
        		sendMessage(hostURL, msg, requestMethod, contentType, noResponse, timeout, retryAttempts);
        	}
        	else
        	{
        		throw new ConnectException();
        	}	
        
        }
        catch(SocketTimeoutException sce)
        {
        	
        	//PGLogger.logTrace("SocketException occured in HTTPS Process",sce);
        	throw new ConnectException();
        	
        }
        catch(Exception e)
        {
        	//PGLogger.logTrace("Exception occured in HTTPS Process",e);
            return null;
        }
        
        finally
        {
        	try 
        	{
        		if(in!=null)
        		{
        			in.close();
        			in=null;
        		}
        		if(out!=null)
        		{
        			out.close();
        			out=null;
        		}
        		if(sendURL!=null)
        		{
        			sendURL.disconnect();
        			sendURL=null;
        		}
        		bout = null;
        		
			}
        	catch (Exception e) 
        	{
        		//PGLogger.logTrace("Exception occured in HTTPS Process at closing the url connection in finally method",e);
			}
        }
      return msg;  
    }


    public static final String POST = "POST";
    public static final String GET = "GET";
    private URL url;
    private HttpsURLConnection sendURL;

    static 
    {
        String proHndlr = "com.sun.net.ssl.internal.www.protocol";
        String keyStore = "";//ConfigFileUtil.getProperty("keyStoreFile");
        String keyStorePswd = "";//ResourceBundleUtil.getString("keyStorePswd");
        String trustStore = "";//ConfigFileUtil.getProperty("trustStore");      
        String trustStorePswd = "";//ResourceBundleUtil.getString("trustStorePswd");
        String debug = "all";
        if(proHndlr != null)
            System.setProperty("java.protocol.handler.pkgs", proHndlr);
        if(keyStore != null)
            System.setProperty("javax.net.ssl.keyStore", keyStore);
        if(keyStorePswd != null)
            System.setProperty("javax.net.ssl.keyStorePassword", keyStorePswd);
        if(trustStore != null)
            System.setProperty("javax.net.ssl.trustStore", trustStore);
        if(trustStorePswd != null)
            System.setProperty("javax.net.ssl.trustStorePassword", trustStorePswd);
        if(debug != null)
            System.setProperty("javax.net.debug", debug);
    }
    
    
    


}

