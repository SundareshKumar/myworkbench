package com.interfaces;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;

import com.util.ConcurrentHashMapUtil;
import com.util.Parser;
import com.util.PaymentConstants;


public class Visa extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("This is GET Method");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String responseString = null;
		String line = null;
		BufferedReader br = null;
		
		try{
			InputStream is = request.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			br = new BufferedReader(isr);
			
			while((line = br.readLine()) != null){
				System.out.println("Request:::::"+line);
				String id = null;
				Parser parse = new Parser();
				HashMap map;
				if(line.contains("<"))
					map = parse.parseXml(line);
				else{
					line = replaceEncodings(line);
					line = line.replaceAll("Auth_req=", "").trim();
					map = Visa.jsonToMap(line.split("\\|\\|")[1]);
				}
				
				ConcurrentHashMapUtil.putAll(map);
				if(line.contains("<VEReq>")){
					id = line.substring(line.indexOf("<Message id=\""),line.indexOf("<VEReq>"));
					responseString = "<ThreeDSecure>"+id+"<VERes><version>1.0.2</version><CH><enrolled>Y</enrolled><acctID>201711021412467033jI3eK6qS</acctID></CH><url>http://localhost:8080/SampleOHS/acs?idct=8172.M&amp;vmid="+id.split("\"")[1]+"</url><protocol>ThreeDSecure</protocol><npc356authdata>OTP1</npc356authdata><otpLength>5</otpLength><npc356authstatusmessage>5638</npc356authstatusmessage><npc356authdataencrypt> </npc356authdataencrypt><npc356authdataencrypttype>FALSE</npc356authdataencrypttype><npc356authdataencryptkeyvalue>FALSE</npc356authdataencryptkeyvalue></VERes></Message></ThreeDSecure>";
				} else if(line.contains("<PAReq>")){
					id = line.substring(line.indexOf("<Message id=\""),line.indexOf("<PAReq>"));
					responseString = "<ThreeDSecure>"+id+"<PARes id=\"PARes\"><version>1.0.2</version><Merchant><acqBIN>515909</acqBIN><merID>100001860</merID></Merchant><Purchase><xid>ONHpI60yACyQd/mUXbEv8cI221c=</xid><date>20171102 02:12:47</date><purchAmount>500000</purchAmount><currency>356</currency><exponent>2</exponent></Purchase><pan>0000000000000229</pan><TX><time>20171102 08:42:52</time><status>Y</status><cavv>jCb0ZXndOg40CBECC2BgBhEAAAA=</cavv><eci>05</eci><cavvAlgorithm>3</cavvAlgorithm></TX></PARes><Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><SignedInfo xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"></CanonicalizationMethod><SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"></SignatureMethod><Reference URI=\"#PARes\"><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"></DigestMethod><DigestValue>USiBY93xZortonJiroUqeqxiM3w=</DigestValue></Reference></SignedInfo><SignatureValue>NAqoy9f/bKWYKQSqcOklEaI9eTAjWYp+hDqL9wRXFqwMEPAacoMIq4im6eU8yWnEAU4v1Xw/MCyUWH09RxrbACn3cVwfH+lPHP3Pf7OpiByo61MRORrQPt9KzcIyOJ9jPb5V0327Qsrk05rvQp1A7j265HkWTYAg4OF7AgSbVFnUpD3PawNzCp1Zy4IV++GJxUV5AGxD227oHgDz+N9173/Us2tYmL5uBpL8Z2bfKbjsThmun6N2aInlHHeFWVJ0rWU1Wudn/oLXADxl1dTb9jCYVziT8CHRxeD0ArgidBquzaOkxRMZpWSStWFv7KOFGHhlvkjQXYjJ2/3h/l0SkA==</SignatureValue><KeyInfo><X509Data><X509Certificate>MIIEUzCCAzugAwIBAgIRAL5xk0SpWK26zM5feAULGYgwDQYJKoZIhvcNAQEFBQAwgYYxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEoMCYGA1UEAxMfUFJEIE1DIFNlY3VyZUNvZGUgSXNzdWVyIFN1YiBDQTAeFw0xNjA5MTcxNjIxNTZaFw0yMDA5MTYxNjE5NTFaMEwxCzAJBgNVBAYTAklOMRYwFAYDVQQKEw1BeGlzIEJhbmsgTHRkMQ4wDAYDVQQLEwVDYXJkczEVMBMGA1UEAxMMQ2FyZFNlY3VyaXR5MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp0t1QffbONnVHlsl33OHwhNPolCQvxfuBwy3AfGwgYV1VLKogXgTlDYdsZF/T9T6OzJVmvjpa/14jEYUZF00DduOAKL5yegRGW4SkccEMeIsqUf870N2HtqORydNykMPet5Z6P0S8Y6/sQzmNNMOoNyf2eWSph0ADAXidRbU9jV+Oir++NyhEABBdBmIydb66/BvQMkEc4mgSmflL7uHCtblCSPCfhEZs58hvkOQeSQag4AK3BucGeaCBzDQ1jVj9zkOj+geBf+B31EzAqoC/WQrDiDSV0mnLqposRcwoCsWuNZylxP9pDnbFu3B/3P1RufAqBGIXrMpYTG17xug2QIDAQABo4H0MIHxMIGmBgNVHSMEgZ4wgZuhgYakgYMwgYAxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEiMCAGA1UEAxMZUFJEIE1DIFNlY3VyZUNvZGUgUm9vdCBDQYIQQ3EBfDozHhKp3pmzcHr6ZzAJBgNVHRMEAjAAMA4GA1UdDwEB/wQEAwIHgDArBgNVHRAEJDAigA8yMDE2MDkxNzE2MjE1NlqBDzIwMTkwOTE3MTYyMTU2WjANBgkqhkiG9w0BAQUFAAOCAQEADEsP0dcKurS4NWcHhbWSog3eMfyy/yRqVYW+Dh6hHBjTrUiPhydUhhDJhJQ70C1Qt7Wae7PQnGvEUsscdvImTMDKdxKcEWXKUpn1/dslkghnwLs/AFVVufDn5uxuOUqrNcBsyFLRqMgey5hEiOpsVavuEDOYZ7Glat7/TkuG3LKMEAhrQtci+ZO9HJl7oc2bv1jakJT59wEAjchNvKcY/2RVefgpj+FRg+Pe5VwCpt4HXqQH2ZVdqGuaQDodESQsrQ1JwUcXFiiPcKQQkg38u5DPHDSl+Xwc+vd8oWaiMRSLb0BB/U9YoM3a6wY455pThZDw/KMdt1riHiuUqikTyg==</X509Certificate><X509Certificate>MIIEgDCCA2igAwIBAgIQQ3EBfDozHhKp3pmzcHr6ZzANBgkqhkiG9w0BAQUFADCBgDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFE1hc3RlckNhcmQgV29ybGR3aWRlMS4wLAYDVQQLEyVNYXN0ZXJDYXJkIFdvcmxkd2lkZSBTZWN1cmVDb2RlIEdlbiAyMSIwIAYDVQQDExlQUkQgTUMgU2VjdXJlQ29kZSBSb290IENBMB4XDTEyMDYyMjA5MjIxNFoXDTI1MDYyMTA5MjIxNVowgYYxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEoMCYGA1UEAxMfUFJEIE1DIFNlY3VyZUNvZGUgSXNzdWVyIFN1YiBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANaeBgfjTKIFls7ueMTzI2nYwAbocHwkQqd8BsIyJbZdk21E+vyq9EhX1NIoiAhP7fl+y/hosX66drjfrbyspZLalrVG6gYbdB2j2Sr8zBRQnMZKKluDwYv/266nnRBeyGYW3FwyVu8L1ACYQc04ACke+07NI/AZ8OXQSoeboEEGUO520/76o1cER5Ok9HRi0jJD8E64j8dEt36Mcg0JaKQiDjShlyTw4ABYyzZ1Vxl0/iDrfwboxNEOOooC0rcGNnCpISXMWn2NmZH1QxiFt2jIZ8QzF3/z+M3iYradh9uZauleNqJ9LPKr/aFFDbe0Bv0PLbvXOnFpwOxvJODWUj8CAwEAAaOB7TCB6jAPBgNVHRMECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQUwTArnR3hR1+Ij1uxMtqoPBm2j7swgacGA1UdIwSBnzCBnKGBhqSBgzCBgDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFE1hc3RlckNhcmQgV29ybGR3aWRlMS4wLAYDVQQLEyVNYXN0ZXJDYXJkIFdvcmxkd2lkZSBTZWN1cmVDb2RlIEdlbiAyMSIwIAYDVQQDExlQUkQgTUMgU2VjdXJlQ29kZSBSb290IENBghEA7qGSrpcB0q8DkgwCPcT3kzANBgkqhkiG9w0BAQUFAAOCAQEA3lJuYVdiy11ELUfBfLuib4gPTbkDdVLBEKosx0yUDczeXoTUOjBEc90f5KRjbpe4pilOGAQnPNUGpi3ZClS+0ysTBp6RdYz1efNLSuaTJtpJpoCOk1/nw6W+nJEWyDXUcC/yVqstZidcOG6AMfKU4EC5zBNELZCGf1ynM2l+gwvkcDUv4Y2et/n/NqIKBzywGSOktojTma0kHbkAe6pj6i65TpwEgEpywVl50oMmNKvXDNMznrAG6S9us+OHDjonOlmmyWmQxXdU1MzwdKzPjHfwl+Z6kByDXruHjEcNsx7P2rUTm/Bt3SWW1K48VfNNhVa/WctTZGJCrV3Zjl6A9g==</X509Certificate><X509Certificate>MIIDzzCCAregAwIBAgIRAO6hkq6XAdKvA5IMAj3E95MwDQYJKoZIhvcNAQEFBQAwgYAxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEiMCAGA1UEAxMZUFJEIE1DIFNlY3VyZUNvZGUgUm9vdCBDQTAeFw0xMjA2MjIwOTA4MzBaFw0yNTA2MjIwOTA4MzFaMIGAMQswCQYDVQQGEwJVUzEdMBsGA1UEChMUTWFzdGVyQ2FyZCBXb3JsZHdpZGUxLjAsBgNVBAsTJU1hc3RlckNhcmQgV29ybGR3aWRlIFNlY3VyZUNvZGUgR2VuIDIxIjAgBgNVBAMTGVBSRCBNQyBTZWN1cmVDb2RlIFJvb3QgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDptCms6aI22T9ST60k487SZP06TKbUBpom7Z1Bo8cQQAE/tM5UOt3THMdrhT+2aIkj9T0pA35IyNMCNGDt+ejhy7tHdw1r6eDX/KXYHb4FlemY03DwRrkQSH/L+ZueS5dCfLM3m2azxBXtrVXDdNebfht8tcWRLK2Ou6vjDzdIzunuWRZ6kRDQ6oc1LSVO2BxiFO0TKowJP/M7qWRT/Jsmb6TGg0vmmQG9QEpmVmOZIexVxuYy3rn7gEbV1tv3k4aG0USMp2Xq/Xe4qe+Ir7sFqR56G4yKezSVLUzQaIB/deeCk9WU2T0XmicAEYDBQoecoS61R4nj5ODmzwmGyxrlAgMBAAGjQjBAMA8GA1UdEwQIMAYBAf8CAQEwDgYDVR0PAQH/BAQDAgEGMB0GA1UdDgQWBBQqFTcxVDO/uxI1hpFF3VSSTFMGujANBgkqhkiG9w0BAQUFAAOCAQEAhDOQ5zUX2wByVv0Cqka3ebnm/6xRzQQbWelzneDUNVdctn1nhJt2PK1uGV7RBGAGukgdAubwwnBhD2FdbhBHTVbpLPYxBbdMAyeC8ezaXGirXOAAv0YbGhPl1MUFiDmqSliavBFUs4cEuBIas4BUoZ5Fz042dDSAWffbdf3l4zrU5Lzol93yXxxIjqgIsT3QI+sRM3gg/Gdwo80DUQ2fRffsGdAUH2C/8L8/wH+E9HspjMDkXlZohPII0xtKhdIPWzbOB6DOULl2PkdGHmJc4VXxfOwE2NJAQxmoaPRDYGgOFVvkzYtyxVkxXeXAPNt8URR3jfWvYrBGH2D5A44Atg==</X509Certificate></X509Data></KeyInfo></Signature></Message></ThreeDSecure>";
				} else if(line.contains("AReq")){
					//responseString = "{'threeDSServerTransID':'"+map.get("threeDSServerTransID")+"','acsTransID':'7bf2f13b-3ca4-4d5d-9a23-98bd51c1947b','acsReferenceNumber':'ACSRefNum1234','authenticationType':'02','acsChallengeMandated':'Y','dsReferenceNumber':'PIT2DSREFERENCENO2','dsTransID':'c789a33b-b67c-4bdb-a8ce-e4dfb41ee111','messageType':'ARes','messageVersion':'2.1.0','transStatus':'Y','acsOperatorID':'00000014','broadInfo':{'test':'test1'},'cardholderInfo':'Additional authentication is needed for this transaction, please contact (Issuer Name) at xxx-xxx-xxxx.'}";
					responseString = "{\"threeDSServerTransID\":\""+map.get("threeDSServerTransID")+"\",\"acsTransID\":\"7bf2f13b-3ca4-4d5d-9a23-98bd51c1947b\",\"acsReferenceNumber\":\"ACSRefNum1234\",\"authenticationType\":\"02\",\"acsChallengeMandated\":\"Y\",\"dsReferenceNumber\":\"PIT2DSREFERENCENO2\",\"dsTransID\":\"c789a33b-b67c-4bdb-a8ce-e4dfb41ee111\",\"messageType\":\"ARes\",\"messageVersion\":\"2.1.0\",\"transStatus\":\"C\",\"acsURL\":\"http://localhost:8080/SampleOHS/cres\",\"acsOperatorID\":\"00000014\",\"broadInfo\":{\"test\":\"test1\"},\"cardholderInfo\":\"Additional authentication is needed for this transaction, please contact (Issuer Name) at xxx-xxx-xxxx.\"}";
				} else if(line.contains("CReq")){
					responseString = "{'threeDSServerTransID':'"+map.get("threeDSServerTransID")+"','acsTransID':'7bf2f13b-3ca4-4d5d-9a23-98bd51c1947b','messageType':'CRes','messageVersion':'2.1.0','transStatus':'Y'}";
				} else if(line.contains("ENC_DATA")){
					String encData = AESDecryption(map.get("ENC_DATA").toString(),"12345678910111213141516171819203");
					encData = encData.replaceAll("::", "&");
					Scanner s = new Scanner(encData).useDelimiter("&");
					while (s.hasNext()) 
					{
						String[] sObj = s.next().split("=");
						if(sObj.length>1)
							map.put(sObj[0], sObj[1]);
					}
					/*private String MERCHANT_ID;
					private String TERMINAL_ID;
					private String TXNREFNO;
					private String VERSION;
					private String BANK_ID;
					private String AGG_ID;
					private String STATUS_CODE;
					private String STATUS_DESC;
					private String ENC_DATA;*/
					responseString = "final_json_resp={'AGG_ID':'"+map.get("AGG_ID")+"'ENC_DATA':'"+map.get("ENC_DATA")+"'BANK_ID':'"+map.get("BANK_ID")+"'VERSION':'"+map.get("VERSION")+"'TERMINAL_ID':'"+map.get("TERMINAL_ID")+"'TXNREFNO':'"+map.get("TXNREFNO")+"','MERCHANT_ID':'"+map.get("MERCHANT_ID")+"','STATUS_CODE':'00','STATUS_DESC':'SUCCESS'}";
					response.sendRedirect(map.get("CALLBACKURL")+"?"+responseString);
				}
			}
			System.out.println("Request:::::"+responseString);
			response(response, responseString);
				
			
		}catch(Exception e){
			
			System.out.println("Error : "+e.getMessage());
		}finally{
			
		}
	}
	
	public void response(HttpServletResponse response, String strRes)
	{
		ServletOutputStream outputStream = null;
		try
		{
			response.setContentType("text/html");
			response.setContentLength(strRes.length());
			outputStream = response.getOutputStream();
			outputStream.print(strRes);
			outputStream.flush();
			outputStream.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		finally
		{
			outputStream = null;
		}
	}
	
	
	public static HashMap jsonToMap(String t) throws JSONException {

        HashMap<Object, Object> map = new HashMap<Object, Object>();
        JSONObject jObject = new JSONObject(t);
        Iterator<?> keys = jObject.keys();

        while( keys.hasNext() ){
            String key = (String)keys.next();
            Object value = jObject.get(key); 
            map.put(key, value);

        }
        return map;
        /*System.out.println("json : "+jObject);
        System.out.println("map : "+map);*/
    }

	private String replaceEncodings(String data) {

		data = data.replace("%20", " ");
		data = data.replace("%21", "!");
		data = data.replace("%22", "\"");
		data = data.replace("%23", "#");
		data = data.replace("%24", "$");
		data = data.replace("%25", "%");
		data = data.replace("%26", "&");
		data = data.replace("%27", "\'");
		data = data.replace("%28", "(");
		data = data.replace("%29", ")");
		data = data.replace("%2A", "*");
		data = data.replace("%2B", "+");
		data = data.replace("%2C", ",");
		data = data.replace("%2D", "-");
		data = data.replace("%2E", ".");
		data = data.replace("%2F", "/");
		data = data.replace("%30", "0");
		data = data.replace("%31", "1");
		data = data.replace("%32", "2");
		data = data.replace("%33", "3");
		data = data.replace("%34", "4");
		data = data.replace("%35", "5");
		data = data.replace("%36", "6");
		data = data.replace("%37", "7");
		data = data.replace("%38", "8");
		data = data.replace("%39", "9");
		data = data.replace("%3A", ":");
		data = data.replace("%3B", ";");
		data = data.replace("%3C", "<");
		data = data.replace("%3D", "=");
		data = data.replace("%3E", ">");
		data = data.replace("%3F", "?");
		data = data.replace("%40", "@");
		data = data.replace("%41", "A");
		data = data.replace("%42", "B");
		data = data.replace("%43", "C");
		data = data.replace("%44", "D");
		data = data.replace("%45", "E");
		data = data.replace("%46", "F");
		data = data.replace("%47", "G");
		data = data.replace("%48", "H");
		data = data.replace("%49", "I");
		data = data.replace("%4A", "J");
		data = data.replace("%4B", "K");
		data = data.replace("%4C", "L");
		data = data.replace("%4D", "M");
		data = data.replace("%4E", "N");
		data = data.replace("%4F", "O");
		data = data.replace("%50", "P");
		data = data.replace("%51", "Q");
		data = data.replace("%52", "R");
		data = data.replace("%53", "S");
		data = data.replace("%54", "T");
		data = data.replace("%55", "U");
		data = data.replace("%56", "V");
		data = data.replace("%57", "W");
		data = data.replace("%58", "X");
		data = data.replace("%59", "Y");
		data = data.replace("%5A", "Z");
		data = data.replace("%5B", "[");
		data = data.replace("%5C", "\\");
		data = data.replace("%5D", "]");
		data = data.replace("%5E", "^");
		data = data.replace("%5F", "_");
		data = data.replace("%60", "`");
		data = data.replace("%61", "a");
		data = data.replace("%62", "b");
		data = data.replace("%63", "c");
		data = data.replace("%64", "d");
		data = data.replace("%65", "e");
		data = data.replace("%66", "f");
		data = data.replace("%67", "g");
		data = data.replace("%68", "h");
		data = data.replace("%69", "i");
		data = data.replace("%6A", "j");
		data = data.replace("%6B", "k");
		data = data.replace("%6C", "l");
		data = data.replace("%6D", "m");
		data = data.replace("%6E", "n");
		data = data.replace("%6F", "o");
		data = data.replace("%70", "p");
		data = data.replace("%71", "q");
		data = data.replace("%72", "r");
		data = data.replace("%73", "s");
		data = data.replace("%74", "t");
		data = data.replace("%75", "u");
		data = data.replace("%76", "v");
		data = data.replace("%77", "w");
		data = data.replace("%78", "x");
		data = data.replace("%79", "y");
		data = data.replace("%7A", "z");
		data = data.replace("%7B", "{");
		data = data.replace("%7C", "|");
		data = data.replace("%7D", "}");
		data = data.replace("%7E", "~");
		data = data.replace("%80", "`");

		return data;
		}
	
	private String AESDecryption(String encryptedText, String encKey) {
   		Key key = null;
		Cipher cipher = null;
		String decryptedValue = "";
		try {
			key = generateKey(encKey.getBytes(), "AES"); 
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, key);
			byte[] decodeBytes = new Base64().decode(encryptedText.getBytes());
			decryptedValue = new String(cipher.doFinal(decodeBytes));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			key = null;
			cipher = null;
		}
		
		return decryptedValue;
   	}
	
	private String AESEncryption(String plainText, String encKey) {
    	Key key = null;
   		Cipher cipher = null;
   		String encryptedValue = "";
   		try {
   			key = generateKey(encKey.getBytes(), "AES"); 
   			cipher = Cipher.getInstance("AES");
   			cipher.init(Cipher.ENCRYPT_MODE, key);
   			byte[] cipherVal = cipher.doFinal(plainText.getBytes());
   			encryptedValue = new String(new Base64().encode(cipherVal));
   		} catch (Exception e) {
   			e.printStackTrace();
   		} finally {
   			key = null;
			cipher = null;
   		}
   		
   		return encryptedValue;
   	}
	
	public Key generateKey(byte[] keyByte, String hashAlgName) throws Exception {
   		Key key = new SecretKeySpec(keyByte, hashAlgName);
   		return key;
   	}
}
