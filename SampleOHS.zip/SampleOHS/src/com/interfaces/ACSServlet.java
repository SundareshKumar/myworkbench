package com.interfaces;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.interfaces.HTTPProcess;
import com.interfaces.HTTPSProcess;
import com.util.ConcurrentHashMapUtil;
import com.util.Parser;
import com.util.PaymentConstants;
import com.util.TextFormat;

public class ACSServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			if(request.getRequestURI().contains("cres"))
			{
				byte[] cresByteVal = null;
				byte[] byteBase64EncodeCreq = null;
		        String cresDecodeValue =  null;
		        String cres = null;
				String cresString = request.getParameter("creq");
				
				if(!"".equals(cresString))
				{
					cresByteVal = TextFormat.base64Decode(cresString.getBytes());
					cresDecodeValue = TextFormat.charEncodeString(cresByteVal);
					System.out.println("Challenge Response Message :  "+cresDecodeValue);
				}
				
				HashMap map = Visa.jsonToMap(cresDecodeValue);
				ConcurrentHashMapUtil.putAll(map);
				String rReq = "{\"threeDSServerTransID\":\""+ConcurrentHashMapUtil.get("threeDSServerTransID")+"\",\"acsTransID\":\"7bf2f13b-3ca4-4d5d-9a23-98bd51c1947b\",\"authenticationType\":\"01\",\"authenticationValue\":\"AJkBAohgWVY3NZIHY2BZAAAAAAA=\",\"dsTransID\":\"c789a33b-b67c-4bdb-a8ce-e4dfb41ee111\",\"eci\":\"05\",\"interactionCounter\":\"01\",\"messageType\":\"RReq\",\"messageVersion\":\"2.1.0\",\"messageCategory\":\"01\",\"transStatus\":\"Y\"}";
				connectWebserver(rReq,"http://localhost:8080/compensate/rReq.htm","application/json;charset=UTF-8"); 
				cres = "{\"threeDSServerTransID\":\""+ConcurrentHashMapUtil.get("threeDSServerTransID")+"\",\"acsTransID\":\"7bf2f13b-3ca4-4d5d-9a23-98bd51c1947b\",\"messageType\":\"CRes\",\"messageVersion\":\"2.1.0\",\"transStatus\":\"Y\"}";
				
				cresByteVal = cres.getBytes();
				byteBase64EncodeCreq = TextFormat.base64Encode(cresByteVal);
				cres = TextFormat.charEncodeString(byteBase64EncodeCreq);
				
				request.setAttribute("TermUrl", "http://localhost:8080/compensate/cRes.htm");
				request.setAttribute("cres", cres);
				request.setAttribute("threeDSSessionData", request.getParameter("threeDSSessionData"));
				
				request.getRequestDispatcher("cres.jsp").forward(request, response);
			}
			else
			{
				byte[] byteArray = TextFormat.charEncodeByteArray(request.getParameter("PaReq"));
				byte[] byteBase64 = TextFormat.base64Decode(byteArray);
				byte[] byteInflatePAReq = TextFormat.inflate(byteBase64);
				String PAReq = new String(byteInflatePAReq);
				String PARes = null;
				
				byteArray = null;
				byteBase64 = null;
				byteInflatePAReq = null;
				
				Parser parse = new Parser();
				HashMap map = parse.parseXml(PAReq);
				ConcurrentHashMapUtil.putAll(map);
				PARes = "<ThreeDSecure><Message id=\""+ConcurrentHashMapUtil.get("id")+"\"><PARes id=\"PARes\"><version>1.0.2</version><Merchant><acqBIN>"+ConcurrentHashMapUtil.get("acqBIN")+"</acqBIN><merID>"+ConcurrentHashMapUtil.get("merID")+"</merID></Merchant><Purchase><xid>"+ConcurrentHashMapUtil.get("xid")+"</xid><date>"+ConcurrentHashMapUtil.get("date")+"</date><purchAmount>"+ConcurrentHashMapUtil.get("purchAmount")+"</purchAmount><currency>"+ConcurrentHashMapUtil.get("currency")+"</currency><exponent>"+ConcurrentHashMapUtil.get("exponent")+"</exponent></Purchase><pan>"+ConcurrentHashMapUtil.get("pan")+"</pan><TX><time>"+ConcurrentHashMapUtil.get("date")+"</time><status>Y</status><cavv>jCb0ZXndOg40CBECC2BgBhEAAAA=</cavv><eci>05</eci><cavvAlgorithm>3</cavvAlgorithm></TX></PARes><Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><SignedInfo xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"></CanonicalizationMethod><SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"></SignatureMethod><Reference URI=\"#PARes\"><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"></DigestMethod><DigestValue>USiBY93xZortonJiroUqeqxiM3w=</DigestValue></Reference></SignedInfo><SignatureValue>NAqoy9f/bKWYKQSqcOklEaI9eTAjWYp+hDqL9wRXFqwMEPAacoMIq4im6eU8yWnEAU4v1Xw/MCyUWH09RxrbACn3cVwfH+lPHP3Pf7OpiByo61MRORrQPt9KzcIyOJ9jPb5V0327Qsrk05rvQp1A7j265HkWTYAg4OF7AgSbVFnUpD3PawNzCp1Zy4IV++GJxUV5AGxD227oHgDz+N9173/Us2tYmL5uBpL8Z2bfKbjsThmun6N2aInlHHeFWVJ0rWU1Wudn/oLXADxl1dTb9jCYVziT8CHRxeD0ArgidBquzaOkxRMZpWSStWFv7KOFGHhlvkjQXYjJ2/3h/l0SkA==</SignatureValue><KeyInfo><X509Data><X509Certificate>MIIEUzCCAzugAwIBAgIRAL5xk0SpWK26zM5feAULGYgwDQYJKoZIhvcNAQEFBQAwgYYxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEoMCYGA1UEAxMfUFJEIE1DIFNlY3VyZUNvZGUgSXNzdWVyIFN1YiBDQTAeFw0xNjA5MTcxNjIxNTZaFw0yMDA5MTYxNjE5NTFaMEwxCzAJBgNVBAYTAklOMRYwFAYDVQQKEw1BeGlzIEJhbmsgTHRkMQ4wDAYDVQQLEwVDYXJkczEVMBMGA1UEAxMMQ2FyZFNlY3VyaXR5MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp0t1QffbONnVHlsl33OHwhNPolCQvxfuBwy3AfGwgYV1VLKogXgTlDYdsZF/T9T6OzJVmvjpa/14jEYUZF00DduOAKL5yegRGW4SkccEMeIsqUf870N2HtqORydNykMPet5Z6P0S8Y6/sQzmNNMOoNyf2eWSph0ADAXidRbU9jV+Oir++NyhEABBdBmIydb66/BvQMkEc4mgSmflL7uHCtblCSPCfhEZs58hvkOQeSQag4AK3BucGeaCBzDQ1jVj9zkOj+geBf+B31EzAqoC/WQrDiDSV0mnLqposRcwoCsWuNZylxP9pDnbFu3B/3P1RufAqBGIXrMpYTG17xug2QIDAQABo4H0MIHxMIGmBgNVHSMEgZ4wgZuhgYakgYMwgYAxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEiMCAGA1UEAxMZUFJEIE1DIFNlY3VyZUNvZGUgUm9vdCBDQYIQQ3EBfDozHhKp3pmzcHr6ZzAJBgNVHRMEAjAAMA4GA1UdDwEB/wQEAwIHgDArBgNVHRAEJDAigA8yMDE2MDkxNzE2MjE1NlqBDzIwMTkwOTE3MTYyMTU2WjANBgkqhkiG9w0BAQUFAAOCAQEADEsP0dcKurS4NWcHhbWSog3eMfyy/yRqVYW+Dh6hHBjTrUiPhydUhhDJhJQ70C1Qt7Wae7PQnGvEUsscdvImTMDKdxKcEWXKUpn1/dslkghnwLs/AFVVufDn5uxuOUqrNcBsyFLRqMgey5hEiOpsVavuEDOYZ7Glat7/TkuG3LKMEAhrQtci+ZO9HJl7oc2bv1jakJT59wEAjchNvKcY/2RVefgpj+FRg+Pe5VwCpt4HXqQH2ZVdqGuaQDodESQsrQ1JwUcXFiiPcKQQkg38u5DPHDSl+Xwc+vd8oWaiMRSLb0BB/U9YoM3a6wY455pThZDw/KMdt1riHiuUqikTyg==</X509Certificate><X509Certificate>MIIEgDCCA2igAwIBAgIQQ3EBfDozHhKp3pmzcHr6ZzANBgkqhkiG9w0BAQUFADCBgDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFE1hc3RlckNhcmQgV29ybGR3aWRlMS4wLAYDVQQLEyVNYXN0ZXJDYXJkIFdvcmxkd2lkZSBTZWN1cmVDb2RlIEdlbiAyMSIwIAYDVQQDExlQUkQgTUMgU2VjdXJlQ29kZSBSb290IENBMB4XDTEyMDYyMjA5MjIxNFoXDTI1MDYyMTA5MjIxNVowgYYxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEoMCYGA1UEAxMfUFJEIE1DIFNlY3VyZUNvZGUgSXNzdWVyIFN1YiBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANaeBgfjTKIFls7ueMTzI2nYwAbocHwkQqd8BsIyJbZdk21E+vyq9EhX1NIoiAhP7fl+y/hosX66drjfrbyspZLalrVG6gYbdB2j2Sr8zBRQnMZKKluDwYv/266nnRBeyGYW3FwyVu8L1ACYQc04ACke+07NI/AZ8OXQSoeboEEGUO520/76o1cER5Ok9HRi0jJD8E64j8dEt36Mcg0JaKQiDjShlyTw4ABYyzZ1Vxl0/iDrfwboxNEOOooC0rcGNnCpISXMWn2NmZH1QxiFt2jIZ8QzF3/z+M3iYradh9uZauleNqJ9LPKr/aFFDbe0Bv0PLbvXOnFpwOxvJODWUj8CAwEAAaOB7TCB6jAPBgNVHRMECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQUwTArnR3hR1+Ij1uxMtqoPBm2j7swgacGA1UdIwSBnzCBnKGBhqSBgzCBgDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFE1hc3RlckNhcmQgV29ybGR3aWRlMS4wLAYDVQQLEyVNYXN0ZXJDYXJkIFdvcmxkd2lkZSBTZWN1cmVDb2RlIEdlbiAyMSIwIAYDVQQDExlQUkQgTUMgU2VjdXJlQ29kZSBSb290IENBghEA7qGSrpcB0q8DkgwCPcT3kzANBgkqhkiG9w0BAQUFAAOCAQEA3lJuYVdiy11ELUfBfLuib4gPTbkDdVLBEKosx0yUDczeXoTUOjBEc90f5KRjbpe4pilOGAQnPNUGpi3ZClS+0ysTBp6RdYz1efNLSuaTJtpJpoCOk1/nw6W+nJEWyDXUcC/yVqstZidcOG6AMfKU4EC5zBNELZCGf1ynM2l+gwvkcDUv4Y2et/n/NqIKBzywGSOktojTma0kHbkAe6pj6i65TpwEgEpywVl50oMmNKvXDNMznrAG6S9us+OHDjonOlmmyWmQxXdU1MzwdKzPjHfwl+Z6kByDXruHjEcNsx7P2rUTm/Bt3SWW1K48VfNNhVa/WctTZGJCrV3Zjl6A9g==</X509Certificate><X509Certificate>MIIDzzCCAregAwIBAgIRAO6hkq6XAdKvA5IMAj3E95MwDQYJKoZIhvcNAQEFBQAwgYAxCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRNYXN0ZXJDYXJkIFdvcmxkd2lkZTEuMCwGA1UECxMlTWFzdGVyQ2FyZCBXb3JsZHdpZGUgU2VjdXJlQ29kZSBHZW4gMjEiMCAGA1UEAxMZUFJEIE1DIFNlY3VyZUNvZGUgUm9vdCBDQTAeFw0xMjA2MjIwOTA4MzBaFw0yNTA2MjIwOTA4MzFaMIGAMQswCQYDVQQGEwJVUzEdMBsGA1UEChMUTWFzdGVyQ2FyZCBXb3JsZHdpZGUxLjAsBgNVBAsTJU1hc3RlckNhcmQgV29ybGR3aWRlIFNlY3VyZUNvZGUgR2VuIDIxIjAgBgNVBAMTGVBSRCBNQyBTZWN1cmVDb2RlIFJvb3QgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDptCms6aI22T9ST60k487SZP06TKbUBpom7Z1Bo8cQQAE/tM5UOt3THMdrhT+2aIkj9T0pA35IyNMCNGDt+ejhy7tHdw1r6eDX/KXYHb4FlemY03DwRrkQSH/L+ZueS5dCfLM3m2azxBXtrVXDdNebfht8tcWRLK2Ou6vjDzdIzunuWRZ6kRDQ6oc1LSVO2BxiFO0TKowJP/M7qWRT/Jsmb6TGg0vmmQG9QEpmVmOZIexVxuYy3rn7gEbV1tv3k4aG0USMp2Xq/Xe4qe+Ir7sFqR56G4yKezSVLUzQaIB/deeCk9WU2T0XmicAEYDBQoecoS61R4nj5ODmzwmGyxrlAgMBAAGjQjBAMA8GA1UdEwQIMAYBAf8CAQEwDgYDVR0PAQH/BAQDAgEGMB0GA1UdDgQWBBQqFTcxVDO/uxI1hpFF3VSSTFMGujANBgkqhkiG9w0BAQUFAAOCAQEAhDOQ5zUX2wByVv0Cqka3ebnm/6xRzQQbWelzneDUNVdctn1nhJt2PK1uGV7RBGAGukgdAubwwnBhD2FdbhBHTVbpLPYxBbdMAyeC8ezaXGirXOAAv0YbGhPl1MUFiDmqSliavBFUs4cEuBIas4BUoZ5Fz042dDSAWffbdf3l4zrU5Lzol93yXxxIjqgIsT3QI+sRM3gg/Gdwo80DUQ2fRffsGdAUH2C/8L8/wH+E9HspjMDkXlZohPII0xtKhdIPWzbOB6DOULl2PkdGHmJc4VXxfOwE2NJAQxmoaPRDYGgOFVvkzYtyxVkxXeXAPNt8URR3jfWvYrBGH2D5A44Atg==</X509Certificate></X509Data></KeyInfo></Signature></Message></ThreeDSecure>";
				
				request.setAttribute("PARes", PARes);
				
				byteArray = PARes.getBytes();
				byte[] byteDeflatePARes = TextFormat.deflate(byteArray);
				byte[] byteBase64EncodePARes = TextFormat.base64Encode(byteDeflatePARes);
				PARes = TextFormat.charEncodeString(byteBase64EncodePARes);
				
				request.setAttribute("PaRes", PARes);
				request.setAttribute("TermUrl", request.getParameter("TermUrl"));
				request.setAttribute("MD", request.getParameter("MD"));
				
				request.getRequestDispatcher("acs.jsp").forward(request, response);
			}
			
		} catch (Exception e) {
			
		}
	}

	public static HashMap jsonToMap(String t) throws JSONException {

        HashMap<Object, Object> map = new HashMap<Object, Object>();
        JSONObject jObject = new JSONObject(t);
        Iterator<?> keys = jObject.keys();

        while( keys.hasNext() ){
            String key = (String)keys.next();
            Object value = jObject.get(key); 
            map.put(key, value);

        }
        return map;
        /*System.out.println("json : "+jObject);
        System.out.println("map : "+map);*/
    }
	
public String connectWebserver(String req,String hostURL,String contentType){
		
		//PGLogger.logTrace("### Inside connectWebserver method in SecureProcessController ###",PaymentConstants.log_transaction_info);
		//StringBuffer data = null;
		HTTPProcess httpprocess =null;
		HTTPSProcess httpsprocess = null;
		byte[] webserverResponse = null;
		//String webHostURL= null;
		try {
		 //data = new StringBuffer();
		
		//data.append( hostURL+ "||" + req+"||"+""+"||"+""+"||"+""+"||"+""+"||"+paymentID+"||"+contentType);
		
		//webHostURL=ConfigFileUtil.getProperty("WEBSERVER_3D_SECURE_TCPIP");
		
		
		if (hostURL.substring(0,8).equalsIgnoreCase("HTTPS://")) 
		 {
			 httpsprocess = new HTTPSProcess();
			 webserverResponse = httpsprocess.sendMessage(hostURL, req.getBytes(), "POST",contentType);
		 }
		 else
		 {
			 httpprocess = new HTTPProcess(hostURL, false);
			 webserverResponse = httpprocess.sendMessage(req.getBytes(), "POST",contentType); 
		 }
		
		if(webserverResponse!= null){
			return new String(webserverResponse);
		}
		else{
			return null;
		}
		
		}catch (Exception e) {
			
			//PGLogger.error(ResourceBundleUtil.getString("pg.tran.problem.connect.webserver"), e);
			return null;
		}
		finally{
			//data = null;
			httpprocess =null;
			httpsprocess = null;
			webserverResponse = null;
			//webHostURL= null;
		}
		
	}
}
