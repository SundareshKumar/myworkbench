package com.fss.iso;

import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.BitSet;
import java.util.Date;
import java.util.Random;

public class IsoUtils 
{
	public static BitSet hexStringToBitSet(byte abyte0[], int i, boolean flag)
    {
        char c = flag ? (Character.digit((char)abyte0[i], 16) & 8) != 8 ? '@' : '\200' : '@';
        BitSet bitset = new BitSet(c);
        for(int j = 0; j < c; j++)
        {
            int k = Character.digit((char)abyte0[i + (j >>> 2)], 16);
            if((k & 8 >>> j % 4) > 0)
                bitset.set(j);
        }
        return bitset;
    }
	
	public static String bitSetToHexString(BitSet bitset)
    {
        return hexString(bitSetToByte(bitset));
    }
	
	 public static byte[] bitSetToByte(BitSet bitset)
	 {
	        int i = (bitset.size() >>> 3) << 3;
	        i = i <= 128 ? i : 128;
	        byte abyte0[] = new byte[i >>> 3];
	        for(int j = 0; j < i; j++)
	            if(bitset.get(j))
	                abyte0[j >>> 3] |= 128 >>> j % 8;

	        if(i > 64)
	            abyte0[0] |= 0x80;
	        return abyte0;
	 }
	 
	 public static String hexString(byte abyte0[])
	 {
	        StringBuffer stringbuffer = new StringBuffer(abyte0.length * 2);
	        for(int i = 0; i < abyte0.length; i++)
	        {
	            char c = Character.forDigit(abyte0[i] >>> 4 & 0xf, 16);
	            char c1 = Character.forDigit(abyte0[i] & 0xf, 16);
	            stringbuffer.append(Character.toUpperCase(c));
	            stringbuffer.append(Character.toUpperCase(c1));
	        }
	        return stringbuffer.toString();
	 }
	 
	 public static String padLeft(String s, int i, char c)
	    {
	        s = s.trim();
	        if(s.length() >= i)
	            return s;
	        StringBuffer stringbuffer = new StringBuffer(i);
	        for(int j = i - s.length(); j-- > 0;)
	            stringbuffer.append(c);

	        stringbuffer.append(s);
	        return stringbuffer.toString();
	    }
	 
	 public static String zeroFill(String s, int i)
	    {
	        StringBuffer stringbuffer = new StringBuffer(i);
	        int j = i - s.length();
	        for(int k = 0; k < j; k++)
	            stringbuffer.append("0");

	        stringbuffer.append(s);
	        return stringbuffer.toString();
	    }
	 
	  public static String padRight(String s, int i)
	    {
	        if(s.length() >= i)
	            return s;
	        StringBuffer stringbuffer;
	        for(stringbuffer = new StringBuffer(s); stringbuffer.length() < i; stringbuffer.append(' '));
	        return stringbuffer.toString();
	    }
	  
	  public static long generateTransactionID(int i)
	    {
	        long l = new Random(System.currentTimeMillis()).nextInt(0x989680);
	        Date date = new Date(System.currentTimeMillis());
	        String s = simpleDateFormat(date, "yyyy.DDD.HH.mm.");
	        int j = s.indexOf('.');
	        int k = j + 1;
	        int i1 = s.indexOf('.', k);
	        int j1 = i1 + 1;
	        int k1 = s.indexOf('.', j1);
	        int l1 = k1 + 1;
	        int i2 = s.indexOf('.', l1);
	        int j2 = Character.digit(s.charAt(j - 1), 10);
	        int k2 = Character.digit(s.charAt(k), 10);
	        for(int l2 = k + 1; l2 < i1; l2++)
	            k2 = k2 * 10 + Character.digit(s.charAt(l2), 10);

	        int i3 = Character.digit(s.charAt(j1), 10);
	        for(int j3 = j1 + 1; j3 < k1; j3++)
	            i3 = i3 * 10 + Character.digit(s.charAt(j3), 10);

	        int k3 = Character.digit(s.charAt(l1), 10);
	        for(int l3 = l1 + 1; l3 < i2; l3++)
	            k3 = k3 * 10 + Character.digit(s.charAt(l3), 10);

	        l *= 100L;
	        l += k3;
	        l *= 100L;
	        l += i3;
	        l *= 10L;
	        l += j2;
	        l *= 1000L;
	        l += k2;
	        l *= 10L;
	        l += i % 10;
	        return l;
	    }
		
		private static String simpleDateFormat(Date date, String s)
	    {
			StringBuffer stringbuffer = new StringBuffer(s.length());
			try 
			{
				SimpleDateFormat sdf = new SimpleDateFormat(s);    	
		        FieldPosition fieldposition = new FieldPosition(0);
		        sdf.format(date, stringbuffer, fieldposition);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
	        return stringbuffer.toString();
	    }	

		public static String  genRRN()
		{
			String rrn = "";
			try 
			{ 
				int randNum = 0;		
				for(; randNum <= 0x98967f; randNum = (new Random(System.currentTimeMillis())).nextInt(0x5f5e100));
		        String yyyyddd = simpleDateFormat(new Date(System.currentTimeMillis()), "yyyyDDD");
		        rrn = yyyyddd.substring(3, 7) + String.valueOf(randNum);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			return rrn;
		}
		
		public static String formatDate(Date date, String s)
	    {
			try 
			{
				SimpleDateFormat sdf = new SimpleDateFormat(s);
		        FieldPosition fieldposition = new FieldPosition(0);
		        StringBuffer sb = new StringBuffer(s.length());
		        sdf.format(date, sb, fieldposition);
		        return sb.toString();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				return null;
			}
	    }
}
