package com.fss.iso;

import java.io.ByteArrayOutputStream;
import java.util.BitSet;

public class Type1Message8583 extends Type1Message
{
	protected Type1Message8583(String s)
    {
        priBitmap = new BitSet(64);
        secBitmap = new BitSet(64);
        msgHdr = s;
        if(msgHdr == null)
            s = "";
    }

    public void setElement(int i, String s)
    {
        if(i <= 64)
            priBitmap.set(i - 1);
        else
            secBitmap.set(i - 1 - 64);
        super.setElement(i, s);
    }

    public void setElement(int i, byte abyte0[])
    {
        if(i <= 64)
            priBitmap.set(i - 1);
        else
            secBitmap.set(i - 1 - 64);
        super.setElement(i, abyte0);
    }

    public void setMsgType(String s)
    {
        msgType = s.getBytes();
    }

    public String getMsgType()
    {
        String s = new String(msgType);
        return s;
    }
    
    // to remove a bit
    public void removeBit(int i)
    {
    	 if(i <= 64)
    	 {
    	    priBitmap.set(i - 1,false);
     	 	msgObj.remove(new Integer(i));	 
    	 }
         else if(i>64 && i<=128)
         {
        	 secBitmap.set(i - 1 - 64, false);
        	 msgObj.remove(new Integer(i));
         }
    }

    protected byte[] pack(Type1Field aauthfield[])
    {
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(512);
        boolean flag = false;
        bytearrayoutputstream.write(msgHdr.getBytes(), 0, msgHdr.length());
        bytearrayoutputstream.write(msgType, 0, msgType.length);
        if(secBitmap.length() > 0)
        {
            priBitmap.set(0);
            byte abyte0[] = super.formatElement(IsoUtils.bitSetToHexString(priBitmap).getBytes(), aauthfield[0]);
            bytearrayoutputstream.write(abyte0, 0, abyte0.length);
            abyte0 = super.formatElement(IsoUtils.bitSetToHexString(secBitmap).getBytes(), aauthfield[1]);
            bytearrayoutputstream.write(abyte0, 0, abyte0.length);
        } 
        else
        {
            byte abyte1[] = super.formatElement(IsoUtils.bitSetToHexString(priBitmap).getBytes(), aauthfield[0]);
            bytearrayoutputstream.write(abyte1, 0, abyte1.length);
        }
        for(int i = 1; i < 64; i++)
            if(priBitmap.get(i))
            {
                byte abyte2[] = super.getBytesElement(i + 1);
                if(abyte2 != null && aauthfield[i + 1] != null)
                {
                    byte abyte3[] = super.formatElement(abyte2, aauthfield[i + 1]);
                    if(abyte3 == null)
                    {
                    	//PGLogger.logTrace("    Problem occured while formatting the bit "+(i + 1));
                    	//PGLogger.logTrace("    Bit #" + (i + 1) + " " + aauthfield[i + 1].getName() + " IS NULL");
                        flag = true;
                    } 
                    else
                    {
                        System.out.println("    Bit #" + (i + 1) + " " + aauthfield[i + 1].getName() + " " + new String(abyte3));
                        bytearrayoutputstream.write(abyte3, 0, abyte3.length);
                    }
                }
            }

        for(int j = 0; j < 64; j++)
            if(secBitmap.get(j))
            {
                byte abyte4[] = super.getBytesElement(j + 65);
                if(abyte4 != null && aauthfield[j + 65] != null)
                {
                    byte abyte5[] = super.formatElement(abyte4, aauthfield[j + 65]);
                    if(abyte5 == null)
                    {
                    	//PGLogger.logTrace("    Problem occured while formatting the bit "+(j + 65));
                    	//PGLogger.logTrace("    Bit #" + (j + 65) + " " + aauthfield[j + 65].getName() + " is null");
                        flag = true;
                    } else
                    {
                    	int k = 64+j;
                    	System.out.println("    Bit #" + (k + 1) + " " + aauthfield[j + 65].getName() + " " + new String(abyte5));
                        bytearrayoutputstream.write(abyte5, 0, abyte5.length);
                    }
                }
            }

        if(flag)
            return null;
        else
            return bytearrayoutputstream.toByteArray();
    }

    protected boolean unpack(byte abyte0[], Type1Field aauthfield[])
    {
        String s = new String(abyte0);
        boolean flag = true;
        boolean flag1 = false;
        int i = 0;
        i = msgHdr.length();
        byte byte0 = 4;
        msgType = s.substring(i, i + byte0).getBytes();
        i += byte0;
        byte0 = 16;
        String s1 = s.substring(i, i + byte0);
        priBitmap = IsoUtils.hexStringToBitSet(s1.getBytes(), 0, false);
        i += byte0;
        if(priBitmap.get(0))
        {
            String s2 = s.substring(i, i + byte0);
            secBitmap = IsoUtils.hexStringToBitSet(s2.getBytes(), 0, false);
            flag1 = true;
            i += byte0;
        }
        for(int k = 2; k <= (flag1 ? 128 : 64); k++)
        {
            boolean flag3;
            if(flag)
                flag3 = priBitmap.get(k - 1);
            else
                flag3 = secBitmap.get(k - 1 - 64);
            if(!flag3)
            {
                if(k == 64 && flag1)
                    flag = false;
            } else
            {
                int l = aauthfield[k].getMinLength();
                int i1 = aauthfield[k].getLengthHeader();
                boolean flag4 = false;
                if(i1 > 0)
                    flag4 = true;
                String s3;
//                if(flag4)
//                {
//                    String s4 = s.substring(i, i += i1);
//                    int j = Integer.valueOf(s4).intValue();
//                    
//                    System.out.println("s::"+s+"i::"+i+"j::"+j);
//                    
//                    s3 = s.substring(i, i += j);
//                } else
//                {
//                    s3 = s.substring(i, i += l);
//                }
                //if(k != 14 && k != 35)
//                System.out.println("    Bit #" + k + " " + aauthfield[k].getName() + " " + s3);
//                setElement(k, s3);
                if(k == 64 && flag1)
                    flag = false;
            }
        }

        return true;
    }

    private BitSet priBitmap;
    private BitSet secBitmap;
    private byte msgType[];
    private String msgHdr;
}
