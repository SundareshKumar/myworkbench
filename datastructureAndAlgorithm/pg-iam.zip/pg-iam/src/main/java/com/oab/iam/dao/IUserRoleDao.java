package com.oab.iam.dao;

import java.util.List;

import com.oab.iam.model.UserRole;

public interface IUserRoleDao {

	public Long create(UserRole userRole);

	public List<UserRole> getUserRole();

	public UserRole getUserRole(Long userRoleId);

	public Long update(UserRole userInfo);
	
	public boolean checkUserRoleId(Long userRoleId);

}
