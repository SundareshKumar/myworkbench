package com.oab.iam.util;

import java.security.Security;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Supplier;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import com.sun.crypto.provider.SunJCE;

import sun.misc.BASE64Encoder;

@Component
public class SendEmail {

	@Value("${mail.title}")
	private String mailTitle;

	@Value("${mail.body1.inst}")
	private String mailBodyInst;

	@Value("${mail.body2.inst}")
	private String mailBody2Inst;

	@Value("${mail.instlogin}")
	private String mailInstLogin;

	@Value("${mail.loginurl.inst}")
	private String mailLoginUrlInst;

	@Value("${mail.passwordURL}")
	private String mailPasswordUrl;

	@Value("${mail.body3.common}")
	private String mailBodyCommon;

	@Value("${mail.body4.common}")
	private String mailBody4Common;

	@Value("${mail.body5.common}")
	private String mailBody5Common;

	@Value("${mail.regards.inst}")
	private String mailRRegardsInst;

	@Value("${mail.regards.inst}")
	private String mailSubjectInst;

	@Value("${mailsmtphost}")
	private String mailsmtphost;

	@Value("${app.context.path}")
	private String contextPath;

	@Value("${fromAddrs}")
	private String fromAddrs;

	@Value("${regards}")
	private String regards;

	@Autowired
	@Qualifier("customThreadExecutor")
	private TaskExecutor executor;

	private static String secKey = "222222222222222222222222222222222222222222222222";
	private static String key = "222222222222222222222222222222222222222222222222";
	private static int mailLinkExpiryFrame = 1; // in hours
	private static SunJCE sunjce = new SunJCE();

	public boolean sendEmailAsyc(String userName, String userId, String toAddrs, Integer instId, Integer userType,
			long userKey) {
		CompletableFuture<String> future = null;
		try {

			future = CompletableFuture.supplyAsync(new Supplier<String>() {
				@Override
				public String get() {
					try {
						sendEmail(userName, userId, toAddrs, instId, userType, userKey);
						return "Message Sent";
					} catch (Exception e) {
						return e.getMessage();
					}
				}

			}, executor);
			future.thenAcceptAsync(new Consumer<String>() {
				@Override
				public void accept(String response) {
					System.out.println(response);
				}
			}, executor);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private boolean sendEmail(String userName, String userId, String toAddrs, Integer instId, Integer userType,
			long userKey) throws Exception {

		InternetAddress internetAddress[] = null;
		StringBuffer key = null;
		String encMerchKey = null;
		String hexMerchKey = null;
		Calendar calendar = null;
		SimpleDateFormat sdf1 = null;
		String currDate = null;
		String encTime = null;
		String hexTime = null;
		Date date = null;
		SimpleDateFormat sdf = null;
		String activationDate = null;
		String dynamic_logo = "";
		String oablogo = null;
		String mailBody = null;
		try {
			internetAddress = new InternetAddress[1];
			internetAddress[0] = new InternetAddress(toAddrs);

			String usrType = userType + "";
			key = new StringBuffer();
			key = key.append(userId).append("-").append(userName).append("-").append(instId).append("-").append(usrType)
					.append("-").append(userKey);
			encMerchKey = encrypt(generateDESedeKey(secKey), key.toString());
			hexMerchKey = alpha2Hex(encMerchKey);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.HOUR, mailLinkExpiryFrame);
			sdf1 = new SimpleDateFormat("ddMMyyHHmm");
			currDate = sdf1.format(calendar.getTime());
			encTime = performEncryption(currDate, userId);
			hexTime = alpha2Hex(encTime);
			date = new Date();
			sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			activationDate = sdf.format(date);
			oablogo = "<font color=blue size=6>OAB</font>";
			oablogo += "&nbsp;";
			oablogo += "<font color=green size=6>IPAY</font>";

			mailBody = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>"
					+ "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>"
					+ "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>" + "<title>" + mailTitle
					+ "</title>" + "</head><body style='margin:0px 0px 0px 0px; color:#707070; background-color:#fff '>"
					+ "<div align='center'>"
					+ "<table width='600' border='0' align='center' cellpadding='0' cellspacing='0' >"
					+ "<tr><td colspan='3'>&nbsp;</td>" + "</tr><tr>"
					+ "<td width='156' height='60' align='left' valign='middle'>" + oablogo
					+ "<td width='170' align='left' valign='middle'>" + dynamic_logo + "</td>"
					+ "<td width='397' align='right' valign='middle'></td></tr>"
					+ "<tr><td colspan='3'><table width='950' border='0' cellspacing='0' cellpadding='0'>"
					+ "<tr><td width='380' valign='top' style='background-image:url(\"cid:image3\"); height:34px;background-repeat:repeat-x;'>&nbsp;</td>"
					+ "<td width='60' valign='top'style='background-image:url(\"cid:image4\"); width:60px;height:34px; background-repeat:no-repeat;'>&nbsp;</td>"
					+ "<td width='509' align='right' valign='top' style='background-image:url(\"cid:image5\"); background-repeat:repeat-x; height:34px; color:#FFFFFF; text-shadow: 0.1em 0.1em 0.05em #6e7367; font-weight:bold;'>"
					+ "<table width='461' border='0' cellspacing='0' cellpadding='0'>"
					+ "<tr><td align='center' width='100%'></td>"
					+ "</tr></table></td><td width='1' valign='top' style='background-image:url(\"cid:image6\");background-repeat:no-repeat;width:2px;background-position:right;'></td>"
					+ "</tr></table></td></tr><tr><td colspan='3' style='height:2px; color:#ffffff;'></td></tr>"
					+ "<tr><td colspan='4'style='background-repeat:repeat-x; padding:0px 30px 30px 30px; background-color:#FFFFFF;background-position:top;' align='left'><table  width='80%' border='0' cellspacing='0' cellpadding='0'>"
					+ "<tr  align='left'>" + "<td colspan='4' style='padding:10px;'>" + mailBodyInst + "&nbsp;"
					+ "<strong>" + userName.toUpperCase() + ",</strong></td>" + "</tr>" + "<tr>"
					+ "<td height='76' colspan='4' valign='top' style='padding:10px;'><p>Welcome!</p>" + " <p>"
					+ mailBody2Inst + "</p></td>" + "</tr>" + "<tr>" + "<td>&nbsp;</td>"
					+ "<td width='17%'>Date of Activation</td>" + "<td>:</td>" + "<td>" + activationDate + "</td>"
					+ "</tr>" + "<tr>" + "<td>&nbsp;</td>" + "<td>" + mailInstLogin + "</td>" + "<td>:</td>" + "<td>"
					+ "<a href=" + contextPath + mailLoginUrlInst + ">" + contextPath + mailLoginUrlInst + "</td>"
					+ "</tr>" + "<tr>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>"
					+ "</tr>" +

					"<tr>" + "<td>&nbsp;</td>" + "<td colspan='3'>" + "<a href=" + contextPath + mailPasswordUrl
					+ "?id=" + hexMerchKey + "&param=" + hexTime + ">" + mailBodyCommon + "</td>" + "</tr>" + "<tr>"
					+ "<td>&nbsp;</td>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>" + "</tr>" + "<tr>"
					+ "</tr>" + "<tr>" + "<td>&nbsp;</td>" + "<td colspan='3'>" + mailBody4Common + "&nbsp;"
					+ mailLinkExpiryFrame + "&nbsp;" + mailBody5Common + "</td>" +

					"<tr>" + "<td width='9'>&nbsp;</td>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>"
					+ "</tr>" + "<tr><td></td>" + "<td >" + mailRRegardsInst + "</td>" + "<td>&nbsp;</td>"
					+ "<td>&nbsp;</td>" + "</tr>" + "<tr>" + "<td>&nbsp;</td>" + "<td>" + regards + "</td>"
					+ "<td>&nbsp;</td>" + "<td>&nbsp;</td>" + "</tr>" + "<tr>" + "<td>&nbsp;</td>" + "<td>&nbsp;</td>"
					+ "<td>&nbsp;</td>" + "<td>&nbsp;</td></tr>" + "</table>" + "</td>"
					+ "<tr><td colspan='3'>&nbsp;</td></tr> <tr><td colspan='3' style='background-color:#d71921; height:2px;'></td></tr>"
					+ "<tr><td bgcolor='#000000;' colspan='3'>&nbsp;</td></tr> <tr><td bgcolor='#000000;' colspan='3' align='center'><table bgcolor='#000000;' width='100%' height='100%' border='0' cellspacing='0' cellpadding='0'>"
					+ "<tr><td bgcolor='#000000;' style='font-size:11px; color:#ffffff; text-align:left;' colspan='3'>&nbsp; Copyright � 2016 Financial Software &amp; Systems Pvt. Ltd. All Rights Reserved.</td>"
					+ "<td bgcolor='#000000;' width='87' align='right'><font color=red size=6>FSS</font></td>"
					+ "<td width='28' align='center'></td>" + "</tr></table></td></tr>"
					+ "<tr><td bgcolor='#000000;' colspan='3'>&nbsp;</td></tr> <tr><td bgcolor='#000000;' colspan='3' align='center'><tr><td colspan='3' colspan='3' style='font-size:11px;color:#666666;'>&nbsp;</td></tr></table></div></body></html>";
			return sendMail(fromAddrs, internetAddress, mailSubjectInst, mailBody);
		} catch (Exception e) {
			throw e;
		}
	}

	private boolean sendMail(String fromAddress, InternetAddress[] internetAddress, String mailSubject, String mailBody)
			throws Exception {
		Properties props = null;
		Session newsession = null;
		MimeMessage mimemsg = null;
		MimeBodyPart mbp1 = null;
		Multipart mp = null;
		try {
			props = new Properties();
			props.put("mail.smtp.host", mailsmtphost);
			newsession = Session.getDefaultInstance(props, null);
			mimemsg = new MimeMessage(newsession);
			mbp1 = new MimeBodyPart();
			mp = new MimeMultipart();
			mimemsg.setFrom(new InternetAddress(fromAddress));
			mimemsg.setRecipients(Message.RecipientType.TO, internetAddress);
			mimemsg.setSubject(mailSubject);
			mbp1.setText(mailBody);
			mimemsg.setSentDate(new Date());
			mbp1.setHeader("Content-Type", "text/html");
			mp.addBodyPart(mbp1);
			mimemsg.setContent(mp);
			Transport.send(mimemsg);
			return true;
		} catch (Exception e) {
			throw e;
		} finally {
			props = null;
			newsession = null;
			mimemsg = null;
			mbp1 = null;
			mp = null;
		}

	}

	private static String performEncryption(String data, String userId) throws Exception {
		StringBuffer sb = null;
		try {
			sb = new StringBuffer();
			sb.append(userId).append(secKey).append(userId);
			return encrypt(generateDESedeKey(sb.toString()), data);
		} catch (Exception e) {
			throw e;
		} finally {
			sb = null;
		}
	}

	private static SecretKey generateDESedeKey(String keyString) throws Exception {
		DESedeKeySpec keyspec = null;
		byte[] key1 = null;
		byte rawkey[] = null;
		SecretKey secretKey = null;
		SecretKeyFactory keyfactory = null;
		try {
			if (keyString.length() < 24) {
				keyString += keyString;
				return generateDESedeKey(keyString);
			}
			key1 = new byte[24];
			rawkey = stringToByteArray(keyString);
			System.arraycopy(rawkey, 0, key1, 0, 24);
			keyspec = new DESedeKeySpec(key1);
			Security.addProvider(sunjce);
			Security.insertProviderAt(sunjce, 1);
			keyfactory = SecretKeyFactory.getInstance("DESede", sunjce);
			secretKey = keyfactory.generateSecret(keyspec);
			return secretKey;
		} catch (Exception e) {
			throw e;
		} finally {
			keyspec = null;
			key1 = null;
			rawkey = null;
			secretKey = null;
		}
	}

	private static byte[] stringToByteArray(String string) {
		byte[] bytes = new byte[string.length()];
		char[] chars = string.toCharArray();
		for (int i = 0; i != chars.length; i++) {
			bytes[i] = (byte) chars[i];
		}
		return bytes;
	}

	private static String encrypt(SecretKey secretkey, String s) throws Exception {
		Cipher cipher = null;
		String s1 = "";
		byte abyte0[] = null;
		BASE64Encoder base64encoder = null;
		try {
			cipher = Cipher.getInstance("DESede");
			cipher.init(1, secretkey);
			abyte0 = cipher.doFinal(s.getBytes("UTF-8"));
			base64encoder = new BASE64Encoder();
			s1 = base64encoder.encode(abyte0);
			return s1;
		} catch (Exception ex) {
			throw ex;
		} finally {
			cipher = null;
			s1 = null;
			abyte0 = null;
			base64encoder = null;
		}

	}

	private static String alpha2Hex(String data) {
		char[] alpha = data.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < alpha.length; i++) {
			int count = Integer.toHexString(alpha[i]).toUpperCase().length();
			if (count <= 1) {
				sb.append("0").append(Integer.toHexString(alpha[i]).toUpperCase());
			} else {
				sb.append(Integer.toHexString(alpha[i]).toUpperCase());
			}
		}
		return sb.toString();
	}

}
