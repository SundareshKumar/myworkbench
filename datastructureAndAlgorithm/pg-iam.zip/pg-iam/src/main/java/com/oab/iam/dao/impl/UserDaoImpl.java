package com.oab.iam.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.oab.iam.dao.IUserDao;
import com.oab.iam.dao.IUserRoleDao;
import com.oab.iam.model.UserInfo;
import com.oab.iam.util.idgen.UID;

@Repository
public class UserDaoImpl implements IUserDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private IUserRoleDao userRoleDao;  

	public Long create(UserInfo userInfo) {
		String sql = "insert into USER_INFO (USER_KEY, USER_ID, USER_NAME, USER_ROLE_ID, DESCRIPTION,"
				+ " USER_TYPE, ADMIN_FLG, BLOCKED, CARD_MASKING, DASHBOARD_FLAG,"
				+ " EMAIL_DATETIME, EMAIL_ID, EMAIL_STATUS, FAILED_ATTEMPTS, INST_ID,"
				+ " LANGUAGE, LAST_LOGGED_DATE, LOCKOUT_DATE, LOGGED_DATE, MOBILE_NO,"
				+ " MRCH_ID, MUST_CHANGE, USER_EXP_FLAG, USER_EXP_PERIOD, WORK_START_TIME,"
				+ " WORK_END_TIME, DASHBOARD_MENU, USER_EXPIRY_DATE, CREATED_BY,CREATED_DATE" 
				+ ", STATUS)" 
				+ " values "
				+ "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Long userKey = null;
		try {
			if (checkUserId(userInfo.getUserId())) {
				return -1L;
			}
			if (!userRoleDao.checkUserRoleId(userInfo.getUserRoleId())) {
				return -2L;
			}
			userKey = UID.genId();
			jdbcTemplate.update(sql,
					new Object[] { userKey, userInfo.getUserId(), userInfo.getUserName(), userInfo.getUserRoleId(),
							userInfo.getDesc(), // Description
							2, // User Type
							0, // Admin Flag
							userInfo.getBlocked(), // Blocked
							0, // Card Masking
							0, // Dashboard Flag
							new java.sql.Timestamp(System.currentTimeMillis()),
							userInfo.getEmailId(),
							1, // Email Status
							0, // Failed Attempt
							1, // Institution Id
							0, // Language
							null, // Last Logged Date
							null, // Lockout Date
							null, // Logged Date
							userInfo.getMobile(), 0, // Merchant Id
							1, // Must Change
							userInfo.getUserExpFlag(), // User Expiry Flag
							userInfo.getUserExpPrd(), // User Expiry Date
							userInfo.getWorkStTime(),
							userInfo.getWorkEndTime(),
							0, // Dashboard Menu
							userInfo.getUserExpDate(), // User Expiry Date
							"IAM API", // Created By
							new java.sql.Timestamp(System.currentTimeMillis()), // Created Date
							1 });
			return userKey;
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean checkUserId(String userId) {
		String sql = null;
		UserInfo userInfo = null;
		try {
			sql = "select * from user_info where USER_ID = ? and USER_TYPE = ?";
			userInfo = getUniqueObjectByQuery(sql, new Object[] { userId, 2 }, new RowMapper<UserInfo>() {
				public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserInfo userInfo = new UserInfo();
					userInfo.setUserKey(rs.getLong("user_key"));
					userInfo.setUserId(rs.getString("user_id"));
					userInfo.setUserName(rs.getString("user_name"));
					userInfo.setDesc(rs.getString("DESCRIPTION"));
					userInfo.setUserRoleId(rs.getLong("user_role_id"));
					userInfo.setEmailId(rs.getString("EMAIL_ID"));
					userInfo.setMobile(rs.getString("MOBILE_NO"));
					userInfo.setWorkStTime(rs.getString("WORK_START_TIME"));
					userInfo.setWorkEndTime(rs.getString("WORK_END_TIME"));
					userInfo.setUserExpFlag(rs.getInt("USER_EXP_FLAG"));
					userInfo.setUserExpPrd(rs.getInt("USER_EXP_PERIOD"));
					userInfo.setBlocked(rs.getInt("BLOCKED"));
					userInfo.setFailedAttempts(rs.getInt("FAILED_ATTEMPTS"));
					userInfo.setMustChange(rs.getInt("MUST_CHANGE"));
					userInfo.setUserType(rs.getInt("USER_TYPE"));
					userInfo.setLastLoggedDate(rs.getDate("LAST_LOGGED_DATE"));
					return userInfo;
				}
			});
			return (userInfo == null ? false : true);
		} catch (Exception e) {
			return false;
		}

	}

	protected <T> T getUniqueObjectByQuery(String sqlQuery, Object[] param, RowMapper<T> mapper) {
		try {
			return (T) jdbcTemplate.queryForObject(sqlQuery, param, mapper);
		} catch (Exception e) {
			if(e instanceof EmptyResultDataAccessException) {
				return null;
			}else{
				throw e;	
			}
		}
	}

	public List<UserInfo> getUserInfo() {
		List<UserInfo> userList = jdbcTemplate.query("select * from user_info where USER_TYPE = ?", new Object[] { 2 },
				new RowMapper<UserInfo>() {
					public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
						UserInfo userInfo = new UserInfo();
						userInfo.setUserKey(rs.getLong("user_key"));
						userInfo.setUserId(rs.getString("user_id"));
						userInfo.setUserName(rs.getString("user_name"));
						userInfo.setDesc(rs.getString("DESCRIPTION"));
						userInfo.setUserRoleId(rs.getLong("user_role_id"));
						userInfo.setEmailId(rs.getString("EMAIL_ID"));
						userInfo.setMobile(rs.getString("MOBILE_NO"));
						userInfo.setWorkStTime(rs.getString("WORK_START_TIME"));
						userInfo.setWorkEndTime(rs.getString("WORK_END_TIME"));
						userInfo.setUserExpFlag(rs.getInt("USER_EXP_FLAG"));
						userInfo.setUserExpPrd(rs.getInt("USER_EXP_PERIOD"));
						userInfo.setBlocked(rs.getInt("BLOCKED"));
						userInfo.setFailedAttempts(rs.getInt("FAILED_ATTEMPTS"));
						userInfo.setMustChange(rs.getInt("MUST_CHANGE"));
						userInfo.setUserType(rs.getInt("USER_TYPE"));
						userInfo.setLastLoggedDate(rs.getDate("LAST_LOGGED_DATE"));
						userInfo.setStatus(rs.getInt("STATUS") == 1 ? "Active" : "InActive");
						return userInfo;
					}
				});
		return userList;
	}

	public UserInfo getUserInfo(Long userKey) {
		String sql = null;
		UserInfo userInfo = null;
		try {
			sql = "select * from user_info where USER_KEY = ? and USER_TYPE = ?";
			userInfo = getUniqueObjectByQuery(sql, new Object[] { userKey, 2 }, new RowMapper<UserInfo>() {
				public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserInfo userInfo = new UserInfo();
					userInfo.setUserKey(rs.getLong("user_key"));
					userInfo.setUserId(rs.getString("user_id"));
					userInfo.setUserName(rs.getString("user_name"));
					userInfo.setDesc(rs.getString("DESCRIPTION"));
					userInfo.setUserRoleId(rs.getLong("user_role_id"));
					userInfo.setEmailId(rs.getString("EMAIL_ID"));
					userInfo.setMobile(rs.getString("MOBILE_NO"));
					userInfo.setWorkStTime(rs.getString("WORK_START_TIME"));
					userInfo.setWorkEndTime(rs.getString("WORK_END_TIME"));
					userInfo.setUserExpFlag(rs.getInt("USER_EXP_FLAG"));
					userInfo.setUserExpPrd(rs.getInt("USER_EXP_PERIOD"));
					userInfo.setBlocked(rs.getInt("BLOCKED"));
					userInfo.setFailedAttempts(rs.getInt("FAILED_ATTEMPTS"));
					userInfo.setMustChange(rs.getInt("MUST_CHANGE"));
					userInfo.setUserType(rs.getInt("USER_TYPE"));
					userInfo.setLastLoggedDate(rs.getDate("LAST_LOGGED_DATE"));
					userInfo.setStatus(rs.getInt("STATUS") == 1 ? "Active" : "InActive");
					return userInfo;
				}
			});
			return userInfo;
		} catch (Exception e) {
			throw e;
		}
	}

	public UserInfo getUserInfo(String userId) {
		String sql = null;
		UserInfo userInfo = null;
		try {
			sql = "select * from user_info where user_id = ? and USER_TYPE = ?";
			userInfo = getUniqueObjectByQuery(sql, new Object[] { userId, 2 }, new RowMapper<UserInfo>() {
				public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserInfo userInfo = new UserInfo();
					userInfo.setUserKey(rs.getLong("user_key"));
					userInfo.setUserId(rs.getString("user_id"));
					userInfo.setUserName(rs.getString("user_name"));
					userInfo.setDesc(rs.getString("DESCRIPTION"));
					userInfo.setUserRoleId(rs.getLong("user_role_id"));
					userInfo.setEmailId(rs.getString("EMAIL_ID"));
					userInfo.setMobile(rs.getString("MOBILE_NO"));
					userInfo.setWorkStTime(rs.getString("WORK_START_TIME"));
					userInfo.setWorkEndTime(rs.getString("WORK_END_TIME"));
					userInfo.setUserExpFlag(rs.getInt("USER_EXP_FLAG"));
					userInfo.setUserExpPrd(rs.getInt("USER_EXP_PERIOD"));
					userInfo.setBlocked(rs.getInt("BLOCKED"));
					userInfo.setFailedAttempts(rs.getInt("FAILED_ATTEMPTS"));
					userInfo.setMustChange(rs.getInt("MUST_CHANGE"));
					userInfo.setUserType(rs.getInt("USER_TYPE"));
					userInfo.setLastLoggedDate(rs.getDate("LAST_LOGGED_DATE"));
					userInfo.setStatus(rs.getInt("STATUS") == 1 ? "Active" : "InActive");
					return userInfo;
				}
			});
			return userInfo;
		} catch (Exception e) {
			throw e;
		}
	}

	
	@Override
	public Long update(UserInfo userInfo) {
		String sql = "UPDATE USER_INFO SET "
				+ "USER_NAME = ? , "
				+ "USER_ROLE_ID = ? , "
				+ "DESCRIPTION = ?, "
				+ "BLOCKED = ? , "
				+ "EMAIL_ID = ?, "
				+ "MOBILE_NO = ?, "
				+ "MUST_CHANGE = ?, "
				+ "USER_EXP_FLAG =?, "
				+ "USER_EXP_PERIOD = ?, "
				+ "WORK_START_TIME =? , "
				+ "WORK_END_TIME = ?, "
				+ "USER_EXPIRY_DATE = ?, "
				+ "MODIFIED_BY = ?, "
				+ "MODIFIED_DATE = ? "
				+ "where "
				+ "USER_KEY = ?";
		UserInfo userInfoTmp = null;
		try {
			if (!checkUserId(userInfo.getUserId())) {
				return -1L;
			}
			if (((userInfoTmp = getUserInfo(userInfo.getUserKey())) == null)) {
				return -2L;
			}else if(userInfoTmp.getStatus() == "InActive"){
				return -3L;
			}
			if (!userRoleDao.checkUserRoleId(userInfo.getUserRoleId())) {
				return -4L;
			}
			jdbcTemplate.update(sql,
					new Object[] { 
							userInfo.getUserName(), 
							userInfo.getUserRoleId(),
							userInfo.getDesc(), // Description
							userInfo.getBlocked(), // Blocked
							userInfo.getEmailId(),
							userInfo.getMobile(), 
							userInfo.getMustChange(),  // Must Change
							userInfo.getUserExpFlag(), // User Expiry Flag
							userInfo.getUserExpPrd(), // User Expiry Date
							userInfo.getWorkStTime(), 
							userInfo.getWorkEndTime(),
							userInfo.getUserExpDate(), // User Expiry Date
							"IAM API", // Modified By
							new java.sql.Timestamp(System.currentTimeMillis()), // Modified By
							userInfo.getUserKey()
						});
			return userInfo.getUserKey();
		} catch (Exception e) {e.printStackTrace();
			throw e;
		} finally {
			userInfoTmp = null;
		}
	}
	
	
	public int changeStatus(UserInfo userInfo) {
		String sql = "UPDATE USER_INFO SET STATUS = ?, MODIFIED_BY = ?, MODIFIED_DATE = ? where USER_KEY = ?";
		try {
			UserInfo userInfoTmp = null; 
			if (((userInfoTmp = getUserInfo(userInfo.getUserKey())) == null)) {
				return -2;
			}else if(userInfoTmp.getStatus().equalsIgnoreCase(userInfo.getStatus())){
				return -3;
			}
			jdbcTemplate.update(sql,
					new Object[] { 
							userInfo.getStatus().equalsIgnoreCase("active") ? 1 : 0,
							"IAM API", // Modified By
							new java.sql.Timestamp(System.currentTimeMillis()), // Modified By
							userInfo.getUserKey()
						});
			return 1;
		} catch (Exception e) {
			throw e;
		}
	}
}
