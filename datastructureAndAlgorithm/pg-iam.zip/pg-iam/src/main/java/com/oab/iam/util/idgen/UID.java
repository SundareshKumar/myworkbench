package com.oab.iam.util.idgen;

import java.util.Random;

public class UID {
	public static long genId() {
		Random generator = new Random(System.currentTimeMillis());
		return generator.nextLong() % 1000000000000L & Integer.MAX_VALUE;
	}
}
