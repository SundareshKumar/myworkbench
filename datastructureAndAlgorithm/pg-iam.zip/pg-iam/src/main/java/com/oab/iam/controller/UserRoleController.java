package com.oab.iam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oab.iam.dao.IUserRoleDao;
import com.oab.iam.model.UserRole;
import com.oab.iam.util.Response;

@RestController
@RequestMapping("/api/v1/userRole")
public class UserRoleController {

	@Autowired
	private IUserRoleDao userRoleDao;

	@PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> create(@RequestBody UserRole userRole) {
		Response<String> response = null;
		Long userRoleId = null;
		try {
			response = new Response<>();
			userRoleId = userRoleDao.create(userRole);
			response.setData(userRoleId.toString());
			response.setStatus(200);
			if (userRoleId == -1) {
				response.setMessage("User Role with same role name already exits.");
			} else {
				response.setMessage("User Role Created Successfully.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return response;
	}

	@GetMapping(value = "{userRoleId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<UserRole> get(@PathVariable("userRoleId") Long userRoleId) {
		UserRole userRole = userRoleDao.getUserRole(userRoleId);
		Response<UserRole> response = null;
		response = new Response<>();
		response.setData(userRole);
		response.setStatus(200);
		response.setMessage("Data Retrieved Successfully.");
		return response;
	}

	@GetMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<List<UserRole>> list() {
		List<UserRole> userRoleLst = userRoleDao.getUserRole();
		Response<List<UserRole>> response = null;
		response = new Response<>();
		response.setData(userRoleLst);
		response.setStatus(200);
		response.setMessage("Data Retrieved Successfully.");
		return response;
	}

	@PostMapping(value = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> update(@RequestBody UserRole userRole) {
		Response<String> response = null;
		Long userRoleId = null;
		try {
			userRoleId = userRoleDao.update(userRole);
			response = new Response<>();
			response.setData(userRoleId.toString());
			response.setStatus(200);
			response.setMessage("User Role updated successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return response;
	}

}
