package com.oab.iam.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value = Include.NON_EMPTY)
public class UserInfo {

	private Long userKey;
	private String userId;
	private String userName;
	private Long userRoleId;
	private String emailId;
	private String mobile;
	private Integer userExpFlag;
	private Integer userExpPrd;
	private Date userExpDate;
	private String workStTime;
	private String workEndTime;
	private Integer adminFlg;
	private Integer failedAttempts;
	private Integer blocked;
	private Integer mustChange;
	private Date loggedDate;
	private Integer emailStatus;
	private Date emailDateTime;
	private Date lastLoggedDate;
	private Date lockoutdate;
	private Integer userType;
	private String desc;
	private String createdBy;
	private Date createdDate;
	private String modifiedBy;
	private Date modifiedDate;
	private String status;
	
	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getUserExpFlag() {
		return userExpFlag;
	}

	public void setUserExpFlag(Integer userExpFlag) {
		this.userExpFlag = userExpFlag;
	}

	public Integer getUserExpPrd() {
		return userExpPrd;
	}

	public void setUserExpPrd(Integer userExpPrd) {
		this.userExpPrd = userExpPrd;
	}

	public Date getUserExpDate() {
		return userExpDate;
	}

	public void setUserExpDate(Date userExpDate) {
		this.userExpDate = userExpDate;
	}

	public String getWorkStTime() {
		return workStTime;
	}

	public void setWorkStTime(String workStTime) {
		this.workStTime = workStTime;
	}

	public String getWorkEndTime() {
		return workEndTime;
	}

	public void setWorkEndTime(String workEndTime) {
		this.workEndTime = workEndTime;
	}

	public Integer getAdminFlg() {
		return adminFlg;
	}

	public void setAdminFlg(Integer adminFlg) {
		this.adminFlg = adminFlg;
	}

	public Integer getFailedAttempts() {
		return failedAttempts;
	}

	public void setFailedAttempts(Integer failedAttempts) {
		this.failedAttempts = failedAttempts;
	}

	public Integer getBlocked() {
		return blocked;
	}

	public void setBlocked(Integer blocked) {
		this.blocked = blocked;
	}

	public Integer getMustChange() {
		return mustChange;
	}

	public void setMustChange(Integer mustChange) {
		this.mustChange = mustChange;
	}

	public Date getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Date loggedDate) {
		this.loggedDate = loggedDate;
	}

	public Integer getEmailStatus() {
		return emailStatus;
	}

	public void setEmailStatus(Integer emailStatus) {
		this.emailStatus = emailStatus;
	}

	public Date getEmailDateTime() {
		return emailDateTime;
	}

	public void setEmailDateTime(Date emailDateTime) {
		this.emailDateTime = emailDateTime;
	}

	public Date getLastLoggedDate() {
		return lastLoggedDate;
	}

	public void setLastLoggedDate(Date lastLoggedDate) {
		this.lastLoggedDate = lastLoggedDate;
	}

	public Date getLockoutdate() {
		return lockoutdate;
	}

	public void setLockoutdate(Date lockoutdate) {
		this.lockoutdate = lockoutdate;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
