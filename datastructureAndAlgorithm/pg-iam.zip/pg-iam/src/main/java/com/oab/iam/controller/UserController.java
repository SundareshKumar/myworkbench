package com.oab.iam.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oab.iam.dao.IUserDao;
import com.oab.iam.model.UserInfo;
import com.oab.iam.util.Response;
import com.oab.iam.util.SendEmail;

@RestController
@RequestMapping("/api/v1/user")
public class UserController {

	@Autowired
	private IUserDao userDao;

	@Autowired
	private SendEmail sendEmail;
	
	@PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> create(@RequestBody UserInfo userInfo) throws Exception {
		Response<String> response = null;
		Long userKey = null;
		try {
			response = new Response<>();
			if (userInfo.getUserExpFlag() != null && userInfo.getUserExpFlag() == 1) {
				Date currDate = new Date();
				Calendar cal = Calendar.getInstance();
				cal.setTime(currDate);
				cal.add(Calendar.DATE, userInfo.getUserExpPrd());
				userInfo.setUserExpDate(cal.getTime());
			}
			userKey = userDao.create(userInfo);
			response.setData(userKey.toString());
			response.setStatus(200);
			if (userKey == -1) {
				response.setMessage("User Id already exits.");
			} else if(userKey == -2){
				response.setMessage("User Role not available.");
			}else {
				sendEmail.sendEmailAsyc(userInfo.getUserName(), userInfo.getUserId(), userInfo.getEmailId(), 1, 2, userKey);
				response.setMessage("User Created Successfully.");
			}
			return response;
		} catch (Exception e) {
			throw e;
		} finally {
			response = null;
			userKey = null;
		}
		
	}

	@GetMapping(value = "{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<UserInfo> get(@PathVariable("userId") String userId) {
		UserInfo userInfo = null;
		Response<UserInfo> response = null;
		try {
			userInfo = userDao.getUserInfo(userId);
			response = new Response<>();
			response.setData(userInfo);
			response.setStatus(200);
			response.setMessage("Data Retrieved Successfully.");
			return response;
		} catch (Exception e) {
			throw e;
		} finally {
			userInfo = null;
			response = null;
		}

	}

	@GetMapping(value = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<List<UserInfo>> list() {
		List<UserInfo> userInfoLst = null;
		Response<List<UserInfo>> response = null;
		try {
			userInfoLst = userDao.getUserInfo();
			response = new Response<>();
			response.setData(userInfoLst);
			response.setStatus(200);
			response.setMessage("Data Retrieved Successfully.");
			return response;
		} catch (Exception e) {
			throw e;
		} finally {
			userInfoLst = null;
			response = null;
		}
	}

	@PostMapping(value = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<String> update(@RequestBody UserInfo userInfo) throws Exception {
		Response<String> response = null;
		Long userKey = null;
		UserInfo userInfoTmp = null;
		try {
			response = new Response<>();
			if(((userInfoTmp = userDao.getUserInfo(userInfo.getUserId())) == null)) {
				throw new Exception("User not found for the user id");
			}
			userInfo.setUserKey(userInfoTmp.getUserKey());
			if (userInfo.getUserExpFlag() != null && userInfo.getUserExpFlag() == 1) {
				Date currDate = new Date();
				Calendar cal = Calendar.getInstance();
				cal.setTime(currDate);
				cal.add(Calendar.DATE, userInfo.getUserExpPrd());
				userInfo.setUserExpDate(cal.getTime());
			}
			userKey = userDao.update(userInfo);
			if (userKey == -1) {
				response.setMessage("User Id not available.");
			} else if(userKey == -3){
				response.setMessage("User Status is InActive.");
			} else if(userKey == -4){
				response.setMessage("User Role not available.");
			} else {
				response.setMessage("User updated successfully.");
			}
			response.setData(userKey.toString());
			response.setStatus(200);
			return response;
		} catch (Exception e) {
			throw e;
		} finally {
			response = null;
			userKey = null;
			userInfoTmp = null;
		}

	}

	@PostMapping(value = "/changeStatus", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Integer> changeStatus(@RequestBody UserInfo userInfo) throws Exception {
		Response<Integer> response = null;
		Integer chgStatus = null;
		UserInfo userInfoTmp = null;
		try {
			if(((userInfoTmp = userDao.getUserInfo(userInfo.getUserId())) == null)) {
				throw new Exception("User not found for the user id");
			}
			if(userInfo.getStatus() == null ||
					(!userInfo.getStatus().equalsIgnoreCase("active") &&
					!userInfo.getStatus().equalsIgnoreCase("inactive"))) {
				throw new Exception("Invalid status received in request parameter.");
			}
			userInfo.setUserKey(userInfoTmp.getUserKey());
			chgStatus = userDao.changeStatus(userInfo);
			response = new Response<>();
			response.setData(chgStatus);
			response.setStatus(200);
			if (chgStatus == -2) {
				response.setMessage("User not found with the user key.");
			} else if (chgStatus == -3) {
				response.setMessage("User available with same status.");
			} else {
				response.setMessage("Status changed successfully.");
			}
			return response;
		} catch (Exception e) {
			throw e;
		} finally {
			response = null;
			chgStatus = null;
		}
	

	}

}
