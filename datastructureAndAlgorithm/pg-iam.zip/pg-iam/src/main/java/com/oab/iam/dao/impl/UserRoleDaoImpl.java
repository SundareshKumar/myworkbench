package com.oab.iam.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.oab.iam.dao.IUserRoleDao;
import com.oab.iam.model.UserRole;
import com.oab.iam.util.idgen.UID;

@Repository
public class UserRoleDaoImpl implements IUserRoleDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public Long create(UserRole userRole) {
		String sql = "insert into USER_ROLE (USER_ROLE_ID, USER_ROLE_NAME, USER_ROLE_TYPE, MRCH_ID, INST_ID,"
				+ " DESCRIPTION, CREATED_BY, CREATED_DATE)" 
				+ " values "
				+ "(?, ?, ?, ?, ?, ?, ?, ?)";
		Long userRoleId = null;
		try {
			if (checkUserRoleName(userRole.getUserRoleName())) {
				return -1L;
			}
			userRoleId = UID.genId();
			jdbcTemplate.update(sql,
					new Object[] {
							userRoleId,
							userRole.getUserRoleName(),
							4, // User Role Type
							0, // Merchant Type
							1, // Inst Id
							userRole.getDesc(),
							"IAM API",	// Created By
							new java.sql.Timestamp(System.currentTimeMillis()) // Created Date
							});
			return userRoleId;
		} catch (Exception e) {
			throw e;
		}
	}
	
	public boolean checkUserRoleName(String userRoleName) {
		String sql = null;
		UserRole userRole = null;
		try {
			sql = "select * from USER_ROLE where USER_ROLE_NAME = ? and USER_ROLE_TYPE = ?";
			userRole = getUniqueObjectByQuery(sql, new Object[] { userRoleName, 4 }, new RowMapper<UserRole>() {
				public UserRole mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserRole userRole = new UserRole();
					userRole.setUserRoleId(rs.getLong("user_role_id"));
					userRole.setUserRoleName(rs.getString("USER_ROLE_NAME"));
					userRole.setDesc(rs.getString("DESCRIPTION"));
					return userRole;
				}
			});
			return (userRole == null ? false : true);
		} catch (Exception e) {
			return false;
		}

	}

	protected <T> T getUniqueObjectByQuery(String sqlQuery, Object[] param, RowMapper<T> mapper) {
		try {
			return (T) jdbcTemplate.queryForObject(sqlQuery, param, mapper);
		} catch (Exception e) {
			if(e instanceof EmptyResultDataAccessException) {
				return null;
			}else{
				throw e;	
			}
		}
	}


	@Override
	public List<UserRole> getUserRole() {
		List<UserRole> userRoleList = jdbcTemplate.query("select * from USER_ROLE where USER_ROLE_TYPE = ?", new Object[] { 4 },
				new RowMapper<UserRole>() {
					public UserRole mapRow(ResultSet rs, int rowNum) throws SQLException {
						UserRole userRole = new UserRole();
						userRole.setUserRoleId(rs.getLong("user_role_id"));
						userRole.setUserRoleName(rs.getString("USER_ROLE_NAME"));
						userRole.setDesc(rs.getString("DESCRIPTION"));
						return userRole;
					}
				});
		return userRoleList;
	}

	@Override
	public UserRole getUserRole(Long userRoleId) {
		String sql = null;
		UserRole userRole = null;
		try {
			sql = "select * from USER_ROLE where USER_ROLE_ID = ? and USER_ROLE_TYPE = ?";
			userRole = getUniqueObjectByQuery(sql, new Object[] { userRoleId, 4 }, new RowMapper<UserRole>() {
				public UserRole mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserRole userRole = new UserRole();
					userRole.setUserRoleId(rs.getLong("user_role_id"));
					userRole.setUserRoleName(rs.getString("USER_ROLE_NAME"));
					userRole.setDesc(rs.getString("DESCRIPTION"));
					return userRole;
				}
			});
			return userRole;
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Long update(UserRole userRole) {
		String sql = "UPDATE USER_ROLE SET "
				+ "USER_ROLE_NAME = ? , "
				+ "DESCRIPTION = ?, "
				+ "MODIFIED_BY = ?, "
				+ "MODIFIED_DATE = ? "
				+ "where "
				+ "USER_ROLE_ID = ?";
		try {
			if (!checkUserRoleName(userRole.getUserRoleName())) {
				return -1L;
			}
			if ((getUserRole(userRole.getUserRoleId())) == null) {
				return -2L;
			}
			jdbcTemplate.update(sql,
					new Object[] { 
							userRole.getUserRoleName(), 
							userRole.getDesc(), // Description
							"IAM API", // Modified By
							new java.sql.Timestamp(System.currentTimeMillis()), // Modified By
							userRole.getUserRoleId()
						});
			return userRole.getUserRoleId();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public boolean checkUserRoleId(Long userRoleId) {
		String sql = null;
		UserRole userRole = null;
		try {
			sql = "select * from USER_ROLE where USER_ROLE_ID = ? and USER_ROLE_TYPE = ?";
			userRole = getUniqueObjectByQuery(sql, new Object[] { userRoleId, 4 }, new RowMapper<UserRole>() {
				public UserRole mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserRole userRole = new UserRole();
					userRole.setUserRoleId(rs.getLong("user_role_id"));
					userRole.setUserRoleName(rs.getString("USER_ROLE_NAME"));
					userRole.setDesc(rs.getString("DESCRIPTION"));
					return userRole;
				}
			});
			return (userRole == null ? false : true);
		} catch (Exception e) {
			return false;
		}

	}

}
