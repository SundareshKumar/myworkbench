package com.oab.iam.dao;

import java.util.List;

import com.oab.iam.model.UserInfo;

public interface IUserDao {

	public Long create(UserInfo userInfo);

	public List<UserInfo> getUserInfo();
	
	public UserInfo getUserInfo(Long userKey);
	
	public UserInfo getUserInfo(String userId);

	public Long update(UserInfo userInfo);
	
	public int changeStatus(UserInfo userInfo);
}
