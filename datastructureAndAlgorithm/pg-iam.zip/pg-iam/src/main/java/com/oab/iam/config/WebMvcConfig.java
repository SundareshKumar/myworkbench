package com.oab.iam.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@ComponentScan({ "com.oab.iam.config", "com.oab.iam.dao", "com.oab.iam.util", "com.oab.iam.controller" })
@PropertySource(value = "classpath:config/${impl.env}/configurations.properties", ignoreResourceNotFound = true)
public class WebMvcConfig {
	
	@Value("${db.url}")
	private String dbUrl;
	@Value("${db.username}")
	private String dbUserName;
	@Value("${db.pwd}")
	private String dbPwd;
	
	@Bean
	JdbcTemplate getJdbcTemplate() {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		ds.setUrl(dbUrl);
		ds.setUsername(dbUserName);
		ds.setPassword(dbPwd);
		return new JdbcTemplate(ds);
	}

}