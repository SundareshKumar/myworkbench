package com.schedule.starter;

import java.util.Timer;

public class SchedulerMain {
	public static void main(String args[]) throws InterruptedException {
		Timer time = new Timer(); 
		ScheduledTask st = new ScheduledTask(); 
		time.schedule(st, 0, 10000); 
	}
}
