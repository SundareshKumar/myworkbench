package com.schedule.starter;

import java.util.Date;
import java.util.TimerTask;

import com.schedule.inquiryproceser.InquiryProcessor;

public class ScheduledTask extends TimerTask {
	Date now; 
	private InquiryProcessor inquiryProcessor = new InquiryProcessor();
	public void run() {
		now = new Date(); 
		System.out.println("Time is :" + now); 
		inquiryProcessor.doProcessInquiry();
	}
}
