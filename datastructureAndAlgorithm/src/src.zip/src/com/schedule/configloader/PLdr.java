package com.schedule.configloader;

import java.io.FileInputStream;
import java.util.Properties;

public class PLdr {
	private static Properties properties = null;

	private static Properties loadproperties() {
		try {
			if(properties != null) {
				return properties;
			}
			properties = new Properties();
			properties.load(new FileInputStream("S:\\WorkSpace\\PaymentMerchantPlugin\\InquiryScheduler\\src\\mrchcrdential\\mrchcrdntl.properties"));
			return properties;
		} catch (Exception e) {
			return null;
		}
	}
	
	public static String getMrchCrdntl(String key) {
		return (String) loadproperties().get(key);
	}

}
