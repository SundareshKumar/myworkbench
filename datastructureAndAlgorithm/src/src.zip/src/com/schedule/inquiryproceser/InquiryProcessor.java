package com.schedule.inquiryproceser;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.List;

import com.schedule.bean.PaymentLog;
import com.schedule.configloader.PLdr;

public class InquiryProcessor {

	private static final String webAddress = "https://certepayments.omannet.om/PG/tranPipe.htm?param=tranInit";
	
	public Integer doProcessInquiry() {
		Integer processCnt = -1;
		List<PaymentLog> paymentLoglst = null;
		try {
			processCnt = processConnect(paymentLoglst);
			
		} catch (Exception e) {
			return processCnt;
		}
		return processCnt;
	}
	
	public Integer processConnect(List<PaymentLog> paymentLoglst) {
		StringBuilder requestbuffer = null;
		String request = null;
		String id = "";
		String password = "";
		int processedCnt = 0; 
		try {
			requestbuffer = new StringBuilder();
			for (PaymentLog paymentLog : paymentLoglst) {
				requestbuffer = buildXMLRequest(paymentLog);
				id = PLdr.getMrchCrdntl(paymentLog.getMerchantId()+"_"+paymentLog.getTerminalId()+"_id");
				password = PLdr.getMrchCrdntl(paymentLog.getMerchantId()+"_"+paymentLog.getTerminalId()+"_pwd");
				requestbuffer.append("<id>" + id + "</id>");
				requestbuffer.append("<password>" + password + "</password>");
				requestbuffer.append("</request>");
				request = requestbuffer.toString();
				sendMessage(request);
				processedCnt++;
			}
		} catch (Exception e) {
			return -1;
		}
		return processedCnt;
	}
	

	private StringBuilder buildXMLRequest(PaymentLog paymentLog) {
		StringBuilder requestbuffer = null;
		try {
			requestbuffer = new StringBuilder();
			requestbuffer.append("<request>");
			if ((paymentLog.getCurrencyCode() != null) && (paymentLog.getCurrencyCode().length() > 0)) {
				requestbuffer.append("<currencycode>" + paymentLog.getCurrencyCode() + "</currencycode>");
			}
			if ((paymentLog.getMrchTrckId() != null) && (paymentLog.getMrchTrckId().length() > 0)) {
				requestbuffer.append("<transid>" + paymentLog.getMrchTrckId() + "</transid>");
			}
			if ((paymentLog.getPaymentAmt() != null) && (paymentLog.getPaymentAmt().length() > 0)) {
				requestbuffer.append("<amt>" + paymentLog.getPaymentAmt() + "</amt>");
			}
			requestbuffer.append("<action>8</action>");
			requestbuffer.append("<trackid>" + new Date().getTime() + "</trackid>");
			requestbuffer.append("<udf1>Inquiry Check</udf1>");
			requestbuffer.append("<udf2>Inquiry Check</udf2>");
			requestbuffer.append("<udf3>Inquiry Check</udf3>");
			requestbuffer.append("<udf4>Inquiry Check</udf4>");
			requestbuffer.append("<udf5>TrackID</udf5>");
			requestbuffer.append("<currencycode>512</currencycode>");
			return requestbuffer;
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			requestbuffer = null;
		}
	}
	
	private static synchronized String sendMessage(String request) {
		String rawResponse = "";
		if (webAddress.indexOf("https") != -1) {
			System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
			System.setProperty("https.protocols", "TLSv1.2");
			System.setProperty("javax.net.debug", "all");

		}
		try {
			URL url = new URL(webAddress);
			URLConnection urlconnection = url.openConnection();
			urlconnection.setDoInput(true);
			urlconnection.setDoOutput(true);
			urlconnection.setUseCaches(false);
			urlconnection.setRequestProperty("Content-Type", "application/xml");
			if (request.length() > 0) {
				DataOutputStream dataoutputstream = new DataOutputStream(urlconnection.getOutputStream());
				dataoutputstream.writeBytes(request);
				dataoutputstream.flush();
				dataoutputstream.close();
				BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(urlconnection.getInputStream()));
				StringBuffer buf = new StringBuffer();
				while (true) {
					String s = bufferedreader.readLine();
					if (s == null)
						break;
					buf.append(s);
				}
				rawResponse = buf.toString();
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
		return rawResponse;
	}
}
