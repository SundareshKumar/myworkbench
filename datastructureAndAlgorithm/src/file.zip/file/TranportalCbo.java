package com.fss.plugin;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.springframework.util.StringUtils;

import com.fss.commons.connections.HostErrorCodes;
import com.fss.commons.utils.RRN;
import com.fss.commons.utils.UniqueIdGenerator;
import com.fss.jdbcConn.utils.ConfigFileUtil;
import com.fss.jdbcConn.utils.LocalObject;
import com.fss.pg.common.PGLogger;
import com.fss.pg.common.util.ResourceBundleUtil;
import com.fss.pg.persistance.admin.tools.ExtrConn;
import com.fss.pg.persistance.payment.PaymentLog;
import com.fss.util.payment.PaymentConstants;


public class TranportalCbo {
		
	public String performCBOMiddlewareTransaction(String request, ExtrConn extrconn, long paymentId) {
		String cboResponse = "";
		String cboWebserverURL = "";
		StringBuffer requestLog = null;
		String cboFinalRequest = null;
		try {
			cboWebserverURL = ConfigFileUtil.getProperty("WEBSERVER_CBO_URL");
			request = request.replace("</reques t>", "");
			requestLog = new StringBuffer(request);
			requestLog.append("<cbourl>" + extrconn.getUrl() + "</cbourl>");
			requestLog.append("</request>");
			cboFinalRequest = new String(requestLog);	
			if(cboFinalRequest.contains("<cvv2>") && cboFinalRequest.contains("</cvv2>"))
				requestLog.replace(requestLog.indexOf("<cvv2>")+"<cvv2>".length(), requestLog.indexOf("</cvv2>"), "****");
			if(cboFinalRequest.contains("<expyear>") && cboFinalRequest.contains("</expyear>"))
				requestLog.replace(requestLog.indexOf("<expyear>")+"<expyear>".length(), requestLog.indexOf("</expyear>"), "****");
			if(cboFinalRequest.contains("<expmonth>") && cboFinalRequest.contains("</expmonth>"))
				requestLog.replace(requestLog.indexOf("<expmonth>")+"<expmonth>".length(), requestLog.indexOf("</expmonth>"), "****");
			if(cboFinalRequest.contains("<password>") && cboFinalRequest.contains("</password>"))
				requestLog.replace(requestLog.indexOf("<password>")+"<password>".length(), requestLog.indexOf("</password>"), "****");
			if(cboFinalRequest.contains("<card>") && cboFinalRequest.contains("</card>"))
				requestLog.replace(requestLog.indexOf("<card>")+11, requestLog.indexOf("</card>")-5, "****");
			PGLogger.logTrace(paymentId, "CBO transaction request : " + requestLog, PaymentConstants.log_transaction_info);		
			cboResponse = sendMessage(cboFinalRequest, cboWebserverURL, extrconn, paymentId);
//			cboResponse = "<result>CAPTURED</result><auth>000000</auth><ref>027880000016</ref><postdate>1004</postdate><tranid>202027812430069</tranid><trackid>1958829801</trackid><payid>302202027887581657</payid><udf1>udf111111111111111111111111111111111111111111</udf1><udf2>udf2222222222222222222222222222222222222222222</udf2><udf3>04-10-2020 19:21:00.171</udf3><udf4>432410******2264</udf4><udf5>VISA</udf5><amt>13.0</amt>";
			cboResponse = "<result>SUCCESS</result><auth>302746</auth><ref>"+RRN.genRRN()+"</ref><postdate>0314</postdate><tranid>"+RRN.genTranId()+"</tranid>"
					+ "<trackid>"+requestLog.substring(requestLog.indexOf("<trackid>")+"<trackid>".length(), requestLog.indexOf("</trackid>"))+"</trackid>"
					+ "<payid>218202107392431905</payid>"
					+ "<udf1>ARB</udf1><udf2>Udf2</udf2><udf3>14-03-2021 13:47:33.910</udf3><udf4>483791******9486</udf4><udf5>VISA</udf5>"
					+ "<amt>"+requestLog.substring(requestLog.indexOf("<amt>")+"<amt>".length(), requestLog.indexOf("</amt>"))+"</amt>";
			if(cboFinalRequest.contains("<action>3</action>")) {
				cboResponse = "<result>VOIDED</result><auth>302746</auth><ref>"+RRN.genRRN()+"</ref><postdate>0314</postdate><tranid>"+RRN.genTranId()+"</tranid>"
						+ "<trackid>"+requestLog.substring(requestLog.indexOf("<trackid>")+"<trackid>".length(), requestLog.indexOf("</trackid>"))+"</trackid>"
						+ "<payid>218202107392431905</payid>"
						+ "<udf1>ARB</udf1><udf2>Udf2</udf2><udf3>14-03-2021 13:47:33.910</udf3><udf4>483791******9486</udf4><udf5>VISA</udf5>"
						+ "<amt>"+requestLog.substring(requestLog.indexOf("<amt>")+"<amt>".length(), requestLog.indexOf("</amt>"))+"</amt>";
			}else if (cboFinalRequest.contains("<action>2</action>")) {
				cboResponse = "<result>CAPTURED</result><auth>302746</auth><ref>"+RRN.genRRN()+"</ref><postdate>0314</postdate><tranid>"+RRN.genTranId()+"</tranid>"
						+ "<trackid>"+requestLog.substring(requestLog.indexOf("<trackid>")+"<trackid>".length(), requestLog.indexOf("</trackid>"))+"</trackid>"
						+ "<payid>218202107392431905</payid>"
						+ "<udf1>ARB</udf1><udf2>Udf2</udf2><udf3>14-03-2021 13:47:33.910</udf3><udf4>483791******9486</udf4><udf5>VISA</udf5>"
						+ "<amt>"+requestLog.substring(requestLog.indexOf("<amt>")+"<amt>".length(), requestLog.indexOf("</amt>"))+"</amt>";
			}
			PGLogger.logTrace(paymentId, "CBO transaction response : " + cboResponse, PaymentConstants.log_transaction_info);
			if((StringUtils.hasText(cboResponse) && !cboResponse.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout"))) || !(StringUtils.hasText(cboResponse))) 
				return cboResponse;
			else if(StringUtils.hasText(cboResponse) && cboResponse.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout"))) {
				String cboRetryResponse = doCBOTransactionWithRetry(cboFinalRequest,cboWebserverURL,extrconn,paymentId);
				if(StringUtils.hasText(cboRetryResponse) && cboRetryResponse.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout"))) {
					return null;
				}
				else 
					return cboRetryResponse;
			}
		} catch (Exception e) {
			PGLogger.logTrace(paymentId+"", "Problem occurred during CBO transaction request", e, PaymentConstants.log_transaction_info);
		} finally {
			cboWebserverURL = null;
			requestLog = null;
			cboFinalRequest = null;
		}
		return cboResponse;
	}
	
	/**Jeenesh added for tokenization - starts*/
	public String performCboTokenDeregistration(String request, ExtrConn extrconn, long paymentId, LocalObject tranObject) {
		String cboResponse = "";
		String cboWebserverURL = "";
		StringBuffer requestLog = null;
		StringBuffer inRequestLog = null;
		String cboFinalRequest = null;
		try {
			cboWebserverURL = ConfigFileUtil.getProperty("WEBSERVER_CBO_URL");
			//request = "<request><action>12</action><tokenNumber>4324159260641601564360</tokenNumber>";
			inRequestLog = new StringBuffer(request);
			String respUrl = inRequestLog.substring(inRequestLog.indexOf("<responseURL>")+13, inRequestLog.indexOf("</responseURL>"));
			String errUrl = inRequestLog.substring(inRequestLog.indexOf("<errorURL>")+10, inRequestLog.indexOf("</errorURL>"));
			String id = inRequestLog.substring(inRequestLog.indexOf("<id>")+4, inRequestLog.indexOf("</id>"));
			String password = inRequestLog.substring(inRequestLog.indexOf("<password>")+10, inRequestLog.indexOf("</password>"));
			requestLog = new StringBuffer("<request><action>"+Integer.parseInt(tranObject.get(PaymentConstants.pymnt_trnsc_actn).toString())+"</action><tokenNumber>"+tranObject.getString(PaymentConstants.payment_Token_number)+"</tokenNumber>");
			requestLog.append("<id>"+id+"</id><password>"+password+"</password>");
			requestLog.append("<responseURL>"+respUrl+"</responseURL>");
			requestLog.append("<errorURL>"+errUrl+"</errorURL>");
			requestLog.append("<cbourl>" + extrconn.getUrl() + "</cbourl>");
			requestLog.append("</request>");
			cboFinalRequest = new String(requestLog);	
			cboResponse = sendMessage(cboFinalRequest, cboWebserverURL, extrconn, paymentId);
			PGLogger.logTrace(paymentId, "CBO transaction response : " + cboResponse, PaymentConstants.log_transaction_info);
			if((StringUtils.hasText(cboResponse) && !cboResponse.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout"))) || !(StringUtils.hasText(cboResponse))) 
				return cboResponse;
			else if(StringUtils.hasText(cboResponse) && cboResponse.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout"))) {
				String cboRetryResponse = doCBOTransactionWithRetry(cboFinalRequest,cboWebserverURL,extrconn,paymentId);
				if(StringUtils.hasText(cboRetryResponse) && cboRetryResponse.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout"))) {
					return null;
				}
				else 
					return cboRetryResponse;
			}
		} catch (Exception e) {
			PGLogger.logTrace(paymentId+"", "Problem occurred during CBO transaction request", e, PaymentConstants.log_transaction_info);
		} finally {
			cboWebserverURL = null;
			requestLog = null;
			cboFinalRequest = null;
		}
		return cboResponse;
	}
	
	
	private String doCBOTransactionWithRetry(String cboFinalRequest,
			String cboWebserverURL, ExtrConn extrconn, long paymentId) {
		int retryAttemps = 0;
		String cboResponse = null;
		do {
			retryAttemps++;
			cboResponse = sendMessage(cboFinalRequest, cboWebserverURL, extrconn, paymentId);
			PGLogger.logTrace(paymentId, "CBO Transaction Retry Attempts : "+ retryAttemps +" : "+ cboResponse, PaymentConstants.log_transaction_info);
			if((StringUtils.hasText(cboResponse) && !cboResponse.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout"))) || !(StringUtils.hasText(cboResponse))) {
				break;
			}
			
		} while(retryAttemps < extrconn.getRetryAttmts());
		
		return cboResponse;
	}
		
	/**Jeenesh added for Tokenization - ends
	 * @throws Exception */

	
	public String performOmanNetIVR(String request, ExtrConn extrconn, long paymentId) throws Exception {
		String omaNetRes = "";
		String omaNetWebserverURL = "";
		StringBuffer requestLog = null;
		String omanNetRequest = null;
		String omanNetIvrInitUrl =null;
		try {
			omaNetWebserverURL = ConfigFileUtil.getProperty("WEBSERVER_CBO_URL");
			omanNetIvrInitUrl = ConfigFileUtil.getProperty("OMANNET_IVR_INIT_URL");
			omaNetWebserverURL = ConfigFileUtil.getProperty("OMANNET_IVR_INIT_URL");
			request = request.replace("</request>", "");
			requestLog = new StringBuffer(request);
			requestLog.append("<cbourl>" + omanNetIvrInitUrl + "</cbourl>");
			requestLog.append("</request>");
			omanNetRequest = new String(requestLog);	
			if(omanNetRequest.contains("<cvv2>") && omanNetRequest.contains("</cvv2>"))
				requestLog.replace(requestLog.indexOf("<cvv2>")+"<cvv2>".length(), requestLog.indexOf("</cvv2>"), "****");
			if(omanNetRequest.contains("<expyear>") && omanNetRequest.contains("</expyear>"))
				requestLog.replace(requestLog.indexOf("<expyear>")+"<expyear>".length(), requestLog.indexOf("</expyear>"), "****");
			if(omanNetRequest.contains("<expmonth>") && omanNetRequest.contains("</expmonth>"))
				requestLog.replace(requestLog.indexOf("<expmonth>")+"<expmonth>".length(), requestLog.indexOf("</expmonth>"), "****");
			if(omanNetRequest.contains("<password>") && omanNetRequest.contains("</password>"))
				requestLog.replace(requestLog.indexOf("<password>")+"<password>".length(), requestLog.indexOf("</password>"), "****");
			if(omanNetRequest.contains("<card>") && omanNetRequest.contains("</card>"))
				requestLog.replace(requestLog.indexOf("<card>")+11, requestLog.indexOf("</card>")-5, "****");
			PGLogger.logTrace(paymentId, "OmanNet IVR Initilization transaction request : " + requestLog, PaymentConstants.log_transaction_info);		
			omaNetRes = sendMessage(omanNetRequest, omaNetWebserverURL, extrconn, paymentId);
			PGLogger.logTrace(paymentId, "OmanNet IVR transaction response : " + omaNetRes, PaymentConstants.log_transaction_info);
			if((StringUtils.hasText(omaNetRes) && !omaNetRes.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout")))) {
				return omaNetRes;
			} else {
				throw new Exception(paymentId+", omaNetRes is not valid omaNetRes :: "+omaNetRes);
			}
				
		} catch (Exception e) {
			PGLogger.logTrace(paymentId+"", "Problem occurred in OmanNet transaction request", e, PaymentConstants.log_transaction_info);
			throw e;
		} finally {
			omaNetRes = null;
			omaNetWebserverURL = null;
			requestLog = null;
			omanNetRequest = null;
			omanNetIvrInitUrl =null;
		}
	}
	
	public String performOmanNetIVRAuth(String request, String omNetInqReq, ExtrConn extrconn, PaymentLog paymentLog) throws Exception {
		String omaNetAuthRes = "";
		String omaNetWebserverURL = "";
		StringBuffer requestLog = null;
		String omanNetRequest = null;
		String omanNetIvrInitUrl =null;
		Long paymentId = null;
		try {
			paymentId = paymentLog.getPaymentID();
			omaNetWebserverURL = ConfigFileUtil.getProperty("WEBSERVER_CBO_URL");
			omanNetIvrInitUrl = ConfigFileUtil.getProperty("OMANNET_IVR_AUTH_URL");
			omaNetWebserverURL = ConfigFileUtil.getProperty("OMANNET_IVR_AUTH_URL");
			request = request.replace("</request>", "");
			requestLog = new StringBuffer(request);
			requestLog.append("<cbourl>" + omanNetIvrInitUrl + "</cbourl>");
			requestLog.append("</request>");
			omanNetRequest = new String(requestLog);	
			PGLogger.logTrace(paymentId, "OmanNet IVR Authorization transaction request : " + requestLog, PaymentConstants.log_transaction_info);		
			omaNetAuthRes = sendMessage(omanNetRequest, omaNetWebserverURL, extrconn, paymentId);
			omaNetAuthRes = omaNetAuthRes.replace("<result>IPAY0100045 - DENIED BY RISK</result>", "<result>CAPTURED</result>");
			omaNetAuthRes = omaNetAuthRes.replace("<result>NOT CAPTURED</result>", "<result>CAPTURED</result>");
//			omaNetAuthRes = "<result>CAPTURED</result><auth>000000</auth><ref>027880000016</ref><postdate>1004</postdate><tranid>202027812430069</tranid><trackid>1958829801</trackid><payid>302202027887581657</payid><udf1>udf111111111111111111111111111111111111111111</udf1><udf2>udf2222222222222222222222222222222222222222222</udf2><udf3>04-10-2020 19:21:00.171</udf3><udf4>432410******2264</udf4><udf5>VISA</udf5><amt>13.0</amt>";
			PGLogger.logTrace(paymentId, "OmanNet IVR Authorization transaction response : " + omaNetAuthRes, PaymentConstants.log_transaction_info);
			if((StringUtils.hasText(omaNetAuthRes) && !omaNetAuthRes.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout")))) {
				return omaNetAuthRes;
			} else {
				int attempt = 0;
				omNetInqReq = omNetInqReq.replace("</request>", "");
				requestLog.setLength(0);
				requestLog.append(omNetInqReq);
				requestLog.append("<cbourl>" + extrconn.getUrl() + "</cbourl>");
				requestLog.append("</request>");
				omNetInqReq = requestLog.toString();
				while (attempt <= extrconn.getRetryAttmts()) {
					attempt++;
					PGLogger.logTrace(paymentId, "OmanNet Host Time Out Inquiry transaction Request : " + omNetInqReq+"; attempt :: "+attempt, PaymentConstants.log_transaction_info);
					omaNetAuthRes = sendMessage(omNetInqReq, omaNetWebserverURL, extrconn, paymentId);	
					PGLogger.logTrace(paymentId, "OmanNet Host Time Out Inquiry transaction Response : " + omaNetAuthRes, PaymentConstants.log_transaction_info);
					if((StringUtils.hasText(omaNetAuthRes) && !omaNetAuthRes.equals(ResourceBundleUtil.getString("pg.transaction.cbo.connecttimeout")))) {
						if(!verifyInquiryResponse(paymentId, paymentLog.getCboPaymentID(), omaNetAuthRes)) {
							Thread.sleep(Integer.parseInt(ConfigFileUtil.getProperty("OMANNET_INQUIRY_SLEEP"))*1000);
							PGLogger.logTrace(paymentId, "OmanNet Host Time Out Inquiry transaction Response Payment Id Not Matched or verifyInquiryResponse result not success : " , PaymentConstants.log_transaction_info);
							continue;
						}
						return replaceInquiryReslut(omaNetAuthRes);
					}
				}
				throw new Exception(HostErrorCodes.READ_TIMED_OUT);
			}
				
		} catch (Exception e) {
			PGLogger.logTrace(paymentId+"", "Problem occurred in OmanNet Authorization transaction request :: "+e.getMessage(), e, PaymentConstants.log_transaction_info);
			throw e;
		} finally {
			omaNetAuthRes = null;
			omaNetWebserverURL = null;
			requestLog = null;
			omanNetRequest = null;
			omanNetIvrInitUrl =null;
		}
	}
	
	public boolean verifyInquiryResponse(Long paymentId, Long cboPaymentId, String omaNetAuthRes) {
		LocalObject responseTranObj = null;
		try {
			responseTranObj = new LocalObject();
			parseXMLIVRResponse(paymentId, omaNetAuthRes, responseTranObj);
			if(!cboPaymentId.toString().equals(responseTranObj.getString(PaymentConstants.pymnt_payid))
					|| !PaymentConstants.pymnt_result_code_success.equalsIgnoreCase(responseTranObj.getString(PaymentConstants.pymnt_result_code_tran))) {
				if(cboPaymentId.toString().equals(responseTranObj.getString(PaymentConstants.pymnt_payid)) && 
						(PaymentConstants.cboNotCaptured.equalsIgnoreCase(responseTranObj.getString(PaymentConstants.pymnt_result_code_tran))
								|| PaymentConstants.cboHostTimeOut.equalsIgnoreCase(responseTranObj.getString(PaymentConstants.pymnt_result_code_tran))
								|| PaymentConstants.cboDeniedByRisk.equalsIgnoreCase(responseTranObj.getString(PaymentConstants.pymnt_result_code_tran)))) {
					PGLogger.logTrace(paymentId, "OmanNet Host Time Out Inquiry Response Payment Id Matched and Result Not Success return true result Code :: "+responseTranObj.getString(PaymentConstants.pymnt_result_code_tran) , PaymentConstants.log_transaction_info);
					return true;
				}
				return false;
			}
			return true;
		} catch (Exception e) {
			PGLogger.logTrace(paymentId+"", "Problem occurred in OmanNet verifyInquiryResponse :: "+e.getMessage(), e, PaymentConstants.log_transaction_info);
			return false;
		}finally {
			responseTranObj = null;
		}
	}
	
	public String replaceInquiryReslut(String response) {
		if(response.indexOf("<result>"+PaymentConstants.cboSuccess+"</result>") != -1) {
			response = response.replaceAll("<result>"+PaymentConstants.cboSuccess+"</result>", "<result>"+PaymentConstants.pymnt_result_code_captured+"</result>");
		}else if(response.indexOf("<result>"+PaymentConstants.cboNotCaptured+"</result>") != -1) {
			response = response.replaceAll("<result>"+PaymentConstants.cboNotCaptured+"</result>", "<result>"+PaymentConstants.pymnt_result_code_notcaptured+"</result>");
		}else if(response.indexOf("<result>"+PaymentConstants.cboHostTimeOut+"</result>") != -1) {
			response = response.replaceAll("<result>"+PaymentConstants.cboHostTimeOut+"</result>", "<result>"+PaymentConstants.pymnt_result_code_hosttimeout+"</result>");
		}else if(response.indexOf("<result>FAILURE(") != -1 && response.indexOf(")</result>") > 0) {
			response = response.replaceAll("<result>FAILURE(", "<result>").replaceAll(")</result>", "</result>");
		}
		return response;
	}
	
	public void parseXMLIVRResponse(Long paymentId, String ivrRes, LocalObject tranObject) {
		int begin = 0;
		int end = 0;
		String beginString = "";
		String value = "";
		try {
			ivrRes = ivrRes.trim();
			if ((ivrRes == null) || (!ivrRes.startsWith("<")) || (ivrRes.length() < 0)) {
				throw new Exception("Invalid ivrRes ::"+ivrRes);
			}
			do {
				beginString = ivrRes.substring(ivrRes.indexOf("<") + 1, ivrRes.indexOf(">"));
				begin = ivrRes.indexOf("<") + beginString.length() + 2;
				end = ivrRes.indexOf("</" + beginString);
				value = ivrRes.substring(begin, end);
				end = end + beginString.length() + 3;
				ivrRes = ivrRes.substring(end, ivrRes.length());
				tranObject.put(beginString, value);
				begin = 0;
				end = 0;
				beginString = "";
				if (ivrRes.isEmpty()) {
					break;
				}
			} while (ivrRes.length() > 0); 
		} catch (Exception ex) {
			PGLogger.logError(paymentId+ "Exception in parseXMLRequest IVR Response :: "+ivrRes, ex);
		} finally {
			begin = 0;
		    end = 0;
		    beginString = null;
		    value = null;
		}

	  }
	  

	
	private String sendMessage(String request, String webAddress, ExtrConn extrConn, long paymentId) {
		String rawResponse = "";
		URLConnection urlconnection = null;
		DataOutputStream dataoutputstream = null;
		BufferedReader bufferedreader = null;
		URL url = null;
		StringBuffer buf = null;
		if(webAddress.indexOf("https") != -1)
            System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
        try {
            url = new URL(webAddress);
            urlconnection = url.openConnection();
            urlconnection.setDoInput(true);
            urlconnection.setDoOutput(true);
            urlconnection.setUseCaches(false);
            urlconnection.setConnectTimeout(extrConn.getTimeOut() * 1000);
            urlconnection.setReadTimeout(extrConn.getTimeOut() * 1000);
            if(StringUtils.hasText(extrConn.getContentType()))
            	urlconnection.setRequestProperty("Content-Type", extrConn.getContentType());
            else
            	urlconnection.setRequestProperty("Content-Type", "application/xml");
            
            
            if(request.length() > 0) {
                dataoutputstream = new DataOutputStream(urlconnection.getOutputStream());
                dataoutputstream.writeBytes(request);
                dataoutputstream.flush();
                dataoutputstream.close();
                bufferedreader = new BufferedReader(new InputStreamReader(urlconnection.getInputStream()));
               	buf = new StringBuffer();
            	do {
                    String s = bufferedreader.readLine();
                    if(s == null)
                        break;
                    buf.append(s);
                } while(true);
            	rawResponse = buf.toString();
            }
            else{
            	PGLogger.logTrace(paymentId+"", "Invalid payment request");
            }
        } catch(Exception exception) {
        	PGLogger.logTrace(paymentId+"", "Problem occurred during CBO transaction request", exception, PaymentConstants.log_transaction_info);
        } finally {
        	url = null;
        	urlconnection = null;
        }
		return rawResponse;
	}
	
	//modified for cbo non-authentication transaction
	public LocalObject parseCBOResponse(long paymentID, String response, LocalObject tranObject) {
		int begin = 0;
		int end = 0;
		String beginString = "";
		String value = "";
		try {
			PGLogger.logTrace(paymentID+"", "Parse CBO Response starts");
			if (!StringUtils.hasText(response)) {
				PGLogger.logTrace(paymentID+"", ResourceBundleUtil.getString("pg.tran.payment.problem.during.transaction") + " - " + "Empty CBO response.");
				tranObject.put("error", ResourceBundleUtil.getString("pg.tran.payment.problem.during.transaction"));
				tranObject.put("errorcode", ResourceBundleUtil.getString("pg.tran.payment.problem.during.transaction"));
				tranObject.put(PaymentConstants.CBO_TRXN_STATUS, PaymentConstants.failureTransaction);
				return tranObject;
			}
			response = response.trim();
			try {
	    	  do {
		          beginString = response.substring(response.indexOf("<") + 1, response.indexOf(">"));
		          begin = response.indexOf("<") + beginString.length() + 2;
		          end = response.indexOf("</" + beginString);
		          value = response.substring(begin, end);
		          end = end + beginString.length() + 3;
		          response = response.substring(end, response.length());
		          tranObject.put(beginString, value);
		          begin = 0;
		          end = 0;
	    	  } while (response.length() > 0);
	      } catch (Exception ex) {
	    	  tranObject.put("error", "Problem occurred during parsing CBO Response");
	    	  PGLogger.logTrace(paymentID+"",tranObject.getString("error"),ex,PaymentConstants.log_transaction_info);
	      }
	      return tranObject;
	  } catch (Exception e) {
		  PGLogger.logTrace(paymentID+"","Problem occurred during parsing CBO Response",e,PaymentConstants.log_transaction_info);
	  } finally {
	      begin = 0;
	      end = 0;
	      beginString = null;
	      value = null;
	     }
	return tranObject;
  }
}
