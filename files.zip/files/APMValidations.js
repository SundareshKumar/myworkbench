		/*
		 	Author					:	GOMATHI N
		 	Date of Creation		:	07 - 06 - 2012
		 	Date modified			:	
		 	JSP						:	APMValidation.jsp
		 	Purpose					:	To provide the all sort of validations	
		
		*/
		
		
		//	Purpose : To check whether the input satisfies all the criteria	
		/* Guidelines	:
		
			type - Can be numeric,alphabeticAndSpaceSpec,alphanumeric,24Hours(Time),Minutes(Time).
			min - Minimum Limit
			max - Maximum Limit
			chkzero - To specify whether the input value can contain zero (N - Dont check for all zeros and Y - Check for all zeros
			labelName - Id of the <Label> to display Error Message.
			mandatory - Specify whether the field is mandatory or not (M - Mandatory and NM - Non Mandatory
			
		*/	
		function checkValid(inputValue,type,min,max,chkzero,labelName,mandatory){
			
			var errorMsg = "";			
			document.getElementById(labelName).innerHTML = errorMsg;
			
			if(inputValue == '' && mandatory == 'NM' && type != 'SelectBox'){
				document.getElementById(labelName).innerHTML = errorMsg;	 
				return errorMsg;
			}
			if(inputValue == '' && mandatory == 'M' && (type != 'SelectBox' && type != 'date')) {
				errorMsg = errorMsgBlock[2];
				document.getElementById(labelName).innerHTML = errorMsg;
				return errorMsg;
			}
			if(type != 'SelectBox' && type != 'date' ) {
				if(trim(inputValue) == '') {
					errorMsg = errorMsgBlock[2];
					document.getElementById(labelName).innerHTML = errorMsg;
					return errorMsg;
				}
			}
			
			if(chkzero == 'Y') {
				errorMsg = checkAllZero(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}	
			if(type == 'validateFees') {						
				errorMsg = validateFees(inputValue,labelName);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}	
			if(type == 'validateFees3Decimals') {						
				errorMsg = validateFees3Decimals(inputValue,labelName);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}	
			
			if(type == 'validateFees2Decimals') {						
				errorMsg = validateFees2Decimals(inputValue,labelName);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
						
			if(type == 'numeric') {				
				errorMsg = checkNumeric(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'amountValue') {				
				errorMsg = checkAmount(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'numericWithHipenPlus') {				
				errorMsg = checkNumericHipenPlus(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'numericWithStar') {				
				errorMsg = checkNumericStar(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'numericspace') {	
				errorMsg = checkNumericandspace(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}		
			
		   if(type == 'alphabetic') {
				errorMsg = checkAlphabetic(inputValue);	
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}		
			}	
			if(type == 'alphabeticAndSpaceSpec') {
				errorMsg = checkAlphabeticWithSpace(inputValue);	
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}		
			}	
			if(type == 'alphabeticAndHyfenSpec') {
				errorMsg = checkAlphabeticWithHyfenSpace(inputValue);	
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}		
			}
			if(type == 'alphabeticWithSpaceAndDot') {
				errorMsg = checkAlphabeticWithSpaceDot(inputValue);	
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}		
			}	
			if(type == 'alphanumeric') {
				errorMsg = checkAlphanumeric(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			//Added by Vinodhini T - For double space validation
			if(type == 'doublespace') {
				errorMsg = checkdoublespace(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			//Ends
			if(type == 'alphanumericWithSpace') {
				errorMsg = checkAlphanumericWithSpace(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'alphanumericWithSpaceAndDot') {
				errorMsg = checkAlphanumericWithSpaceAndDot(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'address') {
				errorMsg = checkvalidAddress(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'addressNoSpace') {
				errorMsg = checkvalidAddressNoSpace(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'phoneNumber') {
				errorMsg = Is_Phone(inputValue);
				if(!errorMsg) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
				}
			}
			if(type == 'faxNumber') {
				errorMsg = Is_Fax(inputValue);
				
				if(!errorMsg) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
				}
			}
			
			//Added by Punitha A
			if(type == 'ipAddress') {
				errorMsg = fnValidateIPAddress(inputValue);
				if(!errorMsg) {
				errorMsg = fnValidateIPV6Address(inputValue);
				if(!errorMsg) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
					}
				
				}

			}
			
			if(type == 'mobileNo') {
				if(!validateMobile(inputValue)) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];
					return errorMsg;	
				}
			}
			
			if(type == 'checkValidateMenuURL') {
				if(!validateMenuURL(inputValue)) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];
					return errorMsg;	
				}
			}
			
			if(type == 'checkValidatePwdSpec') {
				if(!validatePwdSec(inputValue)) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];
					return errorMsg;	
				}
			}
			
			if(type == 'url') {
				errorMsg = ValidateWebSiteAddress(inputValue);
				if(!errorMsg) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
				}
			}
			
			if(type == 'externalConnURL') {
				errorMsg = ValidateExternalConnURL(inputValue);
				if(!errorMsg) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
				}
			}
			
			if(type == 'contentType') {
				errorMsg = validateContentType(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			
			if(type == 'validateConnURL') {
				errorMsg = ValidateConnURL(inputValue);
				if(!errorMsg) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
				}
			}
			if(type == 'validateSpace') {
				if(!validateSpace(inputValue)) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
				}
			}
			if(type == 'validateSpaceandSpecialChar') {
				if(!validateSpaceandSpecialChar(inputValue)) {
					document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
					return errorMsg;
				}
			}
			
			//End
						
			if(type == '24Hours') {
				errorMsg = checkNumeric(inputValue);
				document.getElementById(labelName).innerHTML = errorMsg;
				if(inputValue > 23) {
					errorMsg = errorMsgBlock[0];
					document.getElementById(labelName).innerHTML = errorMsg;
				}	
				if(errorMsg != '') {
					return errorMsg;
				}
			}	
			
			if(type == 'Minutes') {
				errorMsg = checkNumeric(inputValue);
				document.getElementById(labelName).innerHTML = errorMsg;
				if(inputValue > 59) {
					errorMsg = errorMsgBlock[1];	
					document.getElementById(labelName).innerHTML = errorMsg;		
				}
					
				if(errorMsg != '') {
					return errorMsg;
				}	
			}		
			if(type == 'FilePathValidation') 
			{
			errorMsg = FilePathValidation(inputValue);
			if(!errorMsg) {
					errorMsg = errorMsgBlock[14];
					document.getElementById(labelName).innerHTML = errorMsg;			
					return errorMsg;
				}
			}
			if(type == 'SelectBox') {
				errorMsg = isNotSelected(inputValue,labelName);	
				if(errorMsg != '') {
					return errorMsg;
				}				
			}
			if(type == 'Email') {
				errorMsg = checkEmail(inputValue,labelName);
				if(errorMsg != '') {
					return errorMsg;
				}					
			}
			if(type == 'WebAddress') {
				errorMsg = checkWebAddress(inputValue,labelName);	
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}		
			}
			if(type == 'keyValue') {
				errorMsg = checkKeyValue(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'validateDbUrl') {
				errorMsg = validateDbUrl(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			
			if(type == 'checkUDF') {
				errorMsg = checkUDF(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			
			if(type == 'alphanumericWithSpaceforcert') {
				errorMsg = checkAlphanumericWithSpaceForCert(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'checkAlphanumericWithCommaAndSlashAndHyphen') {
				errorMsg = checkAlphanumericWithCommaAndSlashAndHyphen(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			
			if(type == 'blockSpace') {				
				for (var i = 0;i < inputValue.length;i++) {
					 if(inputValue.charAt(i) == " "){
				  		document.getElementById(labelName).innerHTML = errorMsgBlock[16];				
						return errorMsg;
			  		 }
				}
			}
			if(type == 'date'){
				errorMsg = validateDate(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			if(type == 'numericSpaceNotStartWithZero'){
				errorMsg = validateNotStartWithZero(inputValue);
				if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}
			}
			
			if (type =='blockSpaceAndInvalidSpclChar')
			{
			 for (var i = 0;i < inputValue.length;i++) {
					 if(inputValue.charAt(i) == " "){
				  		document.getElementById(labelName).innerHTML = errorMsgBlock[16];				
						return errorMsg;
			  		 }
			  		 else if(inputValue.charAt(i) == '<' || inputValue.charAt(i) == '>'){
			  		
			  		    document.getElementById(labelName).innerHTML = errorMsgBlock[3];				
						return errorMsg;
			  		 }
				}  
			}
			
			if(type =='alphaAndSplCharswithspace')
			{
			errorMsg =checkNumericAndInvalidSpecialChar(inputValue);
			if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}	
			}
			
			if(min != "-") 	{
		 		errorMsg = checkMin(inputValue,min);
		 		if(errorMsg != '') {
					document.getElementById(labelName).innerHTML = errorMsg;				
					return errorMsg;
				}	
		 	}	
			
			if(max != "-") 	{				
				errorMsg = checkMax(inputValue,max);
				if(errorMsg != ''){
				document.getElementById(labelName).innerHTML = errorMsg;
				return errorMsg;
				}
			}			
			return errorMsg;
							
		}
		
		
//To validate Mobile No
function validateMobile(mobile){		
		var flag = false;
		if(isNaN(mobile) || mobile.indexOf(" ") != -1){
			if(! validMobileChar(mobile)){
				flag = false;
			}else if((mobile.indexOf('+') != -1) && (mobile.indexOf('+') != mobile.lastIndexOf('+'))){
				flag = false;
			}else if(mobile.indexOf('+') != 0){
				flag = false;
			}else{
				flag = true;
			}
				
		}else{
			flag = true;
		}
		return flag;
	}
	
function validMobileChar(val){
		var allowedChars = "0123456789+-";
		var a = val;

		var checkStatus = true;
		for(var i=0;i < a.length;i++){
			if(allowedChars.indexOf(a.charAt(i)) == -1){		
				checkStatus = false;
				break;				
			}
		}
		return checkStatus;
	}  

//To validate URL
/*function isURL(url) {

	if((url.indexOf("https://") != -1 ) || (url.indexOf("http://") != -1))
	{	
		if(url.indexOf(".") != -1 )
		{
			if( url.lastIndexOf(".") + 1 != url.length)
			{
				var str = url.substring(url.indexOf("//") + 2, url.indexOf("."));
				if(str.length <= 0)
				{
					return false;
				}
				else
				{
					return true
					
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}*/





		
	// To validate a IP Address
	function fnValidateIPAddress(IPvalue) {
    	//Remember, this function will validate only Class C IP.
    	//change to other IP Classes as you need
   		ipaddr = IPvalue.replace( /\s/g, "") //remove spaces for checking
    	var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/; //regex. check for digits and in
                                          //all 4 quadrants of the IP
    	if (IPvalue == "0.0.0.0"){
    		return false;
    	} else if (IPvalue == "255.255.255.255") {
    		return false;
    	} else if (re.test(IPvalue)) { 
        	//split into units with dots "."
        	var parts = IPvalue.split(".");
        	//if the first unit/quadrant of the IP is zero
        	if (parseInt(parseFloat(parts[0])) == 0) {
            	return false;
       		}
        	//if the fourth unit/quadrant of the IP is zero
        	if (parseInt(parseFloat(parts[3])) == 0) {
            	return false;
        	}
        	//if any part is greater than 255
        	for (var i=0; i<parts.length; i++) {
            	if (parseInt(parseFloat(parts[i])) > 255){
                return false;
            	}
        	}
        return true;
      } else {
        return false;
      }
}


     //To validate a IPV6 address
      
      function fnValidateIPV6Address(IPvalue) {
			var regex=/^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/;
       
  			 if (IPvalue.match(regex)) {
 					return true;
   				} else {
					return false;
   				}
			}
			
		//To check whether the select box option is selected or not.
		function isNotSelected(value,labelName) {
			var errorMsg = "";
			document.getElementById(labelName).innerHTML = errorMsg;
				if(value == '-1'){
					errorMsg = errorMsgBlock[10];
					document.getElementById(labelName).innerHTML = errorMsg;
					return errorMsg;
				}else if(value == 'select'){
					errorMsg = errorMsgBlock[10];
					document.getElementById(labelName).innerHTML = errorMsg;
					return errorMsg;
				}
			return errorMsg;
		}
		
		
		function validateCheckbox(chkboxval,labelName){
			var flag = false;
			var errorMsg = "";
			if(labelName != "-")
				document.getElementById(labelName).innerHTML = errorMsg;
			
			if(!chkboxval.length){
				if(chkboxval.checked){
					flag = true;					
				}
			} else {
				var cnt = 0;
				for(var i=0;i<chkboxval.length;i++)	{
					if(chkboxval[i].checked){
						flag = true;
					}
				}
			}
			if(!flag) { 
				errorMsg = errorMsgBlock[10];
				if(labelName != "-")
					document.getElementById(labelName).innerHTML = errorMsg;
			}
			return flag;
		}
		
		
		
	function validateFees(inputValue,labelName) {
		var errorMsg = "";  
		var iChars = "0123456789.";
		var regex = /^[0-9]\d*(?:\.\d{0,2})?$/;  
		document.getElementById(labelName).innerHTML = errorMsg;
		
		for (var i = 0; i < inputValue.length; i++) {
			
			if (iChars.indexOf(inputValue.charAt(i)) == -1) {
				errorMsg = errorMsgBlock[5];
		  		document.getElementById(labelName).innerHTML = errorMsg;
				return errorMsg;
		  	}		  				
		 }
		
		var valid = regex.test(inputValue);
		if(!valid){
			errorMsg = errorMsgBlock[11];
			document.getElementById(labelName).innerHTML = errorMsg;
			return errorMsg;
		}
		
		
	  	return errorMsg;
	}
		
		
	function validateFees3Decimals(inputValue,labelName) {
		var errorMsg = "";  
		var iChars = "0123456789.";
		var regex = /^[0-9]\d*(?:\.\d{3}$)?$/;  
		document.getElementById(labelName).innerHTML = errorMsg;
		
		for (var i = 0; i < inputValue.length; i++) {
			
			if (iChars.indexOf(inputValue.charAt(i)) == -1) {
				errorMsg = errorMsgBlock[5];
		  		document.getElementById(labelName).innerHTML = errorMsg;
				return errorMsg;
		  	}		  				
		 }
		
		if(inputValue > 9999999.999) {		
			errorMsg = errorMsgBlock[17];
			document.getElementById(labelName).innerHTML = errorMsg;
			return errorMsg;
		}
		
		if (inputValue == "" || inputValue.indexOf(".") == -1){
			errorMsg = errorMsgBlock[23];
	  		document.getElementById(labelName).innerHTML = errorMsg;
			return errorMsg;
	  	}
		
		var valid = regex.test(inputValue);
		if(!valid){
			errorMsg = errorMsgBlock[11];
			document.getElementById(labelName).innerHTML = errorMsg;
			return errorMsg;
		}
		
		
	  	return errorMsg;
	}
	
	function validateFees2Decimals(inputValue,labelName) {
		var errorMsg = "";  
		var iChars = "0123456789.";
		var regex = /^[0-9]\d*(?:\.\d{0,2})?$/;  
		document.getElementById(labelName).innerHTML = errorMsg;
		
		for (var i = 0; i < inputValue.length; i++) {
			
			if (iChars.indexOf(inputValue.charAt(i)) == -1) {
				errorMsg = errorMsgBlock[5];
		  		document.getElementById(labelName).innerHTML = errorMsg;
				return errorMsg;
		  	}		  				
		 }
		
		var valid = regex.test(inputValue);
		if(!valid){
			errorMsg = errorMsgBlock[11];
			document.getElementById(labelName).innerHTML = errorMsg;
			return errorMsg;
		}
		if(inputValue > 9999999.999) {		
			errorMsg = errorMsgBlock[17];
			document.getElementById(labelName).innerHTML = errorMsg;
			return errorMsg;
		}
		
	  	return errorMsg;
	}
				
		/*	Purpose : To check whether the value passed is Numeric or Not, 
			Result	: If it is not numeric return error message.
		*/
		
		function checkNumeric(inputValue) {
			var iChars = "0123456789";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				 if(inputValue.charAt(i) == " "){
			  		errorMsg = errorMsgBlock[16];
			  		return errorMsg;
		  		}else if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[5];
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}
		
		function checkAmount(inputValue) {
			var iChars = "0123456789.";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				 if(inputValue.charAt(i) == " "){
			  		errorMsg = errorMsgBlock[16];
			  		return errorMsg;
		  		}else if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[5];
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}
		
		function checkNumericHipenPlus(inputValue) {
			var iChars = "0123456789+-";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				 if(inputValue.charAt(i) == " "){
			  		errorMsg = errorMsgBlock[16];
			  		return errorMsg;
		  		}else if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[5];
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}

		function checkNumericStar(inputValue) {
			var iChars = "0123456789*";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				 if(inputValue.charAt(i) == " "){
			  		errorMsg = errorMsgBlock[16];
			  		return errorMsg;
		  		}else if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = 'Should be numeric with *';
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}

		
		/*	Purpose : To check whether the value passed is Numeric with comma or Not, 
			Result	: If it is not numeric return error message.
		*/
		
		function checkNumericWithComma(inputValue) {
			var iChars = "0123456789,";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				 if(inputValue.charAt(i) == " "){
			  		errorMsg = errorMsgBlock[16];
			  		return errorMsg;
		  		}else if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[5];
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}
		
			/*	Purpose : To check whether the value passed is Numeric or Not, 
			Result	: If it is not numeric return error message.
		*/
		
		function checkNumericandspace(inputValue) {
			var iChars = "0123456789";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
	        
	        if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
	        
			for (var i = 0;i < len;i++) {
				 if(inputValue.charAt(i) == " "){
			  		errorMsg = errorMsgBlock[16];
			  		return errorMsg;
		  		 }else if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[5];
		  		} 	  	
		  	}
		  	
		  return errorMsg;
	  
		}
		
		/*	Purpose : To check whether the value passed is Alphanumeric or Not, 
			Result	: Returns error message if it is not Alphanumeric.
		*/
		
		function checkAlphanumeric(inputValue) {
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			var space = inputValue.indexOf(" ");
       	 	if (space != -1)
        	{
        		errorMsg = errorMsgBlock[16];
		  		return errorMsg;
        	}
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[7];
		  		}
		  	}
		  	
		  return errorMsg;
	  
		}
		
		
			
		/*	Purpose : To check whether the value passed is Alphanumeric or Not, 
			Result	: Returns error message if it is not Alphanumeric.
		*/
		
		function checkAlphanumericWithSpace(inputValue) {
		
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[7];
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[18];
		  		} 	  	
		  	}
		  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		  	 var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  return errorMsg;
	  
		}
		
		/*	Purpose : To check whether the value passed is Alphanumeric or Not, allows space and dot 
			Result	: Returns error message if it is not Alphanumeric.
		*/
		
		function checkAlphanumericWithSpaceAndDot(inputValue) {
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ. ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[7];
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[18];
		  		} 	  	
		  	}
		  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		  	 var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  return errorMsg;
	  
		}
		function checkAlphanumericWithCommaAndSlashAndHyphen(inputValue) {
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ,/-";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[7];
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[20];
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}
		function checkvalidAddress(inputValue) {
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ#/ ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[18];
		  		} 	  	
		  	}
		  	
		  return errorMsg;
	  
		}
		
			function checkvalidAddressNoSpace(inputValue) {
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ#/ ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			
			if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
			
			
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[18];
		  		} 	  	
		  	}
		  	
		  return errorMsg;
	  
		}
		
		/*	Purpose : To check whether the value passed exceeds maximum limit given.
			Result	: Returns error message if it exceeds.
		*/			
		function checkMax(inputValue,max){		
			var flag = true;			
			var errorMsg = "";	
			
			if(inputValue.length > max) {
				flag = false;	
				errorMsg = errorMsgBlock[12]+" "+max;			
			}				
				
			return errorMsg;			
		}
		
		/*	Purpose : To check whether the value passed is lesser than minimum limit given. 
			Result	: Returns error message if it is lesser than specified limit.
		*/
		
		function checkMin(inputValue,min){
			var flag = true;
			var errorMsg = "";	
					
			if(inputValue.length < min){
				flag = false;	
				errorMsg = errorMsgBlock[13]+" "+min;	
			}			
			return errorMsg;
			
		}
		
		/*	Purpose : To check whether the input contains all zeros.
			Result	: Returns error message if it contains all zero
		*/
		
		function checkAllZero(inputValue){
			var flag = true;
			var errorMsg = "";	
			
			if(inputValue.valueOf()== 0){
				flag = false;	
				errorMsg = errorMsgBlock[4];
			}			
			return errorMsg;
			
		}
		
		/*To check whether the input value is alphabetic and it should not contain few spaces in the middle of the text. 
		There should not be any spaces at both ends*/
		
		function checkAlphabetic(inputValue) {
			var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
			var len = inputValue.length;		
			var flag = true;
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
	         var space = inputValue.indexOf(" ");
       	 	if (space != -1)
        	{
        		errorMsg = errorMsgBlock[16];
		  		return errorMsg;
        	}
	       	for (var i = 0;i < len;i++) {
			
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[6];
		  		}		  		  	
		  	}
		  return errorMsg;
	  
		}			
		
		/*To check whether the input value is alphabetic and it can contain few spaces in the middle of the text. 
		There should not be any spaces at both ends*/
		
		function checkAlphabeticWithSpace(inputValue) {
			var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[19];
		  		} 	  	
		  	}
		  	
		  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  		
		  return errorMsg;
	  
		}
		function checkAlphabeticWithHyfenSpace(inputValue) {
			var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[19];
		  		} 	  	
		  	}
		  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  return errorMsg;
		}
		
		
		function checkNumericAndInvalidSpecialChar(inputValue){
		
			var iChars = "0123456789\\\|&<>";
			var len = inputValue.length;		
			var errorMsg = "";		
			
			if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
	        
			for (var i = 0;i < len;i++) {
			
				 if (iChars.indexOf(inputValue.charAt(i)) != -1){
				 errorMsg = errorMsgBlock[22];
		  		} 	  	
		  	}
		  	
		  return errorMsg;
	  
		}
		/*To check whether the input value is alphabetic and it can contain dot and few spaces in the middle of the text. 
		There should not be any spaces at both ends*/
		
		function checkAlphabeticWithSpaceDot(inputValue) {
			var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ. ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[7];
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[19];
		  		} 	  	
		  	}
		  	
		  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  		
		  return errorMsg;
	  
		}	
	
		function ltrim(str) { 
			for(var k = 0; k < str.length && isWhitespace(str.charAt(k)); k++);
			return str.substring(k, str.length);
		}
		function rtrim(str) {
			for(var j=str.length-1; j>=0 && isWhitespace(str.charAt(j)) ; j--) ;
			return str.substring(0,j+1);
		}
		function trim(str) {
			return ltrim(rtrim(str));
		}
		function isWhitespace(charToCheck) {
			var whitespaceChars = " \t\n\r\f";
			return (whitespaceChars.indexOf(charToCheck) != -1);
		}

		
	function checkWebAddress(url,labelName) {
	
		var errorMsg = "";	
		if(labelName != "-")
	    	document.getElementById(labelName).innerHTML = errorMsg;	
	    
	    	
	    if((url.indexOf("https://") != -1 ) || (url.indexOf("http://") != -1)){ 
			var companyUrl = url; 
		    var RegExp = /^(([\w]+:)?\/\/)?(([\d\w]|%[a-fA-f\d]{2,2})+(:([\d\w]|%[a-fA-f\d]{2,2})+)?@)?([\d\w][-\d\w]{0,253}[\d\w]\.)+[\w]{2,4}(:[\d]+)?(\/([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)*(\?(&?([-+_~.\d\w]|%[a-fA-f\d]{2,2})=?)*)?(#([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)?$/; 

			
		    if(RegExp.test(companyUrl)){ 
		    	 if(url.indexOf("///") != -1) {		
					if(labelName != "-")
					    document.getElementById(labelName).innerHTML = errorMsgBlock[3];	    	
					return errorMsgBlock[3];			
		    	 } else {
			    	if(labelName != "-")
			    		document.getElementById(labelName).innerHTML = errorMsg;	    	
			        return errorMsg;
			     }
		    } else { 
		   		 if(labelName != "-")
		    		document.getElementById(labelName).innerHTML = errorMsgBlock[3];
		        return errorMsgBlock[3];
		    } 	
		} else {
			if(labelName != "-")
				document.getElementById(labelName).innerHTML = errorMsgBlock[3];
			return errorMsgBlock[3];
		}
	} 
		
	function checkEmail(inputValue,labelName) {

		var flag = true;
		var errorMsg = "";	
		document.getElementById(labelName).innerHTML = errorMsg;	
	   	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		if(reg.test(inputValue)) {	         
	       
	       var parts = inputValue.split(".");
	       for (i=0;i<parts.length;i++)
	       {
	        	if(parts[i] == ""){
	        		flag = false;
	        		break;
	        	}
	        }	        
	    } else {
	    	flag = false;
	    }
	    if(!flag) {
	    	document.getElementById(labelName).innerHTML = errorMsgBlock[3];	
	    	errorMsg = errorMsgBlock[3];
	    }	
	    return errorMsg;
	}	
		
	function Is_Phone(inputValue) {
	   var flag = true;	 
       if(inputValue.length < 10)
		{
		    flag = false;
		}
		for(var i=0;i<inputValue.length;i++)
			{
				if((inputValue.substring(i,i+1) < "0") || (inputValue.substring(i,i+1) > "9"))
					{
						if(!(inputValue.substring(i,i+1)=="-") && !(inputValue.substring(i,i+1)=="+"))
							{
								 flag = false;
							}
					}
			}
			
		return flag;
	}
	
	function Is_Fax(inputValue) {
	
	   var flag = true;	 
       //if(inputValue.length < 4)
		//{
		   // flag = false;
		//}
		for(var i=0;i<inputValue.length;i++)
			{
				if((inputValue.substring(i,i+1) < "0") || (inputValue.substring(i,i+1) > "9"))
					{
						if(!(inputValue.substring(i,i+1)=="-") && !(inputValue.substring(i,i+1)=="+"))
							{
								 flag = false;
							}
					}
			}
			
		return flag;
	}
		
		//The following set of Code has been copied from general.js
		
		
		function checkFees(inputValue) {
			var iChars = "0123456789.";
			var regex = /^[0-9]\d*(?:\.\d{0,2})?$/;  
			
			for (var i = 0; i < inputValue.length; i++) {
				
				if (iChars.indexOf(inputValue.charAt(i)) == -1) {
					return true;
			  	}		  				
			 }
			
			var valid = regex.test(inputValue);
			if(!valid){				
				return true;
			}
		
		
	  		return false;
		}
		
		function checkFees3Decimals(inputValue) {
			if (inputValue == "" || inputValue.indexOf(".") == -1)
				return true;
			var iChars = "0123456789.";
			var regex = /^[0-9]\d*(?:\.\d{3}$)?$/;
			
			for (var i = 0; i < inputValue.length; i++) {
				
				if (iChars.indexOf(inputValue.charAt(i)) == -1) {
					return true;
			  	}		  				
			 }
			
			var valid = regex.test(inputValue);
			if(!valid){				
				return true;
			}
		
		
	  		return false;
		}
		
	
	function validateZeroNumber(value)
	{
	
	 	var flag = false;
		var len=value.length;
		var i=0;
	    for (i=0;i<len;i++)
	    {
	   
	    	var c = value.charAt(i);
	    	if(c!=0)
	        {	  
	    		flag = true;        
	        	break;
	    	} 
	    }
	    return flag;
	    
	}
	
	function validateZeroForMobileNumber(value)
	{
	
	 	var flag = false;
		var len=value.length;
		var i=0;
		var iChars="+-";
	    for (i=0;i<len;i++)
	    {
	   
	    	var c = value.charAt(i);
	    	if(c!=0)
	        {	  
	        	if(iChars.indexOf(c) == -1){
	        	flag = true;        
	        	break;
	        	}   
	    		
	    	} 
	    }
	    return flag;
	    
	}
		// to validate textbox value for String
	function validateStrOnly(value,errmsg)
	{
		var msg = "";
		var flag = true;
		value = myTrim(value);
		if(value.length==0)
		{
			return errmsg;
		}	
		if(value == 'select')
			return errmsg;
		else if(value == '-1')
			return errmsg;
		else 	
			return msg;
		
	}
	
	function validateSplCharAndSpace(value)
	{
	 	var flag = true;
		var msg="";
		var len=value.length;
		var i=0;
	    for (i=0;i<len;i++)
	    {
	     var c = value.charAt(i);
	      if(c=="!")
	        {
	    	flag = false;
	        break;
	    	}
	    	if(c=="@")
	        {
	    	flag = false;
	    	 break;
	    	}
	    	if(c=="$")
	        {
	    	flag = false;
	    	 break;
	    	}
	    	if(c=="&")
	        {
	    	flag = false;
	    	 break;
	    	}
	    	if(c=="#")
	        {
	    	flag = false;
	         break;
	    	}
	    	if(c=="%")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c=="*")
	        {
	   		flag = false;
		    break;
	    	}
	    	if(c=="^")
	        {
	    	flag = false;
	    	 break;
	    	}
	    	if(c=="(")
	        {
	    	flag = false;
	    	 break;
	    	}
	    	if(c==")")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c=="-")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c=="_")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c=="+")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c=="=")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c=="}")
	        {
	    	flag = false;
	     	  break;
	    	}
	    	if(c=="{")
	        {
	    	flag = false;
	        break;
	    	}
	    	if(c=="[")
	        {
	    	flag = false;
	         break;
	    	}
	    	if(c=="]")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c==" |")
	        {
	    	flag = false;
	     	 break;
	    	}
	    	if(c=='"')
	        {
	    	flag = false;
	        break;
	    	}
	    	if(c==";")
	        {
	    	flag = false;
	      	break;
	    	}
	    	if(c==":")
	        {
	    	flag = false;
	      	 break;
	    	}   
	    	if(c=="?")
	        {
	    	flag = false;
	        break;
	    	}
	 		if(c=="/")
	        {
	    	flag = false;
	      	 break;
	    	}
	    	if(c==".")
	        {
	    	flag = false;
	      	break;
	    	}
	    	if(c=="> ")
	        {
	    	flag = false;
	     	break;
	    	}
	    	if(c=="<")
	        {
	    	flag = false;
	     	 break;
	    	}
	    	if(c==",")
	        {
	    	flag = false;
	      	break;
	    	}
	    	if(c==" ")
		    {
			 	flag = false;
		    	break;
		    }  
	    }
	     return flag
	}
	function validateSplChar(value)
	{
	 	var flag = true;
		var len=value.length;
		var i=0;
	    for (i=0;i<len;i++)
	    {
	     var c = value.charAt(i);
	      if(c=="!")
	        {
	     
	    	flag = false;
	        
	        break;
	    	}
	    	if(c=="@")
	        {
	    	flag = false;
	        
	    	 break;
	    	}
	    	if(c=="$")
	        {
	    	flag = false;
	        
	    	 break;
	    	}
	    	if(c=="&")
	        {
	    	flag = false;
	        
	    	 break;
	    	}
	    	if(c=="#")
	        {
	    	flag = false;
	        
	         break;
	    	}
	    	if(c=="%")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="*")
	        {
	   		flag = false;
	             
		    break;
	    	}
	    	if(c=="^")
	        {
	    	flag = false;
	     	 
	    	 break;
	    	}
	    	if(c=="(")
	        {
	    	flag = false;
	     	 
	    	 break;
	    	}
	    	if(c==")")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="-")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="_")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="+")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="=")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="}")
	        {
	    	flag = false;
	     	 
	     	  break;
	    	}
	    	if(c=="{")
	        {
	    	flag = false;
	       
	        break;
	    	}
	    	if(c=="[")
	        {
	    	flag = false;
	        
	         break;
	    	}
	    	if(c=="]")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	
	    	if(c==" |")
	        {
	    	flag = false;
	     	  
	     	 break;
	    	}
	    	if(c=='"')
	        {
	    	flag = false;
	       
	        break;
	    	}
	    	if(c==";")
	        {
	    	flag = false;
	      	 
	      	break;
	    	}
	    	if(c==":")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}   
	    	if(c=="?")
	        {
	    	flag = false;
	     	 
	        break;
	    	}
	 		if(c=="/")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c==".")
	        {
	    	flag = false;
	      	 
	      	break;
	    	}
	    	if(c=="> ")
	        {
	    	flag = false;
	     	
	     	break;
	    	}
	    	if(c=="<")
	        {
	    	flag = false;
	     	 
	     	 break;
	    	}
	    	if(c==",")
	        {
	    	flag = false;
	      	
	      	break;
	    	} 
	    }
	     return flag
	}
	
	function validateSplCharWithSingleHyphenAndPlus(value)
	{
		var noOfhyphen = 0;
		var noOfPlus = 0;
	 	var flag = true;
		var len=value.length;
		var i=0;
	    for (i=0;i<len;i++)
	    {
	     var c = value.charAt(i);
	     	if(c=="-")
	        {
	    	noOfhyphen++;
	    	}
	    	if(c=="+")
	        {
	    	noOfPlus++;
	    	}
	      	if(c=="!")
	        {
	     
	    	flag = false;
	        
	        break;
	    	}
	    	if(c=="@")
	        {
	    	flag = false;
	        
	    	 break;
	    	}
	    	if(c=="$")
	        {
	    	flag = false;
	        
	    	 break;
	    	}
	    	if(c=="&")
	        {
	    	flag = false;
	        
	    	 break;
	    	}
	    	if(c=="#")
	        {
	    	flag = false;
	        
	         break;
	    	}
	    	if(c=="%")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="*")
	        {
	   		flag = false;
	             
		    break;
	    	}
	    	if(c=="^")
	        {
	    	flag = false;
	     	 
	    	 break;
	    	}
	    	if(c=="(")
	        {
	    	flag = false;
	     	 
	    	 break;
	    	}
	    	if(c==")")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="_")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="=")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c=="}")
	        {
	    	flag = false;
	     	 
	     	  break;
	    	}
	    	if(c=="{")
	        {
	    	flag = false;
	       
	        break;
	    	}
	    	if(c=="[")
	        {
	    	flag = false;
	        
	         break;
	    	}
	    	if(c=="]")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	
	    	if(c==" |")
	        {
	    	flag = false;
	     	  
	     	 break;
	    	}
	    	if(c=='"')
	        {
	    	flag = false;
	       
	        break;
	    	}
	    	if(c==";")
	        {
	    	flag = false;
	      	 
	      	break;
	    	}
	    	if(c==":")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}   
	    	if(c=="?")
	        {
	    	flag = false;
	     	 
	        break;
	    	}
	 		if(c=="/")
	        {
	    	flag = false;
	      	
	      	 break;
	    	}
	    	if(c==".")
	        {
	    	flag = false;
	      	 
	      	break;
	    	}
	    	if(c=="> ")
	        {
	    	flag = false;
	     	
	     	break;
	    	}
	    	if(c=="<")
	        {
	    	flag = false;
	     	 
	     	 break;
	    	}
	    	if(c==",")
	        {
	    	flag = false;
	      	
	      	break;
	    	} 
	    }
	    
	    if(noOfhyphen > 1 || noOfPlus > 1){
	    	flag = false;
	    }
	    
	     return flag
	}
	
	// to validate textbox value for special character
	function validateMrchStrSpcl(value)
	{		
		var msg = "";
		var flag = true;
		value = myTrim(value);
		if(value.length==0)
		{
			flag = false;
		}
		else
		{
			flag = validateSplChar(value);
			if(!flag)
			{
				flag = false
			}
		}
		return flag;
	}
	function myTrim(text)
	{
	   	var newStr="";
		for(var i=0;i<text.length;i++)
		{
			  if(text.charCodeAt(i)!=32)
			  {
			     newStr+=text.charAt(i);
			  }
		  }
		  return newStr;
	}

	// to validate a number
	function validateNumber(value,errmsg)
	{
		var msg = "";
		var flag = true;
		if (isNaN(value)) 
        {
             flag = false;
        }
        if(!validateSplCharAndSpace(value))
        {
             flag = false;
        }
        if (value <=0) 
        {
            flag = false;
        }
		if(flag)
		{
			return msg;
		}
		else
		{
			return errmsg;
		}
	}
	// to validate a alphanumeric
	function validateAlphaNumeric(value,errmsg)
	{
		var msg = "";
		var flag = true;
		var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var len = value.length;		
		var flag = true;	
		var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(value.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[7];
		  		} 	  	
		  	}
		
		if(flag)
		{
			return msg;
		}
		else
		{
			return errmsg;
		}
	}
	
	function validateAlphaNumericwithspace(value,errmsg)
	{
		var msg = "";
		var flag = true;
		var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var len = value.length;		
		var flag = true;	
		var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(value.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[7];
		  		} 	  	
		  	}
		 var twoSpace = value.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		flag = false;
        	}
    if(flag)
		{
			return msg;
		}
		else
		{
			return errmsg;
		}
	}
	
	
	// to validate a number
	function validateNumberwithZero(value,errmsg)
	{
		var msg = "";
		var flag = true;
		// Added by sunil to check empty value
		if(value.length==0)
		{
			
			flag = false;
		}		
		if (isNaN(value)) 
        {
             flag = false;
        }
        if(!validateSplCharAndSpace(value))
        {
             flag = false;
        }
        if(flag)
		{
			return msg;
		}
		else
		{
			return errmsg;
		}
	
	
	}
	
	function validateNumberwithSingleHyphenPlus(value,errmsg)
	{
		var msg = "";
		var flag = true;
        if(!validateSplCharWithSingleHyphenAndPlus(value))
        {
             flag = false;
        }
        if (value <=0) 
        {
            flag = false;
        }
		if(flag)
		{
			return msg;
		}
		else
		{
			return errmsg;
		}
	}
	
	function validateEmailId(email) {
		var flag = true;
	   	var reg=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;
	   	  	if(reg.test(email)) {	      
	       
	       var parts = email.split(".");
	       for (i=0;i<parts.length;i++)
	       {
	        	if(parts[i] == ""){
	        		flag = false;
	        		break;
	        	}
	        }	        
	    } else {
	    	flag = false;
	    }
	    return flag;
	}	
	
	function isAlphabetic(val) {   
		var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		
		if(val.length == 0) {
			return false;
		}
	
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) == -1) {
	  			return false;
	  		}
	  	}
	  	return true;
	}

	// to validate textbox value for special character & space 
	function validateStrSpclSpace(value,errmsg)
	{
		var msg = "";
		var flag = true;
		if(value.length==0)
		{
			return errmsg;
		}
		else
		{
			flag = validateSplCharAndSpace(value);
			if(flag)
			{
				return msg;
			}
			else
			{
				return errmsg;
			}
		}
	}
	
	
	//From Validation.js
	
	
	//To validate a Name or Desc fully given as special character
	function validateSplChars(value)
	{
	 	var flag = false;
		var len=value.length;
		var i=0;
		var iChars = "_&";
	    for (i=0;i<len;i++)
	    {
	    	if (iChars.indexOf(value.charAt(i)) == -1) {
	    		flag = true;
	    	}    	   	 
	    }    
	    return flag;    
	}
	
	function validateMenuURL(val) {
		var flag = true;
		if(val.length == 0) {
			flag = false;
		}
		if(val != "#") {
			var iChars = "#~`!@$%^*()+-[]\\\';,/{}|\:<> ";
			for (var i = 0; i < val.length; i++) {
				if (iChars.indexOf(val.charAt(i)) != -1) {
		  			flag = false;
		  		}
		  		if ('"'.indexOf(val.charAt(i)) != -1) {
		  			flag = false;
		  		}
		  	}
		  	
	  	}
	  	return flag;  	
	}
	
	function validatePwdSec(val) {   
		var iChars = "._!@#$";
		if(val.length == 0) {
			return false;
		}
	
		if(val<=0){
		return false;
		}
		
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) == -1) {
	  			return false;
	  		}
	  	}
	  	return true;
	}
	
	
	function validatePwdSpecialChar(val) {
		var flag = true;
		if(val.length == 0) {
			flag = false;
		}
	
		var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ^:&()<> ";
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) != -1) {
	  			flag = false;
	  		}
	  	}
	  	return flag;  	
	}
	
	function isNumeric(val) {   
		var iChars = "0123456789";
		
		if(val.length == 0) {
			return false;
		}
	
		if(val<=0){
		return false;
		}
		
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) == -1) {
	  			return false;
	  		}
	  	}
	  	return true;
	}
	function isNumericOnly(val) {   
		var iChars = "0123456789";
		
		if(val.length == 0) {
			return false;
		}
	
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) == -1) {
	  			return false;
	  		}
	  	}
	  	return true;
	}
	
	
	function validateContentType(val) {
		var errorMsg = '';
		var len = val.length;
		var iChars = "~`!@#$%^*()+[]\\\',{}|\"<>?&";
		
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) != -1) {
	  			errorMsg = errorMsgBlock[3];
	  			return errorMsg;
	  		}
	  	}
	  	
	  		if(val.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(val.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		  	 var twoSpace = val.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
	  	
	  	return errorMsg;  	
	}
	
	function noSplCharsName(val) {
		var flag = true;
		if(val.length == 0) {
			flag = false;
		}
	
		var iChars = "~`!@#$%^*()+=-[]\\\';,./{}|\":<>?";
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) != -1) {
	  			flag = false;
	  		}
	  	}
	  	return flag;  	
	}

	function noSplCharsNameExceptDot(val) {
		var flag = true;
		if(val.length == 0) {
			flag = false;
		}
	
		var iChars = "~`!@#$%^*()+=-[]\\\';,/{}|\":<>?";
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) != -1) {
	  			flag = false;
	  		}
	  	}
	  	return flag;  	
	}
	
	 function isAlphabeticAllowSpace(val) 
    {   
		var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
		
		if(val.length == 0) {
			return false;
		}
	
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) == -1)
			{
	  			return false;
	  		}
	  	}
	  	return true;
	}
	
	function isAlphabeticAllowSpaceAndDot(val) 
    {   
		var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ. ";
		
		if(val.length == 0) {
			return false;
		}
	
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) == -1)
			{
	  			return false;
	  		}
	  	}
	  	return true;
	}
	
		//to add CSRFToken value to the form
		function getFrmName(val)
		{
			focusOnFirstElement();
			if(val!=null || val !='')
				document.forms[0].CSRFToken.value=val;
			return true;
		}	
		function focusOnFirstElement()
		{
			var forms = document.forms || [];
	        for(var i = 0; i < forms.length; i++){
	            for(var j = 0; j < forms[i].length; j++){
	                if(!forms[i][j].readonly != undefined && forms[i][j].type != "hidden" && forms[i][j].disabled != true && forms[i][j].style.display != 'none'){
	                    forms[i][j].focus();
	                    return;
	                }
	            }
	        }
		}
	
	function validateSpace(value)
	{
	 	var flag = true;
		var len=value.length;
		if(value == "")
			return false;
			
 		for (var i=0;i<len;i++)
    	{
		     var c = value.charAt(i);
			 if(c==" ")
		     {
		    	flag = false;
				break;
		   	} 
    	}
    	return flag;
	}
	function validateSpaceandSpecialChar(value)
	{
	 	var flag = true;
		var len=value.length;
		if(value == "")
			return false;
			
 		for (var i=0;i<len;i++)
    	{
		     var c = value.charAt(i);
			 if(c==" ")
		     {
		    	flag = false;
				break;
		   	} else  if(c=="&")
		     {
		        alert("Special character '&' is not allowed");
		    	flag = false;
				break;
		   	}  else  if(c=="|")
		     {
		    	alert("Special character '|' is not allowed");
		    	flag = false;
				break;
		   	} 
    	}
    	
      return flag;
	}
	function validateSplSpaceStartEnd(strValue)
    {
    	if (!noSplCharsName(strValue))
    	{
    		return false;
    	}
    	
    	if (!isAlphabeticAllowSpace(trim(strValue)))
    	{
    		return false;
    	}
    	var startingChar = strValue.charAt(0);
    	if (!validateSpace(startingChar))
    	{
    		return false;
        }
        var endingChar = strValue.charAt(strValue.length-1);
        if (!validateSpace(endingChar))
    	{
    		return false;
        }
        var twoSpace = strValue.indexOf("  ");
        if (twoSpace != -1)
        {
        	return false;
        }
        return true;
    }
    
    function getFocus(col){
		document.getElementById(col).style.background="#E1E9D4";
		document.getElementById(col).style.border.color="black";
	}
	function lostFocus(col)
	{
		document.getElementById(col).style.background="white";
	}
	
	function initRequest()
	{
	
		if (window.ActiveXObject) 
		{ 
	   		req = new ActiveXObject("Microsoft.XMLHTTP");
		}
	    else if(window.XMLHttpRequest)
	   	{
	    	req = new XMLHttpRequest();
	    }
	    return req;
	}


/**
	Validation for Key Value - Sunil 13/08/2012
*/
	function checkKeyValue(inputValue) {
			var iChars = "0123456789abcdefABCDEF";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[3];
		  		} 
		  	}
		  			  	
		  			  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		  	 var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  	
		  return errorMsg;
	  }


	// to validate textbox value for special character
	function validateStrSpcl(value,errmsg)
	{
		var msg = "";
		var flag = true;
		value = myTrim(value);
		if(value.length==0)
		{
			return errmsg;
		}
		else
		{
			flag = validateSplChar(value);
			if(flag)
			{
				return msg;
			}
			else
			{
				return errmsg;
			}
		}
	}
	
function validateCheckbox(chkboxval)
	{
		var flag = false;
		if(!chkboxval.length)
		{
			if(chkboxval.checked)
			{
				flag = true;
			}
		}
		else
		{
			var cnt = 0;
			for(var i=0;i<chkboxval.length;i++)
			{
				if(chkboxval[i].checked)
				{
					flag = true;
				}
			}
		}
		return flag;
	}
	
function isAlphaNumeric(val) {   
	var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	
	if(val.length == 0) {
		return false;
	}

	for (var i = 0; i < val.length; i++) {
		if (iChars.indexOf(val.charAt(i)) == -1) {
  			return false;
  		}
  	}
  	return true;
}
		
		
//File path validation
	
	function FilePathValidation(path)
	{
		var flag = true;
		var errormsg = "";
		if(navigator.platform == "Linux") {
			if(path.charAt(0) != "/")
			{
				flag = false;
			}
			if(path.charAt(0) == "/" && path.charAt(1) == "/")
			{
				flag = false;
			} 
		} else {
			if((path.charAt(0) != "" && path.charAt(0) != "\\" && path.charAt(1) != "\\") && (path.charAt(0) != "/" && path.charAt(1) != "/"))
			{
				if(!path.charAt(0).match(/^[a-zA-z]/))  
				{
					flag = false;
				}			 
				if(path.charAt(0) != "" && (path.charAt(1) == "" ||!path.charAt(1).match(/^[:]/) || !path.charAt(2).match(/^[\/\\]/)))
				{
					flag = false;
				} 	
			}
		}
		
		return flag;
		}
		function FilePathValidationLinuxWindow(path)
	{
			//alert("entered file path ");
		var flag = true;
		var ichar="!~@#$%^&*()_-+={}[],.;"
		var input=path;
		var len=path.length;
		var errormsg = "";
    		 
    		for(var i =0;i<len;i++)
    		{
    		if(path.charAt(len-1)== "\\" || path.charAt(len)== "\\"){
    			flag=true;
    			break;
    			}
    			else if(path.charAt(len-1) == "\/" || path.charAt(len) == "\/"){
    			flag=true;
    			break;
    			}
    			else{
    			flag=false;
    			break;
    			}
    		}
    		if((ichar.indexOf(input.charAt(1)) !=-1) || (/[*?<>|]/.test(path)) || (/\\[a-zA-Z]:/.test(path)) || (/[a-zA-Z]:[a-zA-Z]/.test(path)) || (/\\:/.test(path)) || (/\\\\\\/.test(path)) ||(/\/\\/.test(path)) || (/\\\//.test.path) || (/\/\/\//.test(path))  || (/["]/.test(path)) ) 
    		{
    		flag= false;
    		}
    		
	return flag;
		}
	
		//to validate the numeric field that allows zeros
		function isNumericAllowZero(val) {   
		var iChars = "0123456789";
		
		if(val.length == 0) {
			return false;
		}
	
		if(val<0)
		{
			return false;
		}
		for (var i = 0; i < val.length; i++) {
			if (iChars.indexOf(val.charAt(i)) == -1) {
	  			return false;
	  		}
	  	}
	  	return true;

		}		

		function checkAlphaWithSpace(inputValue) {
			var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";
			if (len <=0) {
	            flag = false;
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  		} 	  	
		  	}
		  	
		  	if(inputValue.charAt(0) == " "){
		  		return false;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		return false;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		return false;
        	}
		  		
		  return flag;
	  
		}	

/**
**New URL verifications.
added by : pradeepa
*/
function ValidateWebSiteAddress(url)
{
   if((url.indexOf("https://") != -1 ) || (url.indexOf("http://") != -1))
	{
		var companyUrl = url; 
		var RegExp = /^(([\w]+:)?\/\/)?(([\d\w]|%[a-fA-f\d]{2,2})+(:([\d\w]|%[a-fA-f\d]{2,2})+)?@)?([\d\w][-\d\w]{0,253}[\d\w]\.)+[\w]{1,4}(:[\d]+)?(\/([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)*(\?(&?([-+_~.\d\w]|%[a-fA-f\d]{2,2})=?)*)?(#([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)?$/; 
	   // var RegExp = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/;
 
	    if(RegExp.test(companyUrl))
	    { 
		    if(url.indexOf("///") != -1) {		    
				return false;			
			}else
	       		return true;
	    }
	    else
	    { 
	        return false;
	    } 	
	} else {
		return false;
	}
} 

//External Connection URL Validation

function ValidateExternalConnURL(urlVal)
{
	var urlProtocol = urlVal.split(",");
	
   if((urlProtocol[0] == "https" && urlProtocol[1].indexOf("https://") != -1 ) || (urlProtocol[0] == "http" && urlProtocol[1].indexOf("http://") != -1))
	{ 
		var companyUrl = urlProtocol[1]; 
		//alert("11: "+companyUrl);
	    var RegExp = /^(([\w]+:)?\/\/)?(([\d\w]|%[a-fA-f\d]{2,2})+(:([\d\w]|%[a-fA-f\d]{2,2})+)?@)?([\d\w][-\d\w]{0,253}[\d\w]\.)+[\w]{2,4}(:[\d]+)?(\/([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)*(\?(&?([-+_~.\d\w]|%[a-fA-f\d]{2,2})=?)*)?(#([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)?$/; 
	    if(RegExp.test(companyUrl))
	    { 
	     //alert("22: "+urlProtocol[1].indexOf("///"));
	 	    if(urlProtocol[1].indexOf("///") != -1) {		    
				return false;			
			}
			/**if(urlProtocol[1].substring(urlProtocol[1].length-1, urlProtocol[1].length).indexOf("/") != -1) {
			//alert("33: ");
				return false;			
			}*/
			else
	       		return true;
	    }
	    else
	    { 
	        return false;
	    } 	
	} else {
	//alert("test");
		return false;
	}
} 
	
	
	function ValidateConnURL(url)
	{
		if((url.indexOf("https://") != -1 ) || (url.indexOf("http://") != -1) || (url.indexOf("HTTPS://") != -1 ) || (url.indexOf("HTTP://") != -1))
		{ 
		var companyUrl = url; 
	    var RegExp = /^(([\w]+:)?\/\/)?(([\d\w]|%[a-fA-f\d]{2,2})+(:([\d\w]|%[a-fA-f\d]{2,2})+)?@)?([\d\w][-\d\w]{0,253}[\d\w]\.)+[\w]{2,4}(:[\d]+)?(\/([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)*(\?(&?([-+_~.\d\w]|%[a-fA-f\d]{2,2})=?)*)?(#([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)?$/; 
	    if(RegExp.test(companyUrl))
	    { 
		    if(url.indexOf("///") != -1) {		    
				return false;			
			}if(url.substring(url.length-1, url.length).indexOf("/") != -1) {
				return false;			
			}else
			{
	       		return true;
	    	}
	    }
	    else
	    { 
	        return false;
	    } 	
	} else {
		return false;
	}
}

function isNumericForFees(val) {   
	var iChars = "0123456789.";
	
	if(val.length == 0) {
		return false;
	}
	var j= 0;

	for (var i = 0; i < val.length; i++) 
	{
		if (iChars.indexOf(val.charAt(i)) == -1) 
		{
  			return false;
  		} 
  		var sp = val.split(".");
  		if(sp.length > 2){  		
  			return false;
  		}  		
  	}
  	return true;
}

function isNumericFees(val) {   
	
	var flag = true;
	var errorMsg = "";
	var iChars = "0123456789.";
	
	if(val.length == 0)
	 {
		flag=false;
		errorMsg = errorMsgBlock[3];
	}
	
	var j= 0;

	for (var i = 0; i < val.length; i++) 
	{
		
		if (iChars.indexOf(val.charAt(i)) == -1) 
		{
  			flag=false;
  			errorMsg = errorMsgBlock[3];
  		} 
  		var sp = val.split(".");
  		
  		if(sp.length != 2){  
  				
  			flag=false;
  			errorMsg = errorMsgBlock[3];
  		}
  	}
  	return errorMsg;
}



function checkDecimalValue(val)
{
	var sp = val.split(".");
	if(sp[1].length!=3) {
		return false;
	}else {
		return true;
	}
}

	//Added By Shereen Banu N - For Transaction amount validation 
       function checkZero(val) {
       var roundOff=Math.round(val);
            if(roundOff<1) {
          return false;
            } else {
            	return true;
          }
        }
//Ends

	      
       function checkEqualZero(val) {
    	   var roundOff=parseFloat(val);
            if(roundOff <= 0) {
            	return false;
            } else {
		   return true;
	      }
        }

//validation to allow alhabetics with .@: in between - Monisha S (20/08/2012)
		
		function validateDbUrl(val)
		{
		var errorMsg = "";
			var iChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789:@.";
		
			for (var i = 0; i < val.length; i++) {
				if (iChars.indexOf(val.charAt(i)) == -1)
				{
		  			errorMsg = "Enter Valid Url";
		  		}
		  	}
		  	return errorMsg;
		}	
		function validateDate(val)
		{
				var errorMsg = "";
				if (val == "")
				{
		  			errorMsg = "Select Date";
		  		}
		  
		  	return errorMsg;
		}	
		/*To check whether the input value is alphabetic and it should not contain few spaces in the middle of the text. 
		There should not be any spaces at both ends*/
		
		function checkUDF(inputValue) {
		    //Commented By Anusha R -  For production issue
		    //var iChars = "~`!#$%^&*()+=-[]\\\';,.{}|\":<>?_";
			var iChars = "~`!#$%^&*()+=-[]\\\';,{}|\":<>?_";
			
			var len = inputValue.length;		
			var flag = true;
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[3];
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) != -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[3];
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}
		
			/*	Purpose : To check whether the value passed is Alphanumeric or Not, 
			Result	: Returns error message if it is not Alphanumeric.
		*/
		
		function checkAlphanumericWithSpaceForCert(inputValue) {
		
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -,";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[7];
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[18];
		  		} 	  	
		  	}
		  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		  	 var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  return errorMsg;
	  
		}
		
		function checkAlphanumericWithSpaceForStaticURL(inputValue) {
		
			var iChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.?=&-";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[7];
	        }
			for (var i = 0;i < len;i++) {
				if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[18];
		  		} 	  	
		  	}
		  return errorMsg;
	  
		}
		
		function checkAlphanumericWithSpecialCharAndSingleSpace(inputValue) {
		
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	            errorMsg = errorMsgBlock[7];
	        }
			
		  	if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		  	 var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
		  return errorMsg;
	  
		}
		function validateNotStartWithZero(inputValue) {
			var iChars = "0123456789";
			var len = inputValue.length;		
			var flag = true;	
			var errorMsg = "";		
			if (len <=0) {
	            flag = false;
	        }
	       // alert("Error:"+inputValue.charAt(0));
	         if(inputValue.charAt(0)=="0"){
		  		errorMsg = errorMsgBlock[21];
		  	//	alert("Error:"+errorMsg);
			  		return errorMsg;
		  	} 
	        if(inputValue.charAt(0) == " "){
		  		errorMsg = errorMsgBlock[8];
		  		return errorMsg;
		  	}
		  	if(inputValue.charAt(len-1) == " "){
		  		errorMsg = errorMsgBlock[9];
		  		return errorMsg;
		  	}
		    var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		errorMsg = errorMsgBlock[15];
		  		return errorMsg;
        	}
	        
			for (var i = 0;i < len;i++) {
				 if(inputValue.charAt(i) == " "){
			  		errorMsg = errorMsgBlock[16];
			  		return errorMsg;
		  		 }else if (iChars.indexOf(inputValue.charAt(i)) == -1){
		  			flag = false;
		  			errorMsg = errorMsgBlock[5];
		  		} 	  	
		  	}
		  	
		  return errorMsg;
			
		}
		
		function validateInvalidSpclChar(inputValue)
		{
		var flag = true;
		for (var i = 0;i < inputValue.length;i++) {
				
			  		 if(inputValue.charAt(i) == '<' || inputValue.charAt(i) == '>'){
			  		
			  		   flag = false;
			  		   break;
			  		 }
				}  
				return flag;
		}
		
	function checkdoublespace(inputValue){
	var msg="";
	var twoSpace = inputValue.indexOf("  ");
       	 	if (twoSpace != -1)
        	{
        		msg = errorMsgBlock[15];
		  		return msg;
        	}
		  return msg;
	
	}